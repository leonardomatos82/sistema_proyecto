<?php 
//include("control/valida.php"); 
include("../config.php");
?><style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.style2 {font-size: 36px}
.style3 {
	font-size: 9px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>

<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="3"><div align="center">
      <p><img src="../imagenes/banin.png" alt="d" width="850" height="70"></p>
      <p><img src="../imagenes/bannertop.png" alt="d" width="850" height="159"></p>
    </div></td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><font size="4">SISTEMA PARA EL CONTROL DE VIATICOS</font></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><img src="imagenes/mural1.png" alt="d" width="850" height="13" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><FONT Size=2>|<a href="tabla/menu_tabla.php?titulo=<?="TABLA DE VIATICOS"?>">Tabla</a> ||<a href="calculos/menu_viatico.php?titulo=<?="VIATICOS"?>">Viaticos</a> ||<a href="../usuario/menu_usuario.php?titulo=<?="USUARIOS"?>">Usuarios</a> ||<a href="consulta/listar.php?titulo=<?="OFICIO"?>">Oficios</a> ||<a href="consulta/buscar.php?titulo=<?="CONSULTAS"?>">Consultas</a> ||<a href="../control/desconectar.php">Salir</a> |</FONT>&nbsp;</div></td>
    <td>&nbsp;</td>
  </tr>
    <tr>
   <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
   <td><div align="left"><a href="../menu.php">Regresar al Menu Principal</a></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59"><p align="right">&nbsp;</p>
    <p align="right">&nbsp;</p></td>
    <td><div align="center"><span class="style2"><img src="imagenes/heading.jpg" alt="d" width="297" height="220" /></span></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><a href="manual/MANUAL_viaticos_def.doc"></a><span class="style3">Versi&oacute;n 3.0 </span></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
       <td>&nbsp;</td>
  </tr>

  <tr>
    <td>&nbsp;</td>
    <td><div align="right"><a href="manual/MANUAL_viaticos_def.doc">Ver Manual de Usuario</a></div>
    <div align="right"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
  </tr>
 
   <tr>
    <td colspan="3"><div align="center"><img src="imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>



