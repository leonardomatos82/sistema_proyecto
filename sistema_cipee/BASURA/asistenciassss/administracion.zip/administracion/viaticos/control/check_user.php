<?php
// Inicio la sesión
session_start();
header("Cache-control: private"); // Arregla IE 6


// reviso si coincide
if ( $_SESSION['tipo'] == "A") {
        
          echo"<b>Mensaje: </b>".$_GET[log].permitido."<br><br>"; die();
     
        } else {
     
         echo"<b>Mensaje: </b>".$_GET[log].no_tiene_permisos_para_modificar_estos_datos."<br><br>"; die();
     
        }
   
?>