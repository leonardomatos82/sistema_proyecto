<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
$result = pg_query($con,"SELECT * FROM oficio");
$row=pg_fetch_array($result);
?>
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Modificar Oficio </strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>Edite las caracter&iacute;sticas del Oficio:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59"><p align="right">&nbsp;</p>
    <p align="right">&nbsp;</p></td>
    <td><form style="width: 742px; height: 300px;" action="../control/edit_oficio.php" method="post">
      <p align="left">&nbsp;</p>
      <table width="81%" border="0" align="left" cellpadding="0">
        <tr>
          <td width="26%" height="33">Para:</td>
          <td width="74%"><input name="para" type="text" id="para" onkeypress="return acceptChar(event)" size="45" &gt="" value="<?php echo $row[para]; ?>"/>
            *</td>
        </tr>
        <tr>
          <td height="33">Destinatario:</td>
          <td><input name="dest" type="text" id="dest" onkeypress="return acceptChar(event)" size="45" &gt="" value="<?php echo $row[dest]; ?>"/>
            *</td>
        </tr>
        <tr>
          <td height="33">De:</td>
          <td><input name="de" type="text" id="de" onkeypress="return acceptChar(event)" size="45" &gt="" value="<?php echo $row[de]; ?>"/>
            *</td>
        </tr>
        <tr>
          <td height="33">Remitente:</td>
          <td><input name="rem" type="text" id="rem" onkeypress="return acceptChar(event)" size="45" &gt="" value="<?php echo $row[rem]; ?>"/>
            *</td>
        </tr>
        <tr>
          <td height="33">Pie pagina : </td>
          <td><textarea name="pie" cols="45" id="pie" onkeypress="return acceptchar(event)"><?php echo $row[pie]; ?></textarea>
            *</td>
        </tr>
        <tr>
          <td height="33">&nbsp;</td>
          <td><input value="Guardar" type="submit" name="submit" /></td>
        </tr>
      </table>
      <p align="left">&nbsp;</p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>
