<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
  <title>css.php</title>


</head>
<body>

<div style="text-align: center;">
<div style="text-align: center;"><img style="width: 776px; height: 111px;" alt="" src="imagenes/bannertop.png"><br>

</div>

<br>

<br>

|<a href="tipo/menu_tipo.php">Tipo</a>||<a href="marca/menu_marca.php">Marca</a>||<a href="modelo/menu_modelo.php">Modelo</a>||<a href="equipo/menu_equipo.php">Equipos</a>||<a href="software/menu_software.php">Software</a>||<a href="list_soft/menu_list.php">Lista de Software</a>||<a href="direccion/menu_direccion.php">Direcciones</a>||<a href="menu_usuario.php">Usuarios</a>|<a>
</a></div>

</body>
</html>
