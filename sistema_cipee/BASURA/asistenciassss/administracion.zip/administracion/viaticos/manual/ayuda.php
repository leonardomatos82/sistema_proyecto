<?php 
//include("control/valida.php"); 
//include("config.php");
?>
<body bgcolor="#CCCCCC">

<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="3"><div align="center">
      <p><img src="../imagenes/banin.png" alt="d" width="850" height="70"></p>
      <p><img src="../imagenes/bannertoppp.png" alt="d" width="850" height="159"></p>
    </div></td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><font size="4">SISTEMA PARA EL CONTROL DE VIATICOS</font></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><FONT Size=2>|<a href="../menu.php">VOLVER</a> |</FONT></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><strong>UNIVERSIDAD BOLIVARIANA DE VENEZUELA </strong></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59"><p align="right">&nbsp;</p>
    <p align="right">&nbsp;</p></td>
    <td><div align="center"><img src="../imagenes/barinas_.png" width="400" height="300" /></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><a href="MANUAL_viaticos_def.doc"></a>Urb. Pedro Brice&ntilde;o M&eacute;ndez, Sector los Pozones, Edificio ALMAGUARN. Detras del Destacamento 14 de la Guardia Nacional. Barinas Edo- Barinas. Telefono: 0273-5465236 </div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><a href="MANUAL_viaticos_def.doc">Ver Manual de Usuario</a></div>
    <div align="right"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>



