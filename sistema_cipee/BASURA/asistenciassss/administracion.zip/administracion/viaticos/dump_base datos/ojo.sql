--
-- PostgreSQL database dump
--

-- Started on 2007-10-06 18:43:40

SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- TOC entry 1632 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- TOC entry 274 (class 2612 OID 16386)
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 1284 (class 1259 OID 16435)
-- Dependencies: 1622 4
-- Name: acceso; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE acceso (
    "login" character varying(30) NOT NULL,
    clave character varying(30) NOT NULL,
    tipo character varying(15) NOT NULL,
    id_acceso integer DEFAULT nextval(('public.acceso_id_seq'::text)::regclass) NOT NULL
);


ALTER TABLE public.acceso OWNER TO postgres;

--
-- TOC entry 1285 (class 1259 OID 16440)
-- Dependencies: 4
-- Name: acceso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE acceso_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.acceso_id_seq OWNER TO postgres;

--
-- TOC entry 1634 (class 0 OID 0)
-- Dependencies: 1285
-- Name: acceso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('acceso_id_seq', 4, true);


--
-- TOC entry 1279 (class 1259 OID 16413)
-- Dependencies: 4
-- Name: oficio; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE oficio (
    id_oficio integer NOT NULL,
    para character varying(100) NOT NULL,
    dest character varying(100) NOT NULL,
    de character varying(100) NOT NULL,
    rem character varying(100) NOT NULL,
    pie character varying(255) NOT NULL
);


ALTER TABLE public.oficio OWNER TO postgres;

--
-- TOC entry 1280 (class 1259 OID 16415)
-- Dependencies: 1619 4
-- Name: tabla; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tabla (
    tipo character varying(30) NOT NULL,
    desayuno numeric NOT NULL,
    almuerzo numeric NOT NULL,
    cena numeric NOT NULL,
    alojamiento numeric NOT NULL,
    taxi numeric(11,0) NOT NULL,
    transporte numeric(11,0) NOT NULL,
    tasa numeric(11,0) NOT NULL,
    autobus numeric(11,0) NOT NULL,
    vehiculo numeric(11,0) NOT NULL,
    id_tabla integer DEFAULT nextval(('public.tabla_id_tabla_seq'::text)::regclass) NOT NULL
);


ALTER TABLE public.tabla OWNER TO postgres;

--
-- TOC entry 1286 (class 1259 OID 16442)
-- Dependencies: 4
-- Name: tabla_id_tabla_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tabla_id_tabla_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tabla_id_tabla_seq OWNER TO postgres;

--
-- TOC entry 1635 (class 0 OID 0)
-- Dependencies: 1286
-- Name: tabla_id_tabla_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tabla_id_tabla_seq', 2, true);


--
-- TOC entry 1281 (class 1259 OID 16421)
-- Dependencies: 4
-- Name: transaccion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE transaccion (
    fecha date,
    hora time with time zone,
    operacion text,
    "login" text
);


ALTER TABLE public.transaccion OWNER TO postgres;

--
-- TOC entry 1282 (class 1259 OID 16426)
-- Dependencies: 1620 4
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usuario (
    nomb_usuario character varying(70) NOT NULL,
    cedula character varying(10) NOT NULL,
    cargo character varying(70) NOT NULL,
    id_usuario integer DEFAULT nextval(('public.usuario_id_usuari_seq'::text)::regclass) NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- TOC entry 1287 (class 1259 OID 16444)
-- Dependencies: 4
-- Name: usuario_id_usuari_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usuario_id_usuari_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.usuario_id_usuari_seq OWNER TO postgres;

--
-- TOC entry 1636 (class 0 OID 0)
-- Dependencies: 1287
-- Name: usuario_id_usuari_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usuario_id_usuari_seq', 1, true);


--
-- TOC entry 1283 (class 1259 OID 16429)
-- Dependencies: 1621 4
-- Name: viaticos; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE viaticos (
    id_tipo integer NOT NULL,
    cedula character varying(10) NOT NULL,
    motivo character varying(500) NOT NULL,
    fecha_ida character varying(15) NOT NULL,
    fecha_ret character varying(15) NOT NULL,
    dias integer NOT NULL,
    subtotal numeric NOT NULL,
    taxi numeric NOT NULL,
    transporte numeric NOT NULL,
    tasa numeric NOT NULL,
    otra1 numeric NOT NULL,
    otra2 numeric NOT NULL,
    observaciones character varying(500) NOT NULL,
    total numeric NOT NULL,
    tiempo1 character varying(15) NOT NULL,
    tiempo2 character varying(15) NOT NULL,
    des character varying(15) NOT NULL,
    alm character varying(15) NOT NULL,
    cen character varying(15) NOT NULL,
    alo character varying(15) NOT NULL,
    id_viatico integer DEFAULT nextval(('public.viaticos_id_viatico_seq'::text)::regclass) NOT NULL,
    departamento character varying
);


ALTER TABLE public.viaticos OWNER TO postgres;

--
-- TOC entry 1288 (class 1259 OID 16446)
-- Dependencies: 4
-- Name: viaticos_id_viatico_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE viaticos_id_viatico_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.viaticos_id_viatico_seq OWNER TO postgres;

--
-- TOC entry 1637 (class 0 OID 0)
-- Dependencies: 1288
-- Name: viaticos_id_viatico_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('viaticos_id_viatico_seq', 3, true);


--
-- TOC entry 1628 (class 0 OID 16435)
-- Dependencies: 1284
-- Data for Name: acceso; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO acceso ("login", clave, tipo, id_acceso) VALUES ('leonardo', '15796044', 'A', 2);


--
-- TOC entry 1623 (class 0 OID 16413)
-- Dependencies: 1279
-- Data for Name: oficio; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO oficio (id_oficio, para, dest, de, rem, pie) VALUES (1, 'COORD ADMINISTRACION', 'COORDINADOR', 'PRESUPUESTO', 'COORDINADOR', 'PATRIA SOCIALISMO O MUERTE, VENCEREMOS');


--
-- TOC entry 1624 (class 0 OID 16415)
-- Dependencies: 1280
-- Data for Name: tabla; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO tabla (tipo, desayuno, almuerzo, cena, alojamiento, taxi, transporte, tasa, autobus, vehiculo, id_tabla) VALUES ('prueba 1 ', 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1);


--
-- TOC entry 1625 (class 0 OID 16421)
-- Dependencies: 1281
-- Data for Name: transaccion; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '07:53:58-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:24:59-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:25:08-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:25:36-04', '-Operacion: Agregar -Acceso: acceso -Registro Usuario: usuario', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:33:21-04', '-Operacion: Agregar -Acceso: acceso -Registro Usuario: leonardo', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:33:38-04', '-Operacion: Agregar -Acceso: acceso -Registro Usuario: usuario', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:46:49-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:51:37-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:52:55-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:53:32-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:53:41-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:53:57-04', '-Operacion: Agregar -Acceso: acceso -Registro Usuario: fgg', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '08:54:49-04', '-Operacion: Agregar -Acceso: acceso -Registro Usuario: fgg', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:10:01-04', '-Operacion: Eliminar -Acceso: Acceso -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:10:06-04', '-Operacion: Eliminar -Acceso: Acceso -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:11:51-04', '-Operacion: Modificar -Acceso: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:13:42-04', '-Operacion: Eliminar -Acceso: Acceso -Registro ID: 4', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:24:02-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:46:07-04', '-Operacion: Agregar -Acceso: Tabla -Registro Desc: prueba 1 ', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '09:46:28-04', '-Operacion: Agregar -Acceso: Tabla -Registro Desc: PRUEBA 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:28:49-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:29:01-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:37:34-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:37:46-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:37:53-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:38:45-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:38:51-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:38:57-04', '-Operacion: Eliminar -Tabla: Acceso -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '10:44:37-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '11:12:50-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '16:14:45-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '16:47:47-04', '-Operacion: Agregar -Tabla: Viaticos -Registro ID: 15796044', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '16:52:15-04', '-Operacion: Agregar -Tabla: Viaticos -Registro ID: 15796044', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '16:52:33-04', '-Operacion: Imprimir -Tabla: Viatico -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '16:57:47-04', '-Operacion: Modificar -Tabla: Viaticos -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:19:53-04', '-Operacion: Modificar -Tabla: Viaticos -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:20:01-04', '-Operacion: Modificar -Tabla: Viaticos -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:28:53-04', '-Operacion: Eliminar -Tabla: Viaticos -Registro ID: 2', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:38:49-04', '-Operacion: Eliminar -Tabla: Viaticos -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:40:06-04', '-Operacion: Agregar -Tabla: Viaticos -Registro ID: 15796044', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:40:11-04', '-Operacion: Imprimir -Tabla: Viatico -Registro ID: 3', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:40:41-04', '-Operacion: Modificar -Tabla: Viaticos -Registro ID: 3', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:41:07-04', '-Operacion: Modificar -Tabla: Viaticos -Registro ID: 3', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:51:34-04', '-Operacion: Imprimir -Tabla: Viatico -Registro ID: 3', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:52:14-04', '-Operacion: Imprimir -Tabla: Viatico -Registro ID: 3', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:52:37-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '17:52:48-04', '-Operacion: Modificar -Tabla: Viaticos -Registro ID: 3', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '18:11:28-04', '-Operacion: Modificar -Acceso: Oficio -: ', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '18:13:08-04', '-Operacion: Modificar -Acceso: Oficio -: ', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '18:17:35-04', '-Operacion: Modificar -Acceso: Oficio -: ', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '18:36:28-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:32:03-04', '-Operacion: Modificar -Tabla: Usuario -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:34:51-04', '-Operacion: Modificar -Tabla: Usuario -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:34:58-04', '-Operacion: Modificar -Tabla: Usuario -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:39:11-04', '-Operacion: Eliminar -Tabla: Usuario -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:39:34-04', '-Operacion: Modificar -Tabla: Viatico -Registro ID: 1', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:41:37-04', '-Operacion: Entrar al sistema', 'leonardo');
INSERT INTO transaccion (fecha, hora, operacion, "login") VALUES ('2007-10-06', '19:41:49-04', '-Operacion: Eliminar -Acceso: Acceso -Registro ID: 3', 'leonardo');


--
-- TOC entry 1626 (class 0 OID 16426)
-- Dependencies: 1282
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 1627 (class 0 OID 16429)
-- Dependencies: 1283
-- Data for Name: viaticos; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO viaticos (id_tipo, cedula, motivo, fecha_ida, fecha_ret, dias, subtotal, taxi, transporte, tasa, otra1, otra2, observaciones, total, tiempo1, tiempo2, des, alm, cen, alo, id_viatico, departamento) VALUES (1, '15796044', 'es una prueba fksdghksfd gkjfhgdf vkljhfdgjdfg', '18/10/2007', '20/10/2007', 3, 9000, 40000, 30000, 0, 0, 0, '', 79000, '1', '1', '1', '1', '1', '1', 3, NULL);


--
-- TOC entry 1633 (class 0 OID 0)
-- Dependencies: 4
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2007-10-06 18:43:41

--
-- PostgreSQL database dump complete
--

