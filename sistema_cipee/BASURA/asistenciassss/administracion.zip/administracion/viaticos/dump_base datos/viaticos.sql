

ALTER TABLE public.acceso OWNER TO viaticos;

--
-- TOC entry 1468 (class 1259 OID 1984013)
-- Dependencies: 5 1467
-- Name: acceso_id_seq; Type: SEQUENCE; Schema: public; Owner: viaticos
--

CREATE SEQUENCE acceso_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.acceso_id_seq OWNER TO viaticos;

--
-- TOC entry 1808 (class 0 OID 0)
-- Dependencies: 1468
-- Name: acceso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viaticos
--

ALTER SEQUENCE acceso_id_seq OWNED BY acceso.id_acceso;


--
-- TOC entry 1462 (class 1259 OID 17288)
-- Dependencies: 5
-- Name: geometry_columns; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE geometry_columns (
    f_table_catalog character varying(256) NOT NULL,
    f_table_schema character varying(256) NOT NULL,
    f_table_name character varying(256) NOT NULL,
    f_geometry_column character varying(256) NOT NULL,
    coord_dimension integer NOT NULL,
    srid integer NOT NULL,
    "type" character varying(30) NOT NULL
);


ALTER TABLE public.geometry_columns OWNER TO postgres;

--
-- TOC entry 1466 (class 1259 OID 1983335)
-- Dependencies: 5
-- Name: oficio; Type: TABLE; Schema: public; Owner: viaticos; Tablespace: 
--

CREATE TABLE oficio (
    id_oficio integer NOT NULL,
    para character varying(100) NOT NULL,
    dest character varying(100) NOT NULL,
    de character varying(100) NOT NULL,
    rem character varying(100) NOT NULL,
    pie character varying(255) NOT NULL
);


ALTER TABLE public.oficio OWNER TO viaticos;

--
-- TOC entry 1460 (class 1259 OID 17250)
-- Dependencies: 1534 5
-- Name: pg_logdir_ls; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW pg_logdir_ls AS
    SELECT a.filetime, a.filename FROM pg_logdir_ls() a(filetime timestamp without time zone, filename text);


ALTER TABLE public.pg_logdir_ls OWNER TO postgres;

--
-- TOC entry 1461 (class 1259 OID 17281)
-- Dependencies: 5
-- Name: spatial_ref_sys; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE spatial_ref_sys (
    srid integer NOT NULL,
    auth_name character varying(256),
    auth_srid integer,
    srtext character varying(2048),
    proj4text character varying(2048)
);


ALTER TABLE public.spatial_ref_sys OWNER TO postgres;

--
-- TOC entry 1465 (class 1259 OID 1983323)
-- Dependencies: 1796 5
-- Name: tabla; Type: TABLE; Schema: public; Owner: viaticos; Tablespace: 
--

CREATE TABLE tabla (
    tipo character varying(30) NOT NULL,
    desayuno numeric NOT NULL,
    almuerzo numeric NOT NULL,
    cena numeric NOT NULL,
    alojamiento numeric NOT NULL,
    taxi numeric(11,0) NOT NULL,
    transporte numeric(11,0) NOT NULL,
    tasa numeric(11,0) NOT NULL,
    autobus numeric(11,0) NOT NULL,
    vehiculo numeric(11,0) NOT NULL,
    id_tabla integer DEFAULT nextval('public.tabla_id_tabla_seq'::text) NOT NULL
);


ALTER TABLE public.tabla OWNER TO viaticos;

--
-- TOC entry 1471 (class 1259 OID 1984037)
-- Dependencies: 1465 5
-- Name: tabla_id_tabla_seq; Type: SEQUENCE; Schema: public; Owner: viaticos
--

CREATE SEQUENCE tabla_id_tabla_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tabla_id_tabla_seq OWNER TO viaticos;

--
-- TOC entry 1809 (class 0 OID 0)
-- Dependencies: 1471
-- Name: tabla_id_tabla_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viaticos
--

ALTER SEQUENCE tabla_id_tabla_seq OWNED BY tabla.id_tabla;


SET default_with_oids = false;

--
-- TOC entry 1472 (class 1259 OID 1986228)
-- Dependencies: 5
-- Name: transaccion; Type: TABLE; Schema: public; Owner: viaticos; Tablespace: 
--

CREATE TABLE transaccion (
    fecha date,
    hora time with time zone,
    operacion text,
    "login" text
);


ALTER TABLE public.transaccion OWNER TO viaticos;

SET default_with_oids = true;

--
-- TOC entry 1464 (class 1259 OID 1983317)
-- Dependencies: 1795 5
-- Name: usuario; Type: TABLE; Schema: public; Owner: viaticos; Tablespace: 
--

CREATE TABLE usuario (
    nomb_usuario character varying(70) NOT NULL,
    cedula character varying(10) NOT NULL,
    cargo character varying(70) NOT NULL,
    id_usuario integer DEFAULT nextval('public.usuario_id_usuari_seq'::text) NOT NULL
);


ALTER TABLE public.usuario OWNER TO viaticos;

--
-- TOC entry 1469 (class 1259 OID 1984020)
-- Dependencies: 5 1464
-- Name: usuario_id_usuari_seq; Type: SEQUENCE; Schema: public; Owner: viaticos
--

CREATE SEQUENCE usuario_id_usuari_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.usuario_id_usuari_seq OWNER TO viaticos;

--
-- TOC entry 1810 (class 0 OID 0)
-- Dependencies: 1469
-- Name: usuario_id_usuari_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viaticos
--

ALTER SEQUENCE usuario_id_usuari_seq OWNED BY usuario.id_usuario;


--
-- TOC entry 1463 (class 1259 OID 1983309)
-- Dependencies: 1794 5
-- Name: viaticos; Type: TABLE; Schema: public; Owner: viaticos; Tablespace: 
--

CREATE TABLE viaticos (
    id_tipo integer NOT NULL,
    cedula character varying(10) NOT NULL,
    motivo character varying(500) NOT NULL,
    fecha_ida character varying(15) NOT NULL,
    fecha_ret character varying(15) NOT NULL,
    dias integer NOT NULL,
    subtotal numeric NOT NULL,
    taxi numeric NOT NULL,
    transporte numeric NOT NULL,
    tasa numeric NOT NULL,
    otra1 numeric NOT NULL,
    otra2 numeric NOT NULL,
    observaciones character varying(500) NOT NULL,
    total numeric NOT NULL,
    tiempo1 character varying(15) NOT NULL,
    tiempo2 character varying(15) NOT NULL,
    des character varying(15) NOT NULL,
    alm character varying(15) NOT NULL,
    cen character varying(15) NOT NULL,
    alo character varying(15) NOT NULL,
    id_viatico integer DEFAULT nextval('public.viaticos_id_viatico_seq'::text) NOT NULL,
    departamento character varying
);


ALTER TABLE public.viaticos OWNER TO viaticos;

--
-- TOC entry 1470 (class 1259 OID 1984027)
-- Dependencies: 5 1463
-- Name: viaticos_id_viatico_seq; Type: SEQUENCE; Schema: public; Owner: viaticos
--

CREATE SEQUENCE viaticos_id_viatico_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.viaticos_id_viatico_seq OWNER TO viaticos;

--
-- TOC entry 1811 (class 0 OID 0)
-- Dependencies: 1470
-- Name: viaticos_id_viatico_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: viaticos
--

ALTER SEQUENCE viaticos_id_viatico_seq OWNED BY viaticos.id_viatico;


--
-- TOC entry 1801 (class 16386 OID 17291)
-- Dependencies: 1462 1462 1462 1462 1462
-- Name: geometry_columns_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY geometry_columns
    ADD CONSTRAINT geometry_columns_pk PRIMARY KEY (f_table_catalog, f_table_schema, f_table_name, f_geometry_column);


--
-- TOC entry 1803 (class 16386 OID 1983338)
-- Dependencies: 1466 1466
-- Name: oficio_pkey; Type: CONSTRAINT; Schema: public; Owner: viaticos; Tablespace: 
--

ALTER TABLE ONLY oficio
    ADD CONSTRAINT oficio_pkey PRIMARY KEY (id_oficio);


--
-- TOC entry 1799 (class 16386 OID 17287)
-- Dependencies: 1461 1461
-- Name: spatial_ref_sys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY spatial_ref_sys
    ADD CONSTRAINT spatial_ref_sys_pkey PRIMARY KEY (srid);


--
-- TOC entry 1807 (class 0 OID 0)
-- Dependencies: 5
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--