<table width="76.7%" border="1" align="center" cellpadding="1" cellspacing="0" bordercolor="#000000" bgcolor="#FFFFFF">
  <tr>
    <td height="19" bordercolor="#000000" bgcolor="#FFFFFF"><div align="center">
      <p><img src="../imagenes/mural1.png" width="749" height="15" /></p>
    </div></td>
  </tr>
</table>
