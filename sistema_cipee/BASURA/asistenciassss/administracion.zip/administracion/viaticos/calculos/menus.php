<a href="javascript:print()">>Imprimir</a>

<!--Codigo para colocar en cualquier parte de la pagina.-->
<!--www.lawebdelprogramador.com-->
<!--INICIO-->
<script language="JavaScript">
function ChangeUrl(form)
{
 	if (form.ListeUrl.selectedIndex != 0)
 	{
  		location.href = form.ListeUrl.options[form.ListeUrl.selectedIndex].value;
  	}
 	else 
  	{
  		alert('Selecciona una opción');
  	}
}
</script>
<!--FIN-->

<!--Codigo para el Menu desplegable...-->
<!--www.lawebdelprogramador.com-->
<!--INICIO-->
<form>
<select name="ListeUrl" size=1 onChange="ChangeUrl(this.form)">
<option SELECTED value="">Selecciona la Opción
	<option value="http://www.lawebdelprogramador.com/codigo/">Código Fuente
	<option value="http://www.lawebdelprogramador.com/cursos/">Cursos
	<option value="http://www.lawebdelprogramador.com/buscar/">Buscador para programadores
	<option value="http://www.lawebdelprogramador.com/news/">Foros
</select>
</FORM>
<!--FIN-->
