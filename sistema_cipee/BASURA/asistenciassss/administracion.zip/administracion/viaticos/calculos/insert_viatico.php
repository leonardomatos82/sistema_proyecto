<?php
 session_start();
include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
//include("../../utils.php");

?> 
<?php
include("../../atras.php"); 
?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="../menu.php";" method="post">
      <p align="left"><br />
          <?php
   
if($_POST[cedula]==""|| $_POST[nombre]=="" ||  $_POST[motivo]=="" ||   $_POST[ida]==""  || $_POST[retorno]=="" ||  $_POST[taxi]=="" || $_POST[transporte]==""|| $_POST[tasa]=="")
	{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>"; 
      	}
	  else 
	   {
	   $query2="select * from usuario where cedula_rif='$_POST[cedula]'";
       $result=pg_query($con,$query2);
       $row=pg_fetch_array($result);
     
     
       if ($_POST[cedula]==$row[cedula_rif]) {
      // echo "imposible guardar en la tabla usuario, registro existe";
      }
	    
	    else 
		{
		$tipo="TRABAJADOR";
		 $sql1="INSERT INTO usuario (cedula_rif,nombre,tipo) 
       VALUES ('$_POST[cedula]','$_POST[nombre]','$tipo')"; 
		pg_query($con,$sql1);
		}
		$estado="EN PROCESO";
      	   
       $sq2="INSERT INTO viaticos (cedula,id_tipo,motivo,fecha_ida,fecha_ret,dias,subtotal,taxi,transporte,tasa,otra1,otra2,observaciones,total,tiempo1,tiempo2,des,alm,cen,alo,estado,departamento) 
     
	 VALUES (
'$_POST[cedula]',
$_GET[tipo],
'$_POST[motivo]',
'$_POST[ida]',
'$_POST[retorno]'
,$_GET[dias],	
$_POST[subtotal],
$_POST[taxi],
$_POST[transporte],
$_POST[tasa],
$_POST[otra1],
$_POST[otra2],
'$_POST[observaciones]',
$_POST[total],
'$_GET[tiempo1]',
$_GET[tiempo2],
'$_GET[des]',
'$_GET[alm]',
'$_GET[cen]',
'$_GET[alo]',
'$estado',
'$_POST[departamento]'
)"; 

	        if (!pg_query($con,$sq2)) { die('Error: ' . pg_result_error()); } 
    echo " Registro  agregado";
 	 /////////////////////////////
$valor="-Operacion: Agregar -Tabla: Viaticos -Registro ID: ".$_POST[cedula];
        registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////

       }
 pg_close($con);
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver al Menu" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
    <?php
include("../../pie.php"); 
?> 