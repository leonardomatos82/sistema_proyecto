<?php
 session_start();
include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
//include("../../utils.php");

?> 
    <?php
include("../../atras.php"); 
 ?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="../menu.php";" method="post">
      <p align="left"><br />
          <?php
   


if($_POST[cedula]==""|| $_POST[nombre]=="" || $_POST[motivo]=="" ||   $_POST[ida]==""  || $_POST[retorno]=="" ||  $_POST[taxi]=="" || $_POST[transporte]==""|| $_POST[tasa]=="")
	{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>"; 
      	}
	  else 
	   {
	            
	   
$sql = "UPDATE viaticos SET 
cedula='$_POST[cedula]',
id_tipo=$_GET[tipo],
motivo='$_POST[motivo]',
fecha_ida='$_POST[ida]',
fecha_ret='$_POST[retorno]',
dias=$_GET[dias],
subtotal=$_POST[subtotal],
taxi=$_POST[taxi],
transporte=$_POST[transporte],
tasa=$_POST[tasa],
otra1=$_POST[otra1],
otra2=$_POST[otra2],
observaciones='$_POST[observaciones]',
total=$_POST[total],
tiempo1='$_GET[tiempo1]',
tiempo2='$_GET[tiempo2]',
des='$_GET[des]',
alm='$_GET[alm]',
cen='$_GET[cen]',
alo='$_GET[alo]' 	
	
WHERE id_viatico=$_GET[id]";
	   

     	    if (!pg_query($con,$sql)) { die('Error: '.pg_result_error()); } 
       
       echo "Registro  Modificado";
	   	 /////////////////////////////
$valor="-Operacion: Modificar -Tabla: Viaticos -Registro ID: ".$_GET[id];
        registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////
           
       }
pg_close($con);
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver al Menu" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
     <?php
include("../../pie.php"); 
 ?>  