<?php 
include("../../control/valida.php"); 
include("../../config.php");
include("../../utils.php");
 session_start();
 
 	 /////////////////////////////
$valor="-Operacion: Imprimir -Tabla: Viatico -Registro ID: ".$_GET[id];
        registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////  

$resultado = pg_query($con,"SELECT tabla.id_tabla,tabla.tipo,viaticos.id_viatico,viaticos.cedula,usuario.nombre,usuario.telf,viaticos.motivo,viaticos.fecha_ida,viaticos.fecha_ret,viaticos.total,viaticos.otra1,viaticos.otra2,viaticos.observaciones,viaticos.tiempo1,viaticos.tiempo2,viaticos.des,viaticos.alm,viaticos.cen,viaticos.alo,viaticos.taxi,viaticos.transporte,viaticos.tasa,viaticos.dias
 FROM viaticos 
  INNER JOIN usuario ON viaticos.cedula= usuario.cedula_rif 
  INNER JOIN tabla ON viaticos.id_tipo= tabla.id_tabla

 where viaticos.id_viatico='$_GET[id]'");
 $row2=pg_fetch_array($resultado);
 

if ($_GET[tipo]==0){ die();}

$resultado3 = pg_query($con,"SELECT * FROM tabla");
$result = pg_query($con,"SELECT * FROM tabla WHERE id_tabla='$_GET[tipo]'");
$row=pg_fetch_array($result);
$funcion=getDateDifference($row2[tiempo1],$row2[tiempo2])+1;
$max=$row2[dias];
$cont=1;
$subtotal=0;
$total=0;
$tipo=$row2[tipo];
$tiempo1=$row2[tiempo1];
$tiempo2=$row2[tiempo2];
$des=$row2[des];
$alm=$row2[alm];
$cen=$row2[cen];
$alo=$row2[alo];
$taxi=$row[taxi];
$transporte=$row[transporte];
$tasa=$row[tasa];
$query2="SELECT * FROM configuracion where id_configuracion='1'";
$result2=pg_query($con,$query2);
$row4=pg_fetch_array($result2);

?>
 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
  </script>
  <p align="center"><img src="../imagenes/bannertop22.png" alt="" width="77%" style="width: 100%; height: 90px;"></p>
  <p align="right">              <script language="javascript">
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el a�o a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
document.write(nombres_dias[dia_semana] + ", " + dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)

//-->
              </script>&nbsp;</p>
  <p align="center"><strong>RECIBO DE VIATICOS </strong></p>
  <p>YO, <?php echo $row2[nombre];?></p>
  <p>Cedula de Identidad: <?php echo $row2[cedula];?></p>
  <p>He recibido de parte de la Universidad Bolivariana de Venezuela, por concepto de: 
 <?php echo $row2[motivo];?>
  .  
  <p>Los viaticos se detallan a continuaci&oacute;n: 
  <table width="33%" border="0">
    <tr>
      <td width="19%">Desde:</td>
      <td width="37%"><div align="left"><?php echo $row2[fecha_ida];?></div></td>
      <td width="21%">Hasta:</td>
      <td width="23%"><div align="left"><?php echo $row2[fecha_ret];?></div></td>
    </tr>
  </table>
  <p>
  
  <tbody> 
  <td width=76% height="472" bordercolor="#000000" bgcolor="#FFFFFF">  
    <div align="left">
<form style="width: 100%; height: 430px;" action="insert_viatico.php?tipo=<?=$tipo?>&dias=<?=$max?>&tiempo1=<?=$tiempo1?>&tiempo2=<?=$tiempo2?>&des=<?=$des?>&alm=<?=$alm?>&cen=<?=$cen?>&alo=<?=$alo?>" method="post" >
          <p>
            <?php
echo "<table align=center cellpadding=1 cellspacing=0  background-color: rgb(255, 255, 255); border =1; WIDTH=100% bgcolor=FFFFFF>";
echo "<tr>";
echo "<td <small style=width:  50px font-weight: bold><b>DIAS</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>_DESAYUNO__</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>__ALMUERZO_</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>____CENA___</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>_ALOJAMIENTO_</b></td>";
echo "<td <small style=width:  50px font-weight: bold><b>__SUBTOTAL_</b></td>";

echo "</tr> ";
while($cont<=$max){
$subsubtotal=0;
echo "<tr align=right> ";

$fecha=$row2[fecha_ida];
echo "<td <small style=width: 50px >$cont</td> ";
$desayuno=$row[desayuno];
$almuerzo=$row[almuerzo];
$cena=$row[cena];
$alojamiento=$row[alojamiento];
if (($row2[tiempo1]==2) && $cont==1) { $desayuno=0;  }
if (($row2[tiempo1]==3) && $cont==1) { $desayuno=0; $almuerzo=0; }

if (($row2[tiempo2]==1) && $cont==$max){ $almuerzo=0; $cena=0;  }
if (($row2[tiempo2]==2) && $cont==$max){ $cena=0;  }

if ($row2[des]==1) {echo "<td <small style=width: 50px >$desayuno</td> ";}
else  {  $desayuno=0;  echo "<td <small style=width: 50px >$desayuno</td> ";}

if ($row2[alm]==1) {echo "<td <small style=width: 50px >$almuerzo</td> ";}
else  {  $almuerzo=0;  echo "<td <small style=width: 50px >$almuerzo</td> ";}

if ($row2[cen]==1) {echo "<td <small style=width: 50px >$cena</td> ";}
else  {  $cena=0;  echo "<td <small style=width: 50px >$cena</td> ";}

if ($cont==$max){ $alojamiento=0;  }
if ($row2[alo]==1) {echo "<td <small style=width: 50px >$alojamiento</td> ";}
else  {  $alojamiento=0;  echo "<td <small style=width: 50px >$alojamiento</td> ";}


$subsubtotal=$subsubtotal+$desayuno+$almuerzo+$cena+$alojamiento;
$subtotal=$subtotal+$subsubtotal;

echo "<td <small style=width: 50px >$subsubtotal</td> ";

?>
            <?PHP
echo "</tr> ";
$cont++;}
echo "</table>";
?>
</p>
          <p align="right"><strong>SUB TOTAL:.....
          <?php echo $subtotal;?></strong></p>
          <table width="44%" border="0" align="center">
            <tr> 
              <td width="46%">&nbsp;</td>
              <td width="54%"><em><strong>Otras Asignaciones</strong></em></td>
            </tr>
            <tr> 
              <td height="24"><div align="right">Taxi:</div></td>
              <td><?php echo $row2[taxi];;?></td>
            </tr>
            <tr> 
              <td><div align="right">Transporte:</div></td>
              <td><?php echo $row2[transporte];?></td>
            </tr>
            <tr> 
              <td><div align="right">Tasa aerea ida vuelta:</div></td>
              <td><?php echo $row2[tasa];?></td>
            </tr>
            <tr> 
              <td><div align="right">Otra:</div></td>
              <td><?php echo $row2[otra1];?></td>
            </tr>
            <tr> 
              <td><div align="right">Otra:</div></td>
              <td><?php echo $row2[otra2];?></td>
            </tr>
      </table>
		  <? $total=$total+$subtotal+$row2[taxi]+$row2[transporte]+$row2[tasa]+$row2[otra1]+$row2[otra2]; ?>
          Observaciones:
          <?php echo $row2[observaciones];?>
          <p align="right"><strong>TOTAL A PAGAR POR CONCEPTO DE VIATICOS:......
          <?php echo $total;?>          </strong></p>
          <p align="right"></p>
          <p align="right"></p>
          <table width="30%" border="0">
            <tr> 
              <td width="37%"><strong>Recibi conforme: </strong></td>
            </tr>
            <tr>
              <td>Nombre: <?php echo $row2[nombre];?></td>
            </tr>
            <tr>
              <td>Cedula de Identidad: <?php echo $row2[cedula];?></td>
            </tr>
            <tr>
              <td>Fecha:</td>
            </tr>
          </table>
          <p>
      </form>
    </div>
<table width="830" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr bordercolor="#CCCCCC"> 
    <td width="192"><strong><font size="1">ELABORADO POR</font></strong></td>
    <td width="201"><strong><font size="1">APROBADO POR</font></strong></td>
    <td width="273"><strong><font size="1">AUTORIZADO POR</font></strong></td>
    <td width="164">&nbsp;</td>
  </tr>
  <tr> 
    <td><font size="1"><?php echo $_SESSION[nomb_usuario];?></font></td>
    <td><font size="1"><?php echo $row4['coordinador_adm'];?></font></td>
    <td><font size="1"><?php echo $row4['coordinador_sede'];?></font></td>
    <td width="192"><strong><font size="1"><strong>SELLO</strong></td>
  </tr>
      <tr> 
    <td><font size="2"></font></td>
    <td><font size="2"><?php echo $row4['cargo2'];?></font></td>
    <td><font size="2"><?php echo $row4['cargo1'];?></font></td>  
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  <tr> 
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr></tr>
</table>
  </tbody> 
</table>
  