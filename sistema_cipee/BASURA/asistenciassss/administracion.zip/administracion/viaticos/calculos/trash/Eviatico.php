<?php 
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
include("../utils.php");
$resultado3 = pg_query($con,"SELECT * FROM tabla");

$result = pg_query($con,"SELECT tabla.id_tabla,tabla.tipo,viaticos.id_viatico,viaticos.cedula,usuario.nomb_usuario,usuario.cargo,viaticos.motivo,viaticos.fecha_ida,viaticos.fecha_ret,viaticos.total,viaticos.otra1,viaticos.otra2,viaticos.observaciones,viaticos.tiempo1,viaticos.tiempo2,viaticos.des,viaticos.alm,viaticos.cen,viaticos.alo
 FROM viaticos 
  INNER JOIN usuario ON viaticos.cedula= usuario.cedula 
  INNER JOIN tabla ON viaticos.id_tipo= tabla.id_tabla

 where viaticos.id_viatico='$_GET[id]'");
$id=$_GET[id];

$row=pg_fetch_array($result);



?>
 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 47 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
  </script>
  <style type="text/css">
<!--
.style2 {font-size: 16px}
-->
  </style>
  
<table width=77% border="2" align="center" cellpadding="1" cellspacing="0">
  <tbody> 
  <td width=76% height="552" bordercolor="#000000" bgcolor="#FFFFFF"> 
      <div align="left">
<form style="width: 742px; height: 430px;" action="elim_viatico.php?id=<?=$id?>"  method="post">
          <table width="15%" border="1" align="right">
            <tr bgcolor="#CCCCCC"> 
              <td width="61%" bgcolor="#CCCCCC"> 
              <div align="right">Desayuno</div></td>
              <td width="39%" bgcolor="#CCCCCC"> 
                <div align="right">
				<?php if ($row[des]=="1") {?>
                  <input name="des" type="checkbox" id="des" value="1" checked><?php }else{?>
				   <input name="des" type="checkbox" id="des" value="1" unchecked><?php }?>
				  
                </div></td>
            </tr>
            <tr bgcolor="#CCCCCC"> 
              <td bgcolor="#CCCCCC"> 
              <div align="right">Almuerzo</div></td>
              <td bgcolor="#CCCCCC"> 
                <div align="right"> 
				<?php if ($row[alm]=="1") {?>
                  <input name="alm" type="checkbox" id="alm" value="1" checked><?php }else{?>
				   <input name="alm" type="checkbox" id="alm" value="1" unchecked><?php }?>
                  
              </div></td>
            </tr>
            <tr bgcolor="#CCCCCC"> 
              <td bgcolor="#CCCCCC"> 
              <div align="right">Cena</div></td>
              <td bgcolor="#CCCCCC"> 
                <div align="right"> 
				<?php if ($row[cen]=="1") {?>
                 <input name="cen" type="checkbox" id="cen" value="1" checked><?php }else{?>
				   <input name="cen" type="checkbox" id="cen" value="1" unchecked><?php }?>
                  
              </div></td>
            </tr>
            <tr bgcolor="#CCCCCC"> 
              <td bgcolor="#CCCCCC"> 
              <div align="right">Alojamiento</div></td>
              <td bgcolor="#CCCCCC"> 
                <div align="right"> 
				<?php if ($row[alo]=="1") {?>
                 <input name="alo" type="checkbox" id="alo" value="1" checked>
                 <?php }else{?>
				  <input name="alo" type="checkbox" id="alo" value="1" unchecked>
				  <?php }?>
                  
              </div></td>
            </tr>
          </table>
          <p><strong>Eliminar Viaticos</strong></p>
          <p><em>&iquest;Desea eliminar estos datos?</em></p>
          <table width="75%" border="0">
            <tr> 
              <td width="25%"> <div align="left">Cedula:</div></td>
              <td width="75%"><input readonly name="cedula" type="text" id="cedula" onkeypress="return acceptchar(event)" value= "<?php echo $row[cedula];?>" >
              * <a href="empleados.php"></a></td>
            </tr>
            <tr> 
              <td width="25%" height="24"> <div align="left">Nombre y Apellido:</div></td>
              <td width="75%" height="24"> <p>
                <input name="nombre" readonly type="text" id="nombre" onkeypress="return acceptchar(event)" value="<?php echo $row[nomb_usuario];?>" >
              *    </p></td>
            </tr>
            <tr> 
              <td width="25%"> <div align="left">Cargo:</div></td>
              <td width="75%"><input name="cargo" readonly type="text" id="cargo" onkeypress="return acceptchar(event)" value= "<?php echo $row[cargo];?>" >
              * </td>
            </tr>
            <tr>
              <td><div align="left">Tipo:</div></td>
              <td><select name="tipo" readonly id="tipo" >
<option value="<? echo $row['id_tabla']?>"><? echo $row['tipo']?></option>
<?php while($obj=pg_fetch_object($resultado3)){?>
<option value="<? echo $obj->id_tabla?>"><? echo $obj->tipo?></option>
<? }//Fin while ?>
</select>
                * </td>
            </tr>
            <tr> 
              <td width="25%"> <div align="left"></div></td>
              <td width="75%">&nbsp;</td>
            </tr>
            <tr> 
              <td width="25%" height="38"> 
                <div align="left">Fecha ida: <font size="-7">(DD/MM/AAAA)</font></div></td>
              <td width="75%" height="38"> 
                <input name="ida" readonly  type="text" id="ida" onKeyPress="return acceptNum(event)" value="<?php echo $row[fecha_ida];?>">
                <select name="di" id="di">
						
				  <option value="1">Ma&ntilde;ana</option>
                  <option value="2">Tarde</option>
                  <option value="3">Noche</option>
                </select>
                * </td>
            </tr>
            <tr> 
              <td width="25%" height="38">Fecha Retorno:&nbsp; <font size="-7">(DD/MM/AAAA)</font></td>
              <td width="75%"> <input name="retorno" readonly type="text" id="retorno" onKeyPress="return acceptNum(event)" value="<?php echo $row[fecha_ret];?>">
                <select name="dr" id="dr">
                  <option value="1">Ma&ntilde;ana</option>
                  <option value="2">Tarde</option>
                  <option value="3">Noche</option>
                </select>
                * </td>
            </tr>
            <tr> 
              <td width="25%">Motivo:&nbsp;</td>
              <td width="75%"> <textarea name="motivo" readonly id="motivo" onKeyPress="return acceptchar(event)"><?php echo $row[motivo];?></textarea>
                * </td>
            </tr>
            <tr> 
              <td>&nbsp;</td>
              <td> Otras Asignaciones</td>
            </tr>
            <tr> 
              <td width="25%">Otra:</td>
              <td width="75%"> <input name="otra1" readonly  type="text" id="otra1" onKeyPress="return acceptchar(event)" value="<?php echo $row[otra1];?>"></td>
            </tr>
            <tr> 
              <td width="25%">Otra:</td>
              <td width="75%"> <input name="otra2" readonly type="text" id="otra2" onKeyPress="return acceptchar(event)" value="<?php echo $row[otra2];?>"></td>
            </tr>
            <tr> 
              <td width="25%" height="23">Observaciones:</td>
              <td width="75%" height="23"> <textarea name="observaciones" readonly id="observaciones" onKeyPress="return acceptchar(event)"><?php echo $row[observaciones];?></textarea></td>
            </tr>
            <tr> 
              <td width="25%">&nbsp;</td>
              <td width="75%"> <input value="Eliminar" type="submit" name="submit">              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </table>
          <p>          
          <p>* Campo requerido
          </tbody> 
</form>
      </div>
    
  </table>
<?php
include("../pie.php");
?>

