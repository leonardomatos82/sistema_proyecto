<?php 
include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
//include("../../utils.php");
$resultado3 = pg_query($con,"SELECT * FROM tabla");

$result = pg_query($con,"SELECT tabla.id_tabla,tabla.tipo,viaticos.id_viatico,viaticos.cedula,usuario.nombre,usuario.telf,viaticos.motivo,viaticos.fecha_ida,viaticos.fecha_ret,viaticos.total,viaticos.otra1,viaticos.otra2,viaticos.observaciones,viaticos.tiempo1,viaticos.tiempo2,viaticos.des,viaticos.alm,viaticos.cen,viaticos.alo,
 viaticos.taxi,viaticos.transporte,viaticos.tasa
 FROM viaticos 
  INNER JOIN usuario ON viaticos.cedula= usuario.cedula_rif 
  INNER JOIN tabla ON viaticos.id_tipo= tabla.id_tabla

 where viaticos.id_viatico='$_GET[id]'");

$id=$_GET[id];

$row=pg_fetch_array($result);
?>
 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 47 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
  </script>  
<?php
include("../../atras.php"); 
 ?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Eliminar Viaticos</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="117">&nbsp;</td>
    <td width="648"><em>&iquest;Desea eliminar estos datos?</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="elim_viatico.php?id=<?=$id?>">
      <table width="103%" border="0">
        <tr>
          <td width="25%"><div align="left">Cedula:</div></td>
          <td width="75%"><input readonly name="cedula" type="text" id="cedula" onkeypress="return acceptchar(event)" value= "<?php echo $row[cedula];?>">
            * <a href="empleados.php"></a></td>
          <td width="19%" rowspan="16"><table width="15%" border="1" align="right">
            <tr bgcolor="#CCCCCC">
              <td width="61%" bgcolor="#CCCCCC"><div align="right">Desayuno</div></td>
              <td width="39%" bgcolor="#CCCCCC"><div align="right">
                  <?php if ($row[des]=="1") {?>
                  <input name="des" type="checkbox" id="des" value="1" checked="checked" />
                <?php }else{?>
                  <input name="des" type="checkbox" id="des" value="1" unchecked="unchecked" />
                <?php }?>
              </div></td>
            </tr>
            <tr bgcolor="#CCCCCC">
              <td bgcolor="#CCCCCC"><div align="right">Almuerzo</div></td>
              <td bgcolor="#CCCCCC"><div align="right">
                  <?php if ($row[alm]=="1") {?>
                  <input name="alm" type="checkbox" id="alm" value="1" checked="checked" />
                <?php }else{?>
                  <input name="alm" type="checkbox" id="alm" value="1" unchecked="unchecked" />
                <?php }?>
              </div></td>
            </tr>
            <tr bgcolor="#CCCCCC">
              <td bgcolor="#CCCCCC"><div align="right">Cena</div></td>
              <td bgcolor="#CCCCCC"><div align="right">
                  <?php if ($row[cen]=="1") {?>
                  <input name="cen" type="checkbox" id="cen" value="1" checked="checked" />
                <?php }else{?>
                  <input name="cen" type="checkbox" id="cen" value="1" unchecked="unchecked" />
                <?php }?>
              </div></td>
            </tr>
            <tr bgcolor="#CCCCCC">
              <td bgcolor="#CCCCCC"><div align="right">Alojamiento</div></td>
              <td bgcolor="#CCCCCC"><div align="right">
                  <?php if ($row[alo]=="1") {?>
                  <input name="alo" type="checkbox" id="alo" value="1" checked="checked" />
                  <?php }else{?>
                  <input name="alo" type="checkbox" id="alo" value="1" unchecked="unchecked" />
                  <?php }?>
              </div></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td width="25%"><div align="left">Nombre y Apellido:</div></td>
          <td width="75%"><p>
              <input readonly name="nombre" type="text" id="nombre" onkeypress="return acceptchar(event)" value="<?php echo $row[nombre];?>">
            * </p></td>
        </tr>
        <tr>
          <td><div align="left">Tipo:</div></td>
          <td><select readonly name="tipo" id="tipo">
              <option value="<? echo $row['id_tabla']?>"><? echo $row['tipo']?></option>
              <?php while($obj=pg_fetch_object($resultado3)){?>
              <option value="<? echo $obj->id_tabla?>"><? echo $obj->tipo?></option>
              <? }//Fin while ?>
            </select>
            * </td>
        </tr>
        <tr>
          <td width="25%"><div align="left"></div></td>
          <td width="75%">&nbsp;</td>
        </tr>
        <tr>
          <td width="25%"><div align="left">Fecha ida: <font size="-7">(DD/MM/AAAA)</font></div></td>
          <td width="75%"><input readonly name="ida" type="text" id="ida" onkeypress="return acceptNum(event)" value="<?php echo $row[fecha_ida];?>" />
              <select readonly name="di" id="di">
                <option value="1">Ma&ntilde;ana</option>
                <option value="2">Tarde</option>
                <option value="3">Noche</option>
              </select>
            * </td>
          </tr>
        <tr>
          <td width="25%">Fecha Retorno:&nbsp; <font size="-7">(DD/MM/AAAA)</font></td>
          <td width="75%"><input readonly name="retorno" type="text" id="retorno" onkeypress="return acceptNum(event)" value="<?php echo $row[fecha_ret];?>" />
              <select readonly name="dr" id="dr">
                <option value="1">Ma&ntilde;ana</option>
                <option value="2">Tarde</option>
                <option value="3">Noche</option>
              </select>
            * </td>
          </tr>
        <tr>
          <td width="25%">Motivo:&nbsp;</td>
          <td width="75%"><textarea readonly name="motivo" id="motivo" onkeypress="return acceptchar(event)"><?php echo $row[motivo];?></textarea>
            * </td>
          </tr>
        <tr>
          <td>&nbsp;</td>
          <td> Otras Asignaciones</td>
          </tr>
        <tr>
          <td>Taxi</td>
          <td><input readonly name="taxi" type="text" id="taxi" onkeypress="return acceptchar(event)" value="<?php echo $row[taxi];?>" /></td>
          </tr>
        <tr>
          <td>Transporte</td>
          <td><input  readonly name="transporte" type="text" id="transporte" onkeypress="return acceptchar(event)" value= "<?php echo $row[transporte];?>" /></td>
          </tr>
        <tr>
          <td>Tasa aerea ida vuelta:</td>
          <td><input  readonly name="tasa" type="text" id="tasa" onkeypress="return acceptchar(event)" value= "<?php echo $row[tasa];?>" /></td>
          </tr>
        <tr>
          <td width="25%">&nbsp;</td>
          <td width="75%">&nbsp;</td>
          </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          </tr>
        <tr>
          <td>Otra:</td>
          <td><input readonly name="otra1" type="text" id="otra1" onkeypress="return acceptchar(event)" value="<?php echo $row[otra1];?>" /></td>
          </tr>
        <tr>
          <td>Otra:</td>
          <td><input readonly name="otra2" type="text" id="otra2" onkeypress="return acceptchar(event)" value="<?php echo $row[otra2];?>" /></td>
          </tr>
        <tr>
          <td>Observaciones:</td>
          <td><textarea readonly name="observaciones" id="observaciones" onkeypress="return acceptchar(event)"><?php echo $row[observaciones];?></textarea></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input value="Eliminar" type="submit" name="submit" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
    <?php
include("../../pie.php"); 
 ?>