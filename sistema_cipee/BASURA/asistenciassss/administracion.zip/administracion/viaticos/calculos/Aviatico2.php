<?php
include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
//include("../../utils.php");
if ($_POST[tipo]==0){ die();}
$resultado3 = pg_query($con,"SELECT * FROM tabla");
$result = pg_query($con,"SELECT * FROM tabla WHERE id_tabla='$_POST[tipo]'");
$row=pg_fetch_array($result);
//$funcion=dias_entre_fechas($_POST[ida],$_POST[retorno])+1;
$funcion=getDateDifference($_POST[ida],$_POST[retorno])+1;

$max=$funcion;
$cont=1;
$subtotal=0;
$total=0;
$tipo=$_POST[tipo];
$tiempo1=$_POST[di];
$tiempo2=$_POST[dr];
$des=$_POST[des];
$alm=$_POST[alm];
$cen=$_POST[cen];
$alo=$_POST[alo];
?>

 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 47 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
  </script>  
<?php
include("../../atras.php"); 
?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Calcular Viaticos</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="117">&nbsp;</td>
    <td width="648"><em>Si esta de acuerdo con los resultados pulse el boton: <strong>Guardar</strong>.</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="insert_viatico.php?tipo=<?=$tipo?>&dias=<?=$max?>&tiempo1=<?=$tiempo1?>&tiempo2=<?=$tiempo2?>&des=<?=$des?>&alm=<?=$alm?>&cen=<?=$cen?>&alo=<?=$alo?>" >
      <p>&nbsp;</p>
      <table width="85%" border="0">
        <tr>
          <td width="13%" nowrap="nowrap">Cedula:</td>
          <td width="29%"><input name="cedula" type="text" id="cedula2" onkeypress="return acceptNum(event)" value= "<?php echo $_POST[cedula];?>" /></td>
          <td width="24%">Nombre y Apellido:</td>
          <td width="34%"><input name="nombre" type="text" id="nombre2" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[nombre];?>" /></td>
        </tr>
        <tr>
          <td height="26" nowrap="nowrap">Cargo:</td>
          <td><input name="cargo" type="text" id="cargo2" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[cargo];?>" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <table width="85%" border="0">
        <tr>
          <td width="14%" height="72">Motivo:&nbsp;</td>
          <td width="33%"><textarea name="motivo" id="motivo" onkeypress="return acceptchar(event)"><?php $cadena=strtoupper($_POST[motivo]); echo $cadena;?></textarea></td>
          <td width="19%">&nbsp;</td>
          <td width="34%">&nbsp;</td>
        </tr>
        <tr>
          <td>Fecha ida:</td>
          <td><input readonly="readonly" name="ida" type="text" id="ida" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[ida];?>" /></td>
          <td>Fecha Retorno:</td>
          <td><input readonly="readonly" name="retorno" type="text" id="retorno" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[retorno];?>" /></td>
        </tr>
      </table>
      <?php
echo "<table align=center cellpadding=1 cellspacing=0  background-color: rgb(255, 255, 255); border =4; WIDTH=100% bgcolor=FFFFFF>";
echo "<tr>";
echo "<td <small style=width:  50px font-weight: bold><b>DIAS</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>_DESAYUNO__</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>__ALMUERZO_</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>____CENA___</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>_ALOJAMIENTO_</b></td>";
echo "<td <small style=width:  50px font-weight: bold><b>__SUBTOTAL_</b></td>";
$taxi=$row[taxi];
$transporte=$row[transporte];
$tasa=$row[tasa];
echo "</tr> ";
while($cont<=$max){
$subsubtotal=0;
echo "<tr align=right> ";

$fecha=$_POST[ida];
echo "<td <small style=width: 50px >$cont</td> ";
$desayuno=$row[desayuno];
$almuerzo=$row[almuerzo];
$cena=$row[cena];
$alojamiento=$row[alojamiento];
if (($_POST[di]==2) && $cont==1) { $desayuno=0;  }
if (($_POST[di]==3) && $cont==1) { $desayuno=0; $almuerzo=0; }

if (($_POST[dr]==1) && $cont==$max){ $almuerzo=0; $cena=0;  }
if (($_POST[dr]==2) && $cont==$max){ $cena=0;  }

if ($_POST[des]==1) {echo "<td <small style=width: 50px >$desayuno</td> ";}
else  {  $desayuno=0;  echo "<td <small style=width: 50px >$desayuno</td> ";}

if ($_POST[alm]==1) {echo "<td <small style=width: 50px >$almuerzo</td> ";}
else  {  $almuerzo=0;  echo "<td <small style=width: 50px >$almuerzo</td> ";}

if ($_POST[cen]==1) {echo "<td <small style=width: 50px >$cena</td> ";}
else  {  $cena=0;  echo "<td <small style=width: 50px >$cena</td> ";}

if ($cont==$max){ $alojamiento=0;  }
if ($_POST[alo]==1) {echo "<td <small style=width: 50px >$alojamiento</td> ";}
else  {  $alojamiento=0;  echo "<td <small style=width: 50px >$alojamiento</td> ";}


$subsubtotal=$subsubtotal+$desayuno+$almuerzo+$cena+$alojamiento;
$subtotal=$subtotal+$subsubtotal;

echo "<td <small style=width: 50px >$subsubtotal</td> ";

?>
      <p align="right"> </p>
      <p align="right">
        <?PHP
echo "</tr> ";
$cont++;}
echo "</table>";
?>
      </p>
      <p align="right">SUB TOTAL:.....
        <input readonly="readonly" name="subtotal" type="text" id="subtotal" onkeypress="return acceptchar(event)" value= "<?php echo $subtotal;?>" />
      </p>
      <table width="44%" border="0">
        <tr>
          <td width="46%">&nbsp;</td>
          <td width="54%">Otras Asignaciones</td>
        </tr>
        <tr>
          <td height="24">Taxi</td>
          <td><input readonly="readonly" name="taxi" type="text" id="taxi" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[taxi];?>" /></td>
        </tr>
        <tr>
          <td>Transporte</td>
          <td><input readonly="readonly" name="transporte" type="text" id="transporte" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[transporte];?>" /></td>
        </tr>
        <tr>
          <td>Tasa aerea ida vuelta:</td>
          <td><input readonly="readonly" name="tasa" type="text" id="tasa" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[tasa];?>" /></td>
        </tr>
        <tr>
          <td>Otra:</td>
          <td><input readonly="readonly" name="otra1" type="text" id="otra1" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[otra1];?>" /></td>
        </tr>
        <tr>
          <td>Otra:</td>
          <td><input readonly="readonly" name="otra2" type="text" id="otra2" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[otra2];?>" /></td>
        </tr>
        <tr>
          <td>Observaciones:</td>
          <td><textarea readonly="readonly" name="observaciones" id="observaciones" onkeypress="return acceptchar(event)"><?php echo $_POST[observaciones];?></textarea></td>
        </tr>
      </table>
      <? $total=$total+$subtotal+$_POST[taxi]+$_POST[transporte]+$_POST[tasa]+$_POST[otra1]+$_POST[otra2]; ?>
      <p align="right">TOTAL:......
        <input readonly="readonly" name="total" type="text" id="total" onkeypress="return acceptchar(event)" value= "<?php echo $total;?>" />
      </p>
      <p align="right"></p>
      <table width="75%" border="0">
        <tr>
          <td width="25%">&nbsp;</td>
          <td width="75%"><input value="Guardar Viatico" type="submit"  name="submit">          </td>
        </tr>
      </table>
      <p>&nbsp;</p>
      </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
    <?php
include("../../pie.php"); 
?> 