<form id="form1" name="form1" method="post" action="Aviatico.php">
  <p>&nbsp;</p>
  <table width="52%" border="2" cellpadding="5">
    <tr>
      <td width="48%" height="33">Cedula de identidad </td>
      <td width="52%"><input name="cedula" onkeypress="return acceptChar(event)" &gt="" type="text" size="15" />
        *</td>
    </tr>
    <tr>
      <td height="33">Nombre y Apellido:</td>
      <td><input name="nombre" onkeypress="return acceptChar(event)" &gt="" type="text" size="15" />
        *</td>
    </tr>
    <tr>
      <td height="33">Cargo:</td>
      <td><input name="cargo" onkeypress="return acceptChar(event)" &gt="" type="text" size="15" />*</td>
    </tr>
    <tr>
      <td height="33">&nbsp;</td>
      <td><input value="Guardar" type="submit" name="submit" /></td>
    </tr>
  </table>
  </form>
<p>&nbsp;</p>
<p>&nbsp;</p>
