<?php
include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
 ?>
  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
  </script>
  
<?php
include("../../atras.php"); 
 ?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Calcular Viaticos</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>Escriba el numero de Cedula:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="../calculos/Aviatico.php">
      <table width="51%" border="0" cellpadding="0">
        <tr>
          <td width="49%" height="33"><div align="center">C&eacute;dula de identidad </div></td>
          <td width="51%"><input name="cedula" onkeypress="return acceptNum(event)" value="V-" type="text" size="15" />
            *</td>
        </tr>
        <tr>
          <td height="33">&nbsp;</td>
          <td><input value="ACEPTAR" type="submit" name="submit" /></td>
        </tr>
      </table>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
<?php
include("../../pie.php"); 
 ?>