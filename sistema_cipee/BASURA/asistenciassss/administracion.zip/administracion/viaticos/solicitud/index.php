<?php 
include("../../config.php");
?>

<table width="670" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="3"><div align="center">
      <p><img src="../../imagenes/banin.png" alt="" width="670" height="70"  /></p>
      <p><img src="../../imagenes/bannertop.png" alt="" width="670" height="159"  /></p>
    </div></td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><font size="4">SOLICITUD DE VIATICOS VIA INTRANET</font></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><img src="../../imagenes/mural1.png" alt="d" width="670" height="5" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2"><div align="right"> <script language="javascript">
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el a�o a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
document.write(nombres_dias[dia_semana] + ", " + dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)

//-->
              </script></div></td>
  </tr>
  <tr>
    <td colspan="2"><em>Escriba El Nombre de Usuario y Clave de acceso </em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
    <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="control/login.php">
      <table width="466" border="0">
        <tr>
          <td width="94"><div align="right">Usuario:</div></td>
          <td width="362"><input name="login"  type="text" size="20" autocomplete=OFF />
            *</td>
        </tr>
        <tr>
          <td><div align="right">Clave :</div></td>
          <td><input  name="password"  type="password" size="20" autocomplete=off />
            *</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><span style="height: 22px; width: 750px;"><font size=4>
            <input value="Entrar" type="submit" name="submit" />
          </font></span></td>
        </tr>
      </table>
      </form>    </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../../imagenes/mural1.png" width="670" height="5" /></div></td>
  </tr>
</table>
<p>&nbsp;</p>
