<?php
//include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
//include("../../utils.php");
$resultado3 = pg_query($con,"SELECT * FROM tabla");
$query="select * from usuario where usuario.cedula_rif='$_POST[cedula]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);
 ?>
 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 47 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
  </script>
  

<table width="670" border="0" align="center" bgcolor="#FFFFFF">
<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><strong>Solicitar Viaticos via INTRANET</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="117">&nbsp;</td>
    <td width="648"><em>Escriba las caracter&iacute;sticas de su solicitud:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="Aviatico2.php">
      <table width="103%" border="0">
        <tr>
          <td width="28%"><div align="left">Cedula:</div></td>
          <td width="53%"><input name="cedula" type="text" id="cedula" onkeypress="return acceptchar(event)" value= "<?php echo $_POST[cedula];?>">
            * </a></td>
          <td width="19%" rowspan="5"></td>
        </tr>
        <tr>
          <td width="28%" height="24"><div align="left">Nombre y Apellido:</div></td>
          <td width="53%" height="24"><p>
              <input name="nombre" type="text" id="nombre" onkeypress="return acceptchar(event)" value= "<?php echo $row[nombre];?>">
            * </p></td>
          </tr>
        
       
        <tr>
          <td width="28%">&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td width="28%" height="38"><div align="left">Fecha ida: <font size="-7">(DD/MM/AAAA)</font></div></td>
          <td width="53%" height="38"><input name="ida" type="text" id="ida" onkeypress="return acceptNum(event)" />
              <select name="di" id="di">
                <option value="1">Ma&ntilde;ana</option>
                <option value="2">Tarde</option>
                <option value="3">Noche</option>
              </select>
            * </td>
          <td width="19%">&nbsp;</td>
        </tr>
        <tr>
          <td width="28%" height="38">Fecha Retorno:&nbsp; <font size="-7">(DD/MM/AAAA)</font></td>
          <td width="53%"><input name="retorno" type="text" id="retorno" onkeypress="return acceptNum(event)" />
              <select name="dr" id="dr">
                <option value="1">Ma&ntilde;ana</option>
                <option value="2">Tarde</option>
                <option value="3">Noche</option>
              </select>
            * </td>
          <td width="19%">&nbsp;</td>
        </tr>
        <tr>
          <td width="28%">Motivo:&nbsp;</td>
          <td width="53%"><textarea name="motivo" id="motivo" cols="70" rows="3" onkeydown="textCounter(this.form.motivo,this.form.remLen,500);" 
				  onkeyup="textCounter(this.form.motivo,this.form.remLen,500);" value="<?php echo $coment1;?>" ><?php echo $coment1;?></textarea>
              <input readonly="readonly" type="text" name="remLen" size="1" maxlength="3" value="500" />
            * </td>
          <td width="19%">&nbsp;</td>
        </tr>
       
        
        <tr>
          <td width="28%">&nbsp;</td>
          <td width="53%">&nbsp;</td>
          <td width="19%">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
       
        <tr>
          <td>Observaciones:</td>
          <td><textarea name="observaciones" id="observaciones" cols="80" rows="3" onkeypress="return acceptchar(event)"></textarea></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input value="Solicitar" type="submit" name="submit" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
  
  
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png"  width="670" height="2" /></div></td>
  </tr>
</table>
  