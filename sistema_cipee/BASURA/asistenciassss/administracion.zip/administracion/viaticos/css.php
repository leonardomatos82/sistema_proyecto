<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>CONTROL DE VIATICOS.php</title>
<style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.style2 {font-size: 36px}
.style3 {	font-size: 9px;
	font-style: italic;
	font-weight: bold;
}
-->
</style></head>
</tr>
<tr>
  <table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="3"><div align="center">
      <p><img src="../imagenes/banin.png" alt="d" width="850" height="70"></p>
      <p><img src="../imagenes/bannertop.png" alt="d" width="850" height="159"></p>
    </div></td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><font size="4">SISTEMA PARA EL CONTROL DE VIATICOS</font></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><FONT Size=2>|<a fontsize=1 href="../menu.php?titulo=<?="MENU PRINCIPAL"?>">Inicio</a> 
    ||<a href="../tabla/menu_tabla.php?titulo=<?="TABLA"?>">Tabla</a> ||<a href="../calculos/menu_viatico.php?titulo=<?="VIATICOS"?>">Viaticos</a> ||<a href="../../usuario/menu_usuario.php?titulo=<?="USUARIOS"?>">Usuarios</a>||<a href="../consulta/listar.php?titulo=<?="OFICIOS"?>">Oficios</a> ||<a href="../consulta/buscar.php?titulo=<?="CONSULTAS"?>">Consultas</a> |</FONT></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<tr>
  
</body>
</html>
