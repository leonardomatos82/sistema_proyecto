<?php
include("../../control/valida.php"); 
include("../css.php");
include("../../config.php");
?>
<style type="text/css">
<!--
.style2 {font-size: 36px}
.style3 {	font-size: 9px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>

<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td><strong>Tabla de Viaticos </strong></td>
    <td><div align="center"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59"><p align="right"><b><font size="2">Seleccione:</font></b></p>
        <p align="right">&nbsp;</p></td>
    <td><div align="center">&nbsp;| <a href="../tabla/Atabla.php?titulo=<?="AGREGAR TABLA"?>">Agregar</a> || <a href="../tabla/ver_modi.php?titulo=<?="MODIFICAR TABLA"?>">Modificar</a> || <a href="../tabla/ver_elim.php?titulo=<?="ELIMINAR TABLA"?>">Eliminar</a> |</div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><a href="manual/MANUAL_viaticos_def.doc"></a><img src="../imagenes/datasheets.gif" width="78" height="50" /><img src="../imagenes/datasheets.gif" width="78" height="50" /><img src="../imagenes/datasheets.gif" width="78" height="50" /></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>