
<?php
//include("../control/valida.php"); 
include("../../css.php");
include("../../config.php");
?>
  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
  </script>
  <? 
  include("../../atras.php");
?>

<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Agregar Tabla de Viaticos</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>Escriba las caracter&iacute;sticas de la tabla de vi&aacute;tico:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="insert_tabla.php">
      <table width="70%" height="128" border="0">
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF"><div align="left">Tipo:</div></td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="tipo" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF"><div align="left">Desayuno:</div></td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><p>
              <input name="desayuno" onkeypress="return acceptNum(event)" type="text" />
            * </p></td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF"><div align="left">Almuerzo:</div></td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="almuerzo" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF"><div align="left">Cena:</div></td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="cena" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF"><div align="left">Alojamiento:</div></td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="alojamiento" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF">Taxi:&nbsp;</td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="taxi" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF">Transporte:&nbsp;</td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="transporte" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF">Tasa:</td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="tasa" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF">Autobus:</td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="autobus" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td width="15%" bordercolor="#000000" bgcolor="#FFFFFF">Vehiculo:&nbsp;</td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input name="vehiculo" onkeypress="return acceptNum(event)" type="text" />
            * </td>
        </tr>
        <tr>
          <td></td>
          <td width="85%" bordercolor="#000000" bgcolor="#FFFFFF"><input value="Guardar" type="submit" name="submit" />
          </td>
        </tr>
        <tr>
          <td></td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
 <? 
  include("../../pie.php");
?>