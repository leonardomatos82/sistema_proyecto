<?php 
include("../../control/valida.php"); 
include("../../css.php");
include("../../config.php");
?>
  <? 
  include("../../atras.php");
?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">SELECCIONE EL REGISTRO</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59"><p align="right">&nbsp;</p>
    <p align="right">&nbsp;</p></td>
    <td><table width="100%" height="48" border="0"  align="center" cellpadding="0" cellspacing="1" >
      <tbody>
      </tbody>
      <tr>
        <td width="100%" height="42" bordercolor="#000000" bgcolor="#FFFFFF">
            <?php
$result = pg_query($con,"SELECT *
 FROM tabla 
 ");

echo "<table align=center cellpadding=1 cellspacing=0 background-color: rgb(255, 255, 255); border =2; WIDTH=100% bgcolor=#FFFFFF >";

 
echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>ID</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>TIPO</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>DES.</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>ALM.</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>CENA</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>ALOJO</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>TAXI</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>TRANSP</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>TASA</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>AUTOBUS</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>PART</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>OPT</b></td>";


echo "</tr> ";
while ($row = pg_fetch_row($result)){
echo "<tr> ";
echo "<td <small style=width: 50px >$row[10]</td> ";
echo "<td <small style=width: 100px >$row[0]</td> ";
echo "<td <small style=width: 50px >$row[1]</td> ";
echo "<td <small style=width: 50px >$row[2]</td> ";
echo "<td <small style=width: 50px >$row[3]</td> ";
echo "<td <small style=width: 50px >$row[4]</td> ";
echo "<td <small style=width: 50px >$row[5]</td> ";

echo "<td <small style=width: 50px >$row[6]</td> ";
echo "<td <small style=width: 50px >$row[7]</td> ";
echo "<td <small style=width: 50px >$row[8]</td> ";
echo "<td <small style=width: 50px >$row[9]</td> ";
?>
            </p>
        </div></td>
        <td><a href="../tabla/Etabla.php?id=<?=$row[10]?>&amp;titulo=<?="SEGURO QUE DESEA ELIMINAR"?>"><img
 style="border: 0px solid ; width: 16px; height: 16px;" alt="d"
 src="../imagenes/b_drop.png"></a></td>
        <?PHP
echo "</tr> ";
}
echo "</table>";
?>
        <? 
  include("../../pie.php");
?>