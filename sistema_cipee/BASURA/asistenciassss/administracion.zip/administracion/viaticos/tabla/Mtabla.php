<?php
include("../../control/valida.php"); 
include("../../css.php");
 include("../../config.php");
?>

  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}

  </script>

<?php 
$sql="select * from tabla";
$result=pg_query($con,$sql);
$nreg= pg_num_rows($result);
$query="select * from tabla where tabla.id_tabla='$_GET[id]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);
?>
  <? 
  include("../../atras.php");
?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Modificar Tabla de Viaticos</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>Edite las caracter&iacute;sticas de la tabla de vi&aacute;tico:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="edit_tabla.php">
      <table width="70%" height="146" border="0">
        <tr>
          <td width="13%"><div align="left">id:</div></td>
          <td width="87%"><input name="id" type="text" id="id" value= "<?php echo $row['id_tabla'];?>" readonly="readonly" />
            * </td>
        </tr>
        <tr>
          <td><div align="left">Tipo:</div></td>
          <td><input name="tipo"  type="text" value= "<?php echo $row['tipo'];?>" />
            * </td>
        </tr>
        <tr>
          <td height="30"><div align="left">Desayuno:</div></td>
          <td height="30"><p>
              <input name="desayuno" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['desayuno'];?>" />
            * </p></td>
        </tr>
        <tr>
          <td><div align="left">Almuerzo:</div></td>
          <td><input name="almuerzo" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['almuerzo'];?>" />
            * </td>
        </tr>
        <tr>
          <td><div align="left">Cena:</div></td>
          <td><input name="cena" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['cena'];?>" />
            * </td>
        </tr>
        <tr>
          <td height="24"><div align="left">Alojamiento:</div></td>
          <td height="24"><input name="alojamiento" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['alojamiento'];?>" />
            * </td>
        </tr>
        <tr>
          <td>Taxi:&nbsp;</td>
          <td><input name="taxi" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['taxi'];?>" />
            * </td>
        </tr>
        <tr>
          <td>Transporte:&nbsp;</td>
          <td><input name="transporte" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['transporte'];?>" />
            * </td>
        </tr>
        <tr>
          <td>Tasa:</td>
          <td><input name="tasa" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['tasa'];?>" />
            * </td>
        </tr>
        <tr>
          <td>Autobus:</td>
          <td><input name="autobus" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['tasa'];?>" />
            * </td>
        </tr>
        <tr>
          <td height="23">Vehiculo:&nbsp;</td>
          <td height="23"><input name="vehiculo" onkeypress="return acceptNum(event)" type="text" value= "<?php echo $row['vehiculo'];?>" />
            * </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input value="Guardar" type="submit" name="submit" />          </td>
        </tr>
      </table>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
  <? 
  include("../../pie.php");
?>