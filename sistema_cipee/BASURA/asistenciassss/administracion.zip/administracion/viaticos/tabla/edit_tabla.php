<?php
 session_start();
//include("../control/valida.php"); 
include("../../css.php");
include("../../config.php");
//include("../../utils.php");

?> 
  <? 
  include("../../atras.php");
?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="../menu.php";" method="post">
      <p align="left">
        <?php
if($_POST[tipo]==""|| $_POST[desayuno]==""|| $_POST[almuerzo]==""||  $_POST[cena]==""  || $_POST[alojamiento]=="" ||     $_POST[taxi]=="" || $_POST[transporte]==""|| $_POST[tasa]==""|| $_POST[autobus]==""|| $_POST[vehiculo]=="" )
		{
		echo"<b>Mensaje: </b>".Escriba_en_los_campos_obligatorios."<br><br>";
		
       	}
	  else 
	   {
	   
	   
	   
	   $sql = "UPDATE tabla SET 
	 tipo='$_POST[tipo]',desayuno='$_POST[desayuno]',almuerzo='$_POST[almuerzo]',cena='$_POST[cena]',
	 alojamiento='$_POST[alojamiento]',taxi='$_POST[taxi]',transporte='$_POST[transporte]',tasa='$_POST[tasa]',
	 autobus='$_POST[autobus]',vehiculo='$_POST[vehiculo]'
	   WHERE id_tabla='$_POST[id]'";
            
       if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error()); } 
       
       echo "Registro N: ",$_POST[id]," modificado";
	     /////////////////////////////
$valor="-Operacion: Modificar -Tabla: Viatico -Registro ID: ".$_POST[id];
        registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////  
       
       
        }
pg_close($con);
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver al Menu" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
    <? 
  include("../../pie.php");
?>