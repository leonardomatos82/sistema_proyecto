<style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
.style2 {font-size: 36px}
.style3 {
	font-size: 7px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>