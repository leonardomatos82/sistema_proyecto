<?php
session_start();
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
?> 
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="menu_chica.php" method="post">
      <p align="left"><br/>
<?php   
if($_POST[fecha_fact]=="" ||
 $_POST[beneficiario]==""|| 
 $_POST[cedula_rif]=="" || 
  $_POST[programa]=="" ||   
 $_POST[nfactura]==""||  
  $_POST[bolivares]=="" || 
 $_POST[concepto]==""  || 
 $_POST[ncaja_chica]=="")
		{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>"; 
       	}
	  else 
	   {
      $estado="PAGADO";
		$fecha=$_POST[fecha_fact];     
	   
	  $sql = "UPDATE caja_chica SET 
	  fecha='$_POST[fecha_fact]',
	  beneficiario='$_POST[beneficiario]',
	  cedula_rif='$_POST[cedula_rif]',
	  nfactura='$_POST[nfactura]',
	  monto_factura='$_POST[bolivares]',
	  concepto='$_POST[concepto]',
	  programa='$_POST[programa]',
	  estado='$estado',
	  id_asignacion_caja_chica='$_POST[ncaja_chica]'
	   WHERE id_caja_chica='$_POST[id]'";
 	
 	
 	
for($x=1; $x<=6; $x=$x+1)
{ 
$partida="partida".$x;
$monto="monto".$x;
 
   
if ($_POST[$partida]== ""  AND  $_POST[$monto]== "")
{}else{
  //  $sqle="DELETE from distribucion_cheque WHERE ncheque='$_POST[numero]'";
   // if (!pg_query($con,$sqle)) { die('Error: ' . pg_result_error()); }
  //  $query2="select * from distribucion_cheque where ncheque='$_POST[numero]'";
  //  $resulta=pg_query($con,$query2);
  //     $row=pg_fetch_array($resulta);  


	//  $sql2="INSERT INTO distribucion_cheque (fecha,ncheque,cod_partida,monto,programa,cod_contable,estado,tipo_f) 
   //    VALUES ('".date("Y-m-d")."','$_POST[numero]','$_POST[$partida]','$_POST[$monto]','$_POST[programa]','$_POST[contable]','$_POST[estado]','$_POST[tipo]')"; 
   //  if (!pg_query($con,$sql2)) { die('Error: ' . pg_result_error()); } 

}	   
 };
	   
	   if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error()); } 
	   
       
echo "Registro_Modificado";
            /////////////////////////////
$valor="-Operacion: Modificar -Caja Chica:  ".$_POST[id];
 registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////         }
 pg_close($con);
 }
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>
