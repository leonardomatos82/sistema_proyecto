<?php
include("../config.php");
include("../control/valida.php"); 

if ($_POST[bolivares]<>0){}
$query2="SELECT * FROM configuracion where id_configuracion='1'";
$result2=pg_query($con,$query2);
$row2=pg_fetch_array($result2);

$query="select *
from caja_chica 
where id_caja_chica='$_GET[ids]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);
include("numero2.php"); 
include("cantidad.php"); 
if($row['id_caja_chica']<1000)
 {$asig="CCH-BNS-0";}
 if($row['id_caja_chica']<100)
 {$asig="CCH-BNS-00";}
  if($row['id_caja_chica']<10)
 {$asig="CCH-BNS-000";}

?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 47 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}

  </script>
   
<p align="left"><img src="../imagenes/bannertop22.png" alt="" width="77%" style="width: 100%; height: 90px;"></p>

<p align="right"><strong>Barinas, 
              <script>
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el año a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
<!-- document.write
document.write (dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
 
</script>
              </strong></p>
             
 <p align="center"><strong>COMPROBANTE DE PAGO POR CAJA CHICA </strong></p>

<table width="617" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
   
    <td height="0" colspan="3"> <div align="center"></div></td>
  </tr>
  
     <td height="23"><FONT SIZE=1><strong>COMPROBANTE Nº: <?php echo $asig.$row['id_caja_chica'];?></strong></FONT></td>
     <tr> 
    <td height="23">YO: <?php echo $row['beneficiario'];?></td>
  </tr>  
   <tr> 
    <td height="23">CI: <?php echo $row['cedula_rif'];?></td>
  </tr> 
  </table>
 
<table width=100% border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">     
     
     <tr>      
    <td height="23"><FONT SIZE=2>He recibido de parte de la Universidad Bolivariana de Venezuela,sede <?php echo $row2['sede'];?> -PORTUGUESA, la cantidad de (<?php echo $row['monto_factura'];?>) <?php echo ($x).$muestra;?>, por concepto de: <?php echo $row['concepto'];?> segun factura  <?php echo $row['nfactura'];?> , de fecha <?php echo $row['fecha'];?></FONT></td>
     </tr>
   </table>
<p>&nbsp;</p>
<table width=100% border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr bordercolor="#CCCCCC"> 
    <td width="154"><strong><font size="1"></font></strong></td>
  <td width="192"><strong><font size="1">ELABORADO POR</font></strong></td>
    <td width="180"><strong><font size="1">REVISADO POR</font></strong></td>
    <td width="180"><strong><font size="1">AUTORIZADO POR</font></strong></td> 
    <td width="50"><strong><font size="1">SELLO</font></strong></td>
    <td width="380"><strong><font size="1">RECIB&Iacute; CONFORME</font></strong></td>
  </tr>
  <tr> 
    <td><font size="1"></font></td>
    <td><font size="1"><?php echo $row2['custodio_chica'];?></font></td>
        <td><font size="1"><?php echo $row2['coordinador_adm'];?></font></td>
          <td><font size="1"><?php echo $row2['coordinador_sede'];?></font></td>
    <td><font size="1"></font></td>
    <td><font size="1"><?php echo $row['beneficiario'];?></font></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
     <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>RIF y/o C.I .<?php echo $row['cedula_rif'];?></td>
    <tr> 
    <td>&nbsp;</td>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>fecha de Recibido</td>
    </tr>

  </tr>
</table>

<tr> 
    <td>&nbsp;</td>
       </tr>
<table width="760" border="1" cellpadding="0" align="center" cellspacing="0" bgcolor="#FFFFFF">  
 
  <tr> 
    <td align="center">ANEXAR FACTURA</td>
       </tr>
  </table>
