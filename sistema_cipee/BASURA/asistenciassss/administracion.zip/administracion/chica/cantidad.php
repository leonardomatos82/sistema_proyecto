<?php
//para el registro contable
include("../config.php");
$rc="select count(id_caja_chica) from caja_chica";
$qrc=pg_query($con,$rc);
$cant_reg=pg_fetch_array($qrc);
$num=$cant_reg[0]+1;
$numerosig=$num;
if ($num<100)
{
$numerosig="CCH-BNS"."0".$num;
}
if ($num<10)
{
$numerosig="CCH-BNS"."00".$num;
}

?>