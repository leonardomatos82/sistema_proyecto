<?php
session_start();
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
?> 
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="menu_chica.php";" method="post">
      <p align="left"><br />
          <?php
$_POST[bolivares]=number_format($_POST[bolivares],2);

if($_POST[fecha_fact]=="" ||
 $_POST[beneficiario]==""|| 
 $_POST[cedula_rif]=="" || 
  $_POST[programa]=="" ||   
 $_POST[nfactura]==""||  
  $_POST[bolivares]=="" || 
 $_POST[concepto]==""  || 
 $_POST[partida1]==""  ||
 $_POST[monto1]==""  ||
 $_POST[ncaja_chica]=="")
		{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>"; 
       	}
	  else 
	   {
	   // $query2="select * from usuario where cedula_rif=$_POST[cedula_rif]";
     //  $result=pg_query($con,$query2);
     //  $row=pg_fetch_array($result);
     //  if ($_POST[cedula_rif]==$row[cedula_rif]) {}
	  //  else 
	//	{
	//	 $sql3="INSERT INTO usuario (cedula_rif,nombre) 
    //   VALUES ('$_POST[cedula_rif]','$_POST[beneficiario]')"; 
	//	pg_query($con,$sql3);
		//}
		$estado="PAGADO";
		$fecha=$_POST[fecha_fact];
	   $sql="INSERT INTO caja_chica (fecha,beneficiario,cedula_rif,nfactura,monto_factura,concepto,programa,estado,id_asignacion_caja_chica) 
       VALUES ('$fecha','$_POST[beneficiario]','$_POST[cedula_rif]','$_POST[nfactura]','$_POST[bolivares]','$_POST[concepto]','$_POST[programa]','$estado', '$_POST[ncaja_chica]')"; 
       
	  	   
for($x=1; $x<=6; $x=$x+1)
{ 
$partida="partida".$x;
$monto="monto".$x;
//$monto=number_format($monto,2);
if ($_POST[$partida]== ""  AND  $_POST[$monto]== "")
{}else{

	  $sql2="INSERT INTO distribucion_caja_chica (fecha,nfactura,cod_partida,monto_factura,programa,estado,id_asignacion_caja_chica) 
       VALUES ('$fecha','$_POST[nfactura]','$_POST[$partida]','$_POST[$monto]','$_POST[programa]','$estado','$_POST[ncaja_chica]')"; 
      if (!pg_query($con,$sql2)) { die('Error: ' . pg_result_error()); } 
}
 };
	   
	   if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error()); } 
	   
       
       echo " Registro  agregado";
            /////////////////////////////
$valor="-Operacion: Agregar -caja chica:  ".$_POST[nfactura];
 registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////  
        }
 pg_close($con);
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>