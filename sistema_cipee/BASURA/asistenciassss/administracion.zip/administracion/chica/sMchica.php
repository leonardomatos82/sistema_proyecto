<?php
include("../control/valida.php"); 
include("../config.php");
include("../css.php");
$val=$_GET[id];
$queryw="select *
from caja_chica 
where id_caja_chica='$val'";
$resultw=pg_query($con,$queryw);
$roww=pg_fetch_array($resultw);

$resultadopart = pg_query($con,"SELECT p_terciaria.codigo_t,p_terciaria.descripcion,distribucion_cheque.cod_partida, p_terciaria.id_p_terciaria,distribucion_cheque.monto
 FROM distribucion_cheque 
  INNER JOIN p_terciaria ON distribucion_cheque.cod_partida= p_terciaria.id_p_terciaria 
where ncheque='$_GET[id]'");
$rowp1=pg_fetch_array($resultadopart );
$resultado1 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado2 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado3 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado4 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado5 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado6 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado = pg_query($con,"SELECT * FROM usuario order by nombre");

?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field, countfield) {
countfield.value = field.value;
}

function comparar(field1,field2,field3,countfield) {



if (field1.value >= countfield.value)
field1.value = "";

}
</script>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="2"><strong>Modificar Comprobante de caja chica</strong></td>
    <td width="73">&nbsp;</td>
  </tr>
  <tr> 
    <td width="60">&nbsp;</td>
    <td width="709"><em>Modifique las caracter&iacute;sticas del Comprobante:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form id="form1" name="form1" method="post" action="edit_chica.php">
        <table width="98%" height="307" border="0" cellpadding="2" cellspacing="0">
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="19%" height="23"> <div align="right"></div></td>
            <td width="81%"> <strong>Barinas, 
              <script>
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el a�o a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
<!-- document.write
document.write (dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
 
</script>
              </strong></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="19%" height="28"> <div align="left"><strong>Cheque N&ordm;:</strong> 
              </div></td>
            <td><strong> 
              <input name="numero" type="text" id="numero4" onKeyPress="return acceptNum(event)" value="<?php echo $roww['ncheque'];?>" size="8" maxlength="8" readonly="readonly" />
              </strong> </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="19%" height="26"> <div align="left"><strong>Monto del cheque:</strong></div></td>
            <td><input  name="bolivares" type="text"  onKeyPress="return acceptNum(event)" value="<?php echo $roww['monto_cheque'];?>" onKeyUp="asignar(this.form.bolivares,this.form.total);"/> 
            </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Beneficiario:</strong></td>
            <td><select name="beneficiario" id="select">
                <option value="<? echo $roww['beneficiario']?>" selected><? echo $roww['beneficiario']?></option>
                <?php while($obj=pg_fetch_object($resultado)){?>
                <option value="<? echo $obj->nombre?>"><? echo $obj->nombre?></option>
                <? }//Fin while ?>
              </select>
            </td>
          </tr>
            <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="26"><strong>Concepto:</strong></td>
            <td><textarea name="concepto" cols="60" id="textarea";"><?php echo $roww['concepto'];?></textarea></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Programa:</strong></td>
            <td><input  name="programa" type="text"   value="<?php echo $roww['programa'];?>" size="50" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Cod Contable:</strong></td>
            <td><input  name="contable" type="text"   value="<?php echo $roww['cod_contable'];?>" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Estado:</strong></td>
            <td><select name="estado">
                <option value="<?php echo $roww['estado'];?>"><?php echo $roww['estado'];?></option>
                <option value="ANULADO">ANULADO</option>
                <option value="PAGADO">PAGADO</option>
              </select></td>
          </tr>
           <tr> 
            <td height="23"><strong>Tipo Fondo:</strong></td>
            <td> <select name="tipo">
               <option value="<?php echo $roww['tipo_f'];?>"><?php echo $roww['tipo_f'];?></option>
                <option value="FONDO MENSUAL">FONDO MENSUAL</option>
                <option value="FONDO ESPECIAL">FONDO ESPECIAL</option>
              </select>
              *</td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF">
            <td height="23">Registro Actual:</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        <p>
          <?php
$result4 = pg_query($con,"SELECT p_terciaria.codigo_t,p_terciaria.descripcion,distribucion_cheque.cod_partida, p_terciaria.id_p_terciaria,distribucion_cheque.monto
 FROM distribucion_cheque 
  INNER JOIN p_terciaria ON distribucion_cheque.cod_partida= p_terciaria.id_p_terciaria 
where ncheque='$_GET[id]'");

 echo "<table align=left cellpadding=1 cellspacing=0 background-color: rgb(255, 255, 255); border =2; WIDTH=640 bgcolor=#FFFFFF >";

echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>PARTIDA PRESUPUESTARIA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>DESCRIPCION</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>MONTO</b></td>";

echo "</tr> ";
while ($row4 = pg_fetch_row($result4)){
echo "<tr> ";
echo "<td <small style=width: 50px >$row4[0]</td> ";
echo "<td <small style=width: 50px >$row4[1]</td> ";
echo "<td <small style=width: 50px >$row4[4]</td> ";
?>
        </p>
        <?PHP
echo "</tr> ";
}
echo "</table>";
?>
<tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
        <p>&nbsp;</p>
        <p>&nbsp;</p><table width="45%" border="0" align="center">
          <tr> 
            <td width="77%"><strong>PARTIDA PRESUPUESTARIA</strong></td>
            <td width="23%"><div align="right"><strong> MONTO</strong></div></td>
          </tr>
          <tr> 
            <td><select name="partida1" id="select6" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado1)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right"> 
                <input name="monto1" type="text" size="10");">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida2" id="partida2" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado2)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
                 </select></td>
            <td><div align="right"> 
                <input name="monto2" type="text" id="monto2" size="10">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida3" id="partida3" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado3)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right"> 
                <input name="monto3" type="text" id="monto3" size="10">
              </div></td>
          </tr>
          <tr> 
            <td> <div align="left">
                <select name="partida4" id="select" >
                  <option value="" selected>-- Seleccione --</option>
                  <?php while($obj=pg_fetch_object($resultado4)){?>
                  <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                  </option>
                  <? }//Fin while ?>
                </select>
              </div></td>
            <td><div align="right">
                <input name="monto4" type="text" id="monto4" size="10">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida5" id="select2" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado5)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right">
                <input name="monto5" type="text" id="monto5" size="10">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida6" id="select3" >
                <option value="" selected>-- Seleccione --</option>
                 <?php while($obj=pg_fetch_object($resultado6)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right">
                <input name="monto6" type="text" id="monto6" size="10">
              </div></td>
          </tr>
          <tr>
            <td><div align="right"><strong>TOTAL</strong></div></td>
            <td><div align="right">
                <input name="total" type="text" value="<?php echo $roww['monto_cheque'];?>" size="10" readonly="readonly">
              </div></td>
          </tr>
        </table>
        <p align="center"><strong>
          <input value="EDITAR CHEQUE" type="submit" name="submit2" />
          </strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form></td>
    <td>&nbsp;</td>
  </tr>
 

