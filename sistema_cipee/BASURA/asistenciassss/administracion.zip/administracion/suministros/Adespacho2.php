<?php	
//include("../control/valida.php"); 
include("../config.php");
include("../css.php");
$guardar="TERMINAR";
$resultado1 = pg_query($con,"SELECT * FROM departamento order by nombre_departamento");
if($_POST[submit1]){
$cont=$_GET[id];
$cont--;
$_GET[id]=$cont;
//echo "eliminar :".$cont;
$ruta="Adespacho2.php?id=$cont";
}
if($_POST[submit2]){
$cont=$_GET[id];
$cont++;
$_GET[id]=$cont;
//echo "agregar :".$cont;
$ruta="Adespacho2.php?id=$cont";
}
if($_POST[submit3]){
$cont=$_GET[id];
//echo "Guardar :".$cont;
$guardar="GUARDAR";
$ruta="insert_despacho.php?id=$cont";
}
if($_POST[departamento]!=""){
$resultado4 = pg_query($con,"SELECT * FROM departamento where id_departamento=$_POST[departamento]");
 $cant_reg4=pg_fetch_array($resultado4);
}
?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field, countfield) {
countfield.value = field.value;
}

function comparar(field1,field2,field3,countfield) {
if (field1.value >= countfield.value)
field1.value = "";

}
  </script>
 
 <?php
include("../atras.php"); 
 ?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="2"><strong>Agregar Material o suministro</strong></td>
    <td width="73">&nbsp;</td>
  </tr>
  <tr> 
    <td width="60">&nbsp;</td>
    <td width="709"><em>Escriba las caracter&iacute;sticas del Material o suministro:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form id="form1" name="form1" method="post" action="<? echo $ruta; ?>">
        <table width="98%" height="150" border="0" cellpadding="2" cellspacing="0">
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="23"> <div align="right"></div></td>
            
          </tr>
           <tr> 
             <td width="21%" height="28"> <div align="left"><strong>Fecha:</strong> 
            <td width="70%"><input autocomplete=OFF name="fecha_fact" type="text" id="fecha_fact" value="<?php echo $_POST[fecha_fact];?>"  size="15" >
              * (dd-mm-yyyy)</td>
          </tr>
             <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="26"> <div align="left"><strong>Recibe :</strong></div></td>
            <td><input  size="50" name="recibe" type="text"   value="<?php echo $_POST[recibe];?>"  /> 
            </td>
          </tr>
                 </tr>          
             <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="26"> <div align="left"><strong>Departamento :</strong></div></td>
                 <td>
                <select name="departamento" id="departamento" >
                <option value="<? echo $cant_reg4[1]?>" selected><? echo $cant_reg4[0]?></option>
                <?php while($obj=pg_fetch_object($resultado1)){?>
                <option value="<? echo $obj->id_departamento?>"> <? echo $obj->nombre_departamento?> 
                </option>
                <? }//Fin while ?>
              </select>            </td>
          </tr>           
          
    </table>
        </table>
    
 <table width="40%" border="0" align="center" bgcolor=SILVER>
<tr>
<td>MATERIALES</td>
<td>PRESENTACION</td>
<td>CANTIDAD</td>

</tr>
<?php
for($x=1; $x<=$_GET[id]; $x++)
{ 
$resultado2 = pg_query($con,"SELECT * FROM material where existencia>0 order by descripcion");

 $cont++;
$partida="partida".$x;
$cantidad="cantidad".$x;
$presentacion="presentacion".$x;
if($_POST[$partida]!=""){
$resultado3 = pg_query($con,"SELECT * FROM material where id_material=$_POST[$partida]");
 $cant_reg2=pg_fetch_array($resultado3);
}

//echo $_POST[$partida];
echo "<tr>"; 
echo "<td><select name=$partida id=$partida >";

?>

<option value="<? echo $cant_reg2[5]?>" selected><? echo $cant_reg2[1]?></option>
<?
while($obj=pg_fetch_object($resultado2)){
?>
<option value="<? echo $obj->id_material;?>"><? echo $obj->descripcion; ?></option>
<?
echo "</option>";
}//Fin while 
echo "</select></td>";
echo "</div></td>";
echo "<td> <select name=$presentacion>";
echo "<option value=$_POST[$presentacion]>$_POST[$presentacion]</option>";
echo "<option value=UNIDAD>UNIDAD</option>";
echo "<option value=CAJA>CAJA</option>";
echo "<option value=RESMA>RESMA</option>";
echo "<option value=PAQUETE>PAQUETE</option>";
echo "</select></td>";
echo "<td><div align=right><input name=$cantidad type=text  id=$cantidad size=5 value=$_POST[$cantidad] >";
echo "<td>";
//echo "<td>";
//  echo "<input value=X type=submit name=submit4 />";
//  echo "</td>";
echo "</tr>";

}
echo "<tr>";
echo "<td></td>";
echo "<td>";
  echo "<input value=ELIMINAR type=submit name=submit1 />";
  echo "</td>";
echo "<td>";
  echo "<input value=AGREGAR type=submit name=submit2 />";
  echo "</td>";  
  echo "</tr>";
?> 
          
             </table>
           <td>&nbsp;</td>          
           <td>&nbsp;</td>
          <tr> 
          <td ></td>
            <td width="10%"><div align="center"><strong> 
               
                <input value="<? echo $guardar; ?>" type="submit" name="submit3" />
                </strong></div></td>
            
          </tr>
             </form></td>
          
    <td>&nbsp;</td>
  </tr>
 <?php
include("../pie.php"); 
 ?>
