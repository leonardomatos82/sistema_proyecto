<?php
echo"<table cellpadding=1 cellspacing=2 border=0 width=480>
<tr><td align=right style='border-bottom:1px solid #990000'><font class=normal color=#990000>RESE�A UNIVERSIDAD BOLIVARIANA DE VENEZUELA</font></td></tr>
<tr><td height=10></td></tr>
<tr><td align=justify><font class=normal>La Educaci�n Superior en Venezuela se hab�a convertido en el privilegio al que acced�an minor�as de la poblaci�n del pa�s y de la que se exclu�a a una gran cantidad de bachilleres con el potencial suficiente para desarrollar un sinn�mero de actividades profesionales. Consecuencia de un sistema injusto, clasista, que ha brindado el conocimiento a peque�os grupos, haciendo de �ste, una pertenencia utilizada en muchos casos para el provecho personal, privado, la exclusi�n se transforma a su vez en dominaci�n y reproducci�n de los sistemas pol�ticos que as� la conciben y financian, profundizando as� las brechas y enormes diferencias sociales. Visto este panorama en cifras, unos 400 mil bachilleres, se convirtieron en \"poblaci�n flotante\".<br><br>
 Luego de derrotado el Paro Petrolero de 2002, el Presidente Ch�vez decreta la creaci�n de la UBV y as� se transforman en universidades los que eran edificios de PDVSA. El de los Chaguaramos, es hoy la sede Caracas. La educaci�n superior en Venezuela toma otro rumbo de manos de la UBV y la Misi�n Sucre, quiere vincularse con la comunidad, formar profesionales integrales, formar valores, decididamente transformar la sociedad para transitar hacia la, paz, la justicia, la libertad. 
</font></td></tr>
</table>";
?>