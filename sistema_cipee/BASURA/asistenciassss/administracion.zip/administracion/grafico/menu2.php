<?php
echo"<table cellpadding=0 cellspacing=0 border=0 width=130>
<tr><td>
<table  cellpadding=0 cellspacing=0>
<tr><td bgcolor=#990000 align=center style='border-bottom:1px solid #990000' width=115><font class=boton color=#ffffff><b>Enlaces de Interes</b></td><td width=15 height=15><img src=images/conner6.jpg></td></tr>
<tr><td height=1 bgcolor=#878787 colspan=2></td></tr>
</table>
</td></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.ubv.edu.ve target='_blank'><img width=55 style='border:none' src=images/logo_ubv.gif></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.misionsucre.gov.ve target='_blank'><img width=50 style='border:none' src=images/ms.gif></td></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.fgma.gov.ve target='_blank'><img width=110 style='border:none' src=images/funda_ayacucho.jpg></td></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.fames.gov.ve target='_blank'><img width=110 style='border:none' src=images/fames.jpg></td></tr>
<tr><td></td></tr>

</table>";
?>