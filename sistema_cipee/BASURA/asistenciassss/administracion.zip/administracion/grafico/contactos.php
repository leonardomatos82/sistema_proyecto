<?php
echo"<table cellpadding=0 cellspacing=0 border=0 width=100%>
<tr><td>
<table cellpadding=0 cellspacing=0 width=100%>
<tr><tr><td with=15 height=20><img src=images/conner5.jpg></td><td align=center width=100% bgcolor=#990000><font class=boton color=#ffffff><b>CONTACTOS DE CONTROL DE ESTUDIO</b></td></tr>
<tr><td height=1 colspan=2 bgcolor=#878787></td></tr>
</table>
</td></tr>

<tr><td style='padding:2px' bgcolor=#fafafa><font class=boton><U><b>ARAGUA, CARABOBO, GU�RICO Y COJEDES:</b></U><br>
DIRECCI�N: AV. BOLIVAR OESTE, SECTOR LA ROMANA, GRUPO C #13, DIAGONAL A LA ESCUELA TECNICA DEL EJERCITO<br>
TEFELFONOS: 0412-8448542</td><tr>

<tr><td style='padding:2px'><font class=boton><U><b>BARINAS, PORTUGUESA:</b></U><br>
DIRECCI�N: SECTOR LOS POZONES  URB. PEDRO BRICE�O MENDEZ, EDIF. ALMAGUARN, DETRAS DEL DESTACAMENTO 14 DE LA GUARDIA NACIONAL.<br>
TEFELFONOS: 0273-5460129 / 0424-5209969</td><tr>

<tr><td style='padding:2px' bgcolor=#fafafa><font class=boton><U><b>BOLIVAR:</b></U><br>
DIRECCI�N: CIUDAD BOLIVAR, AV. GERMANIA EDIFICIO UBV (ANTIGUA CVG).<br>
TEFELFONOS:0285-6327445 / 0285-6325723</td><tr>

<tr><td style='padding:2px'><font class=boton><U><b>DISTRITO FEDERAL, MIRANDA Y APURE:</b></U><br>
DIRECCI�N:AV. LEONARDO DA VINCI, EDIFICIO UBV, LOS CHAGUARAMOS.<br>
TEFELFONOS:212-6063590 / 0212-6063731</td><tr>

<tr><td style='padding:2px' bgcolor=#fafafa><font class=boton><U><b>FALCON, LARA, YARACUY:</b></U><br>
DIRECCI�N:PUNTO FIJO, VIA REFINERIA CARDON, ANTIGUO EDIFICIO CIED.<br>
TEFELFONOS:0269-5110465</td><tr>

<tr><td style='padding:2px'><font class=boton><U><b>MONAGAS, SUCRE, NUEVA ESPARTA, ANZOATEGUI Y DELTA AMACURO:</b></U><br>
DIRECCI�N:AV. BOLIVAR, ANTIGUA BRIGADA DE CAZADORES, FRENTE A LA REDOMA JUANA LA AVANZADORA.<br>
TEFELFONOS:0291-3000902 / 0291-3000901</td><tr>

<tr><td style='padding:2px' bgcolor=#fafafa><font class=boton><U><b>TACHIRA:</b></U><br>
DIRECCI�N: CIUDAD SAN CRIST�BAL, CALLE 12 ENTRE CARRERAS 7 Y 8 EDIFICIO SAN GABRIELE.<br>
TEFELFONOS: 0414-9305984</td><tr>

<tr><td style='padding:2px'><font class=boton><U><b>VALLES DEL TUY:</b></U><br>
DIRECCI�N:<br>
TEFELFONOS:</td><tr>

<tr><td style='padding:2px' bgcolor=#fafafa><font class=boton><U><b>ZULIA:</b></U><br>
DIRECCI�N:<br>
TEFELFONOS:</td><tr>
</table>";
?>