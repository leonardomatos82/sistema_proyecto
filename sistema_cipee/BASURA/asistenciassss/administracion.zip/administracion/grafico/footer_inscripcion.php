<?php
echo"</td></tr>
<tr><td height=15 bgcolor=#990000 class=celda_menu colspan=2>
<font color=#ffffff class=boton>Universidad Bolivariana de Venezuela - Copyleft� 2007 - Caracas Venezuela, edificio UBV, Los Chaguaramos. Telf. +58(212)606.3590/3731</font></td></tr>
</table></body></html>";
?>