<?php
echo"<tr><td height=15 bgcolor=#990000 class=celda_menu colspan=2 align=center>
<font color=#ffffff class=boton>Universidad Bolivariana de Venezuela - Copyleft� 2007 - Caracas Venezuela</font></td></tr>
</table></body></html>";
?>