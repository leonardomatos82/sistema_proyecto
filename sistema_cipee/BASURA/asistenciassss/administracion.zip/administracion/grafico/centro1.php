<?php
echo"<table cellpadding=1 cellspacing=1  border=0 width=480 height=100% bgcolor=#f0f0f0>
<tr><td valign=top height=40><font class=titulo1><b>SISTEMA UNICO DE REGISTRO ACADEMICO DE LA UNIVERSIDAD BOLIVARIANA DE VENEZUELA</td></tr>
<tr><td align=justify valign=top><font class=normal>Este sistema creado en el a�o 2007, permitir� controlar el ingreso, prosecusi�n y egreso de los estudiantes de la UBV.</font></td></tr>
</table>";
?>