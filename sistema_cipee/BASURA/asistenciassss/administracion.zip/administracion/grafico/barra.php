<?
$anchura1=100;
$anchura2=40;
$anchura3=80;
?>

<p>Gráfico Vertical
<table border=0 cellspacing=0 cellpadding=0>
	<tr>

		<td valign=bottom>
			<img src="cuadro_rojo.gif" width=20 height=<?echo $anchura1?>>
		</td>
		<td width=5></td>
		<td valign=bottom>
			<img src="cuadro_verde.gif" width=20 height=<?echo $anchura2?>>
		</td>
		<td width=5></td>
		<td valign=bottom>

			<img src="cuadro_azul.gif" width=20 height=<?echo $anchura3?>>
		</td>
	</tr>
</table>