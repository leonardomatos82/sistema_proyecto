<?php
$contactos=$_POST[contactos];
if($contactos==1)
 include('includes/contactos.php');
else
 echo"<table cellpadding=0 cellspacing=0 width=450 border=0>
<tr><td style=padding:4px' align=justify><font class=normal color=#990000>Bienvenido, sur@ubv es el sistema que permitir� controlar el ingreso, prosecusi�n y egreso de los estudiantes de la Universidad Bolivariana de Venezuela.</font><br></td></tr>
<tr><td align=center valign=top><img src=images/mapa.jpg></td></tr>
<tr><td height=10></td></tr>
</table>";
?>