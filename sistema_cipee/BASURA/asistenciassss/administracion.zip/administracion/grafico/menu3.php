<?php
echo"<table cellpadding=0 cellspacing=1 border=0 width=130 style='border-left:1px solid #990000' height=100%>
<tr><td height=15 bgcolor=#990000 align=center style='border-bottom:1px solid #990000'><font class=normal color=#ffffff>Enlaces de Interes</td></tr>
<tr><td height=10></td></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.ubv.edu.ve target='_blank'><img width=50 style='border:none' src=images/logo_ubv.gif></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.misionsucre.gov.ve target='_blank'><img width=50 style='border:none' src=images/ms.gif></td></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.fgma.gov.ve target='_blank'><img width=110 style='border:none' src=images/funda_ayacucho.jpg></td></tr>
<tr><td align=center style='padding:2px' height=60><a href=http://www.fames.gov.ve target='_blank'><img width=110 style='border:none' src=images/fames.jpg></td></tr>
<tr><td></td></tr>
</table>";
?>