<?php
include("control/valida.php"); 
include("css.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
  <title>menu_Principal</title>

</head>

<body>


<br>

<div style="text-align: center;"><big style="font-weight: bold;">Menu Principal<br>

</big>
<big style="font-weight: bold;"><br>

</big>