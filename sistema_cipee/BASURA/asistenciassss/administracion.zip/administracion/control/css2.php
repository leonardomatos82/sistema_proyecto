<style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.style2 {font-size: 36px}
.style3 {
	font-size: 9px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
  <title>css.php</title>


</head>
<body>

<div style="text-align: center;">
<div style="text-align: center;">
    <table width="760" border="0" align="center" bgcolor="#FFFFFF">
      <tr> 
        <td colspan="3"><div align="center"> 
            <p><img src="../imagenes/banin.png" alt="" width="760" height="70"></p>
            <p><img src="../imagenes/bannertop.png" alt="" width="760" height="159"></p>
          </div></td>
      </tr>
      <tr> 
        <td width="149">&nbsp;</td>
        <td width="584">&nbsp;</td>
        <td width="77">&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td><div align="center"><font size="4">USTED NO TIENE PERMISOS PARA ACCEDER A ESTE MODULO</font></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td colspan="3"><div align="center"><img src="imagenes/mural1.png" width="760" height="2" /></div></td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td><div align="center"><FONT Size=2> |<a href="../menu.php"> <font size="5">Atras</font></a> 
            |</FONT></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td><div align="center"></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td height="59"><p align="right">&nbsp;</p>
          <p align="right">&nbsp;</p></td>
        <td><div align="center"><span class="style2"><img src="../imagenes/candado.jpg"  width="210" height="160" /></span></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td><div align="center"><a href="manual/MANUAL_viaticos_def.doc"></a><span class="style3">Versi&oacute;n 
            1.0 </span></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
        <td>&nbsp;</td>
        <td><div align="center"></div></td>
        <td>&nbsp;</td>
      </tr>
      <tr> 
       <td colspan="3"><div align="center"><img src="imagenes/mural1.png" width="760" height="2" /></div></td>
      </tr>
    </table>
    
  </div>
</div>

</body>
</html>
