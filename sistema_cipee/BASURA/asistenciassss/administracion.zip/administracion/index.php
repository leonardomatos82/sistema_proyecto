<?php 
include("config.php");
include("utils.php");
include("style.php"); 
include("tabla.php"); 
?>
<script language="javascript">
var foco = {
	ini : function()
	{
		if (0 in document.form1) {
			var f=document.form1[0];
			f.login.focus();
		}	
	}
}
</script>
  <body onload="document.form1.login.focus()"></body>
<!-- Main -->
<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
   
  <tr>
    <th width="210" scope="col"><div id="col" class="noprint">
      <div id="col-in">
        <hr class="noscreen" />
        <!-- Category -->
        <h3 align="center" class="style10" >SESION DE USUARIO</h3>
          <?php
		  if ($_SESSION["login"]=='') {
		  ?>
        <form name="form1" method="post" action="control/login.php">
          <div align="justify">
            <p>Usuario
                      <input name="login" type="text" size="10" maxlength="30" autocomplete=OFF/>
                      <br/>
                      <br/>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Clave <strong>
                <input name="password" type="password" size="10" maxlength="30" autocomplete=OFF />
              </strong></p>
            <p align="center">
              <input name="Enter" type="submit" id="Enter" value="Entrar" />
            </p>
            <p align="center"><img src="imagenes/security.png" alt="" width="70" height="50" /> </p>
          </div>
        </form>
        <div align="center"> <span class="style4"> </span>
              <?php
		} else {
		//echo $_SESSION["login"] . " logout";
		?>
              <form action="control/desconectar.php" method="post">
                <input name="SALIR" type="submit" value="SALIR"/>
              </form>
               
     <h3 align="center" class="style10"><marquee>Sistema SICAF</marquee></h3>
          <?php
			}
			?>
       
      <!-- /col-in -->
    </div></th>
    <th width="566" bgcolor="#FFFFFF" scope="col"><div align="left"><!-- InstanceBeginEditable name="Cuerpo" -->
      <h1 align="left" class="style28">
        <?php
		  if ($_SESSION["login"]=='') {
		  ?>
      </h1>
      <p align="left" class="style28">&nbsp;</p>
      <p align="center" class="style28"><img src="imagenes/heading.jpg" alt="" width="340" height="270" />
        <?php
		} else {
		?>
        <table width="550" border="0" cellspacing="0" cellpadding="0">
         <tr>
          <td><div align="center"><span class="style1"><span class="style37">Bienvenido(a) al sistema</span></span></div></td>
        </tr>
        <tr>
          <td><div align="center"><span class="style1"><span class="style37">Men&uacute; de Inicio </span></span></div></td>
        </tr>
        <tr>
          <td><div align="center">
            <p class="style37"><span class="style28"><img src="imagenes/heading.jpg" alt="" width="340" height="270" /></span></p>
            <p class="style37">&nbsp;</p>
            <p class="style38"><font size="2"><a href="">&quot;Manual de Usuario&quot; </a></font></p>
          </div></td>
        </tr>
      </table>
      <p align="center" class="style1">
        <?php
			}
			?>
        &nbsp;</p>
      <!-- InstanceEndEditable --></div></th>
  </tr>

<!-- InstanceEnd -->
<tr> 
    <td>&nbsp;</td>
    <td> <marquee direction="left" onmouseout="this.start()" onmouseover="this.stop()">
      Universidad Bolivariana de Venezuela|Ministerio del Poder Popular para la Educacion Superior </marquee></td>
    </tr>
</table>
<p>&nbsp; </p>

<table width="770" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
<tr> 
 <td>&nbsp;</td>
  <td>&nbsp;</td>
 <td>
</td>
</td>
   </tr>
 </table>
</body>
    <? include("pie.php"); ?>
 

</html>
