<?php
include("../css.php");
include("../config.php");
include("../utils.php");

 formato_numero(44.67876); 

 ?>