<?php 

phpinfo();
?>