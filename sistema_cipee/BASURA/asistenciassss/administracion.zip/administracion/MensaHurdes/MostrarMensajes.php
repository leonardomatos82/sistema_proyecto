<?php
//////////////////////////////////////////////////////
//
// MensaHurdes (beta)V. 2007 1.0 
// 
// �ltima Modificaci�n: 12-Diciembre-2006
// www.MensaHurdes.es.mw
// mensahurdes.iespana.es
//Copyright (C) 2006  Hurdes: hurdes@gmail.com
//
////////////////////////////////////////////////////////////////////////////////////////////////////
// Este programa es Software Libre; Usted puede redistribuirlo y/o modificarlo 
//bajo los t�rminos de la GNU Licencia P�blica General (GPL) tal y como ha sido 
//p�blicada por la Free Software Foundation; o bien la versi�n 2 de la Licencia, 
//o (a su opci�n) cualquier versi�n posterior.
// Este programa se distribuye con la esperanza de que sea �til, pero SI NINGUNA GARANT�A.
///////////////////////////////////////////////////////////////////////////////////////////////////
?>
<html>
<head>
   <title>MensaHurdes</title> 
<?
  // Cargando Configuraci�n
 $conf = file("conf.php");
 $conf[0] = "";
 eval(join("",$conf));
  echo "<meta http-equiv='Refresh' content='".$tiempo."'>";
?>
<style type="text/css">
<!--
.Estilo2 {color: #33FF99}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<table border="0" cellpadding="0" cellspacing="0" bgcolor="<? echo $fondotabla ?>" style=" text-decoration:none; border-left: 1px solid <? echo $bordetabla ?>; border-right: 1px solid <? echo $bordetabla ?>; border-top: 1px solid <? echo $bordetabla ?>; border-bottom: 1px solid <? echo $bordetabla ?>;" width="100%" height="100%"><tr>

				<span class="Estilo2"></font>				</span>
</td></tr>
<?
// Leemos los mensajes
$archivo = file("Mensajes.txt");
$lineas = count($archivo);
 for ($i = 0; $i < $lineas; $i++) {
 	$total .= $archivo[$i]; 
 }
$mensajes = explode("##",$total);
		
?>
<td class="Texto" align="center" valign="top">
		<table border="0" cellpadding="2" cellspacing="0" width="100%">
		
<?
// Mostramos mensajes

for ($i = $lineas-1; $i >= 0; $i--){
   if ($i % 2 == 0) $fondocelda = $cpar; else $fondocelda = $cimpar;
?>
<tr><td style="color:#CC3366;font-size: 10px; font-style: normal; font-family: verdana; " bgcolor="<?=$fondocelda; ?>" style="border-bottom: 1px solid <? echo $bordetabla ?>"> 
<?
echo $mensajes[$i]; 
?>
</td></tr>
<?
echo "\n"; 
}
$i++;
if ($i % 2 == 0) $fondocelda = $cpar; else $fondocelda = $cimpar;
?>
<tr><td style="color:#CC3366;font-size: 10px; font-style: normal; font-family: verdana; " bgcolor="<?=$fondocelda; ?>" style="border-bottom: 1px solid <? echo $bordetabla ?>"> 
<?
 // �ltimo mensaje
 $mensaje="";
 echo $mensaje;
?>
 </td></tr>
</td></tr></table>
</td></tr></table>
</body></html>
