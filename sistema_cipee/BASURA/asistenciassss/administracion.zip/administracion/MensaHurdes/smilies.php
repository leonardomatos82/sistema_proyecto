<?php
//////////////////////////////////////////////////////
//
// MensaHurdes (beta)V. 2007 1.0 
// 
// �ltima Modificaci�n: 12-Diciembre-2006
// www.MensaHurdes.es.mw
// mensahurdes.iespana.es
//Copyright (C) 2006  Hurdes: hurdes@gmail.com
//
////////////////////////////////////////////////////////////////////////////////////////////////////
// Este programa es Software Libre; Usted puede redistribuirlo y/o modificarlo 
//bajo los t�rminos de la GNU Licencia P�blica General (GPL) tal y como ha sido 
//p�blicada por la Free Software Foundation; o bien la versi�n 2 de la Licencia, 
//o (a su opci�n) cualquier versi�n posterior.
// Este programa se distribuye con la esperanza de que sea �til, pero SI NINGUNA GARANT�A.
///////////////////////////////////////////////////////////////////////////////////////////////////
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<head>
<title>MensaHurdes</title>	
<link rel="stylesheet" type="text/css" href=" style.css">
<link REL="STYLESHEET" HREF=" estilo.css" TYPE="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css">
<!--
body {
	background-color: #FF9966;
}
-->
</style></head>
<BODY>
<table border="0" cellpadding="5" cellspacing="0" width="100%" height="100%" style="border: 1px solid <? echo $bordetabla; ?>"><tr><td align="center" width="50%">
<img src="smilies/0001.gif" alt=":0001"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:0001</td></tr><tr><td align="center"> 
<img src="smilies/0004.gif" alt=":0004"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:0004</td></tr><tr><td align="center"> 
<img src="smilies/0005.gif" alt=":0005"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:0005</td></tr><tr><td align="center"> 
<img src="smilies/0006.gif" alt=":0006"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:0006</td></tr><tr><td align="center"> 
<img src="smilies/0007.gif" alt=":0007"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:0007</td></tr><tr><td align="center"> 
<img src="smilies/153.bmp" alt=":153"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:153</td></tr><tr><td align="center"> 
<img src="smilies/153.gif" alt=":153"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:153</td></tr><tr><td align="center"> 
<img src="smilies/167.gif" alt=":167"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:167</td></tr><tr><td align="center"> 
<img src="smilies/17758.gif" alt=":17758"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:17758</td></tr><tr><td align="center"> 
<img src="smilies/223.GIF" alt=":223"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:223</td></tr><tr><td align="center"> 
<img src="smilies/234.bmp" alt=":234"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:234</td></tr><tr><td align="center"> 
<img src="smilies/244.GIF" alt=":244"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:244</td></tr><tr><td align="center"> 
<img src="smilies/283.GIF" alt=":283"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:283</td></tr><tr><td align="center"> 
<img src="smilies/357.GIF" alt=":357"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:357</td></tr><tr><td align="center"> 
<img src="smilies/46.GIF" alt=":46"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:46</td></tr><tr><td align="center"> 
<img src="smilies/819.gif" alt=":819"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:819</td></tr><tr><td align="center"> 
<img src="smilies/aliean.gif" alt=":aliean"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:aliean</td></tr><tr><td align="center"> 
<img src="smilies/alien.jpg" alt=":alien"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:alien</td></tr><tr><td align="center"> 
<img src="smilies/ardilla.gif" alt=":ardilla"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:ardilla</td></tr><tr><td align="center"> 
<img src="smilies/besitodeamor.bmp" alt=":besitodeamor"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:besitodeamor</td></tr><tr><td align="center"> 
<img src="smilies/burger.bmp" alt=":burger"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:burger</td></tr><tr><td align="center"> 
<img src="smilies/caballo.bmp" alt=":caballo"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:caballo</td></tr><tr><td align="center"> 
<img src="smilies/cerdo.bmp" alt=":cerdo"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:cerdo</td></tr><tr><td align="center"> 
<img src="smilies/corazon.bmp" alt=":corazon"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:corazon</td></tr><tr><td align="center"> 
<img src="smilies/corazonlatiendo.gif" alt=":corazonlatiendo"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:corazonlatiendo</td></tr><tr><td align="center"> 
<img src="smilies/enamorado.gif" alt=":enamorado"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:enamorado</td></tr><tr><td align="center"> 
<img src="smilies/enfadado.bmp" alt=":enfadado"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:enfadado</td></tr><tr><td align="center"> 
<img src="smilies/fresa.gif" alt=":fresa"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:fresa</td></tr><tr><td align="center"> 
<img src="smilies/fuck5.GIF" alt=":fuck5"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:fuck5</td></tr><tr><td align="center"> 
<img src="smilies/fumaor.GIF" alt=":fumaor"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:fumaor</td></tr><tr><td align="center"> 
<img src="smilies/guau.jpg" alt=":guau"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:guau</td></tr><tr><td align="center"> 
<img src="smilies/Hasta_los_huevos.gif" alt=":Hasta_los_huevos"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:Hasta_los_huevos</td></tr><tr><td align="center"> 
<img src="smilies/helado.bmp" alt=":helado"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:helado</td></tr><tr><td align="center"> 
<img src="smilies/hippi.GIF" alt=":hippi"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:hippi</td></tr><tr><td align="center"> 
<img src="smilies/icon_twisted.gif" alt=":icon_twisted"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:icon_twisted</td></tr><tr><td align="center"> 
<img src="smilies/inlove.jpg" alt=":inlove"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:inlove</td></tr><tr><td align="center"> 
<img src="smilies/inlove.png" alt=":inlove"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:inlove</td></tr><tr><td align="center"> 
<img src="smilies/llora.gif" alt=":llora"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:llora</td></tr><tr><td align="center"> 
<img src="smilies/love.gif" alt=":love"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:love</td></tr><tr><td align="center"> 
<img src="smilies/maria.GIF" alt=":maria"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:maria</td></tr><tr><td align="center"> 
<img src="smilies/mutilado.bmp" alt=":mutilado"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:mutilado</td></tr><tr><td align="center"> 
<img src="smilies/nono.GIF" alt=":nono"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:nono</td></tr><tr><td align="center"> 
<img src="smilies/Nuclear-.bmp" alt=":Nuclear-"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:Nuclear-</td></tr><tr><td align="center"> 
<img src="smilies/Nueva imagen.GIF" alt=":Nueva imagen"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:Nueva imagen</td></tr><tr><td align="center"> 
<img src="smilies/paz.jpg" alt=":paz"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:paz</td></tr><tr><td align="center"> 
<img src="smilies/pelopulpo.bmp" alt=":pelopulpo"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:pelopulpo</td></tr><tr><td align="center"> 
<img src="smilies/PIRATA02.bmp" alt=":PIRATA02"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:PIRATA02</td></tr><tr><td align="center"> 
<img src="smilies/quee.bmp" alt=":quee"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:quee</td></tr><tr><td align="center"> 
<img src="smilies/ron.bmp" alt=":ron"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:ron</td></tr><tr><td align="center"> 
<img src="smilies/s10.gif" alt=":s10"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:s10</td></tr><tr><td align="center"> 
<img src="smilies/sandia.bmp" alt=":sandia"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:sandia</td></tr><tr><td align="center"> 
<img src="smilies/sandwich.gif" alt=":sandwich"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:sandwich</td></tr><tr><td align="center"> 
<img src="smilies/TQ.jpg" alt=":TQ"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:TQ</td></tr><tr><td align="center"> 
<img src="smilies/triste.gif" alt=":triste"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:triste</td></tr><tr><td align="center"> 
<img src="smilies/vaca2.bmp" alt=":vaca2"></td><td class="Texto" style="color:#000099;font-size: 10px; font-style: normal; font-family: verdana; ">:vaca2</td></tr><tr><td align="center"> 


<a href="MostrarMensajes.php" class="EnlaceMenu"><?=VOLVER; ?></a></td></tr></table>
</BODY>
</HTML>