<?php
 $nicks = array ();
?>
