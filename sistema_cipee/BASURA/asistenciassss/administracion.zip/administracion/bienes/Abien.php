<?php
include("../control/valida.php"); 
include("../config.php");
include("../css.php");
$resultado1 = pg_query($con,"SELECT * FROM departamento order by nombre_departamento");
?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field, countfield) {
countfield.value = field.value;
}

function comparar(field1,field2,field3,countfield) {
if (field1.value >= countfield.value)
field1.value = "";
}
  </script>
 
 <?php
include("../atras.php"); 
 ?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="2"><strong>Agregar Bien Nacional</strong></td>
    <td width="73">&nbsp;</td>
  </tr>
  <tr> 
    <td width="60">&nbsp;</td>
    <td width="709"><em>Escriba las caracter&iacute;sticas del Bien:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form id="form1" name="form1" method="post" action="insert_bien.php">
        <table width="98%" height="259" border="0" cellpadding="2" cellspacing="0">
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="23"> <div align="right"></div></td>
            <td width="79%"> <strong>Barinas, 
              <script>
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el año a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
<!-- document.write
document.write (dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
 
</script>
              </strong></td>
          </tr>
                  <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Serial BN:</strong></td>
            <td><input  size= 25 name="serial_bn" type="text"   value="<?php echo $_POST['serial_bn'];?>" />
            </td>
               </tr>    
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="26"> <div align="left"><strong>Descripcion del Bien:</strong></div></td>
            <td><input  size= 50 name="bien" type="text"   value="<?php echo $_POST['bien'];?>" /> 
            </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Color:</strong></td>
            <td><input  size= 25 name="color" type="text"   value="<?php echo $_POST['color'];?>" />
            </td>
               </tr>
                  <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Marca:</strong></td>
            <td><input  size= 25 name="marca" type="text"   value="<?php echo $_POST['marca'];?>" />
            </td>
               </tr>
                 <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Modelo:</strong></td>
            <td><input  size= 25 name="modelo" type="text"   value="<?php echo $_POST['modelo'];?>" />
            </td>
               </tr>
                 <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Serial:</strong></td>
            <td><input  size= 25 name="serial" type="text"   value="<?php echo $_POST['serial'];?>" />
            </td>
               </tr>
                     
              <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="26"><strong>Observaciones:</strong></td>
            <td><textarea name="observaciones" cols="60" id="textarea";"><?php echo $_POST['observaciones'];?></textarea></td>
          </tr>
           <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="26"><strong>Estatus:</strong></td>
          <td height="26"> <select name="tipo">
              <option value="ACTIVO">ACTIVO</option>
              <option value="INACTIVO">INACTIVO</option>
            </select></td>
             </tr>
           <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
             <td height="29"><strong>Unidad/Coordinación:</strong></td>
             <td><select name="partida3" id="partida3" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado1)){?>
                <option value="<? echo $obj->id_departamento?>"> <? echo $obj->nombre_departamento?> 
                </option>
                <? }//Fin while ?>
              </select></td>          
          </tr>  
            <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Responsable:</strong></td>
            <td><input  size= 25 name="responsable" type="text"   value="<?php echo $_POST['responsable'];?>" />
            </td>
               </tr>    
          
                 </table>
        <p><strong> </strong></p>
        <table width="8%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr> 
            <td width="10%"><div align="center"><strong> 
                <input value="GUARDAR" type="submit" name="submit2" />
                </strong></div></td>
          </tr>
          

        </table>
        <p><strong> </strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form></td>
    <td>&nbsp;</td>
  </tr>
 <?php
include("../pie.php"); 
 ?>


