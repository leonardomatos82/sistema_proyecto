<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
include("../utils.php");
?> 
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
    <td>
      <div align="center">
 <p><form style="width: 615px;" action="Aequipo.php?titulo=<?="AGREGAR EQUIPO"?>" method="post">
          <p align="left"><br>
            <?php	
	
		
if($_POST[procedencia]=="" || $_POST[tipo]==0 || $_POST[marca]==0 || $_POST[modelo]==0 ||  $_POST[serial]==""  || $_POST[bn]==""  ||  $_POST[direccion]==0 || $_POST[usuario]==0 )
		{
		echo"<b>Mensaje: </b>".Escriba_en_los_campos_obligatorios."<br><br>";
	   
     	}
	  else 
	   {
	   
	   $result = mysqli_query($con,"SELECT * FROM equipos  WHERE serial='$_POST[serial]'");
$row=mysqli_fetch_row($result);

 if ($_POST[serial]==$row[3])
    {	
    echo "Registro Existe";
	header("Location: Aequipo.php?titulo=AGREGAR EQUIPO (Error: El serial del equipo ya fue registrado)");
	  
	 }
	  else 
	 { 
	   $sql="INSERT INTO equipos (id_tipo,id_marca,id_modelo,serial,bn,mac1,mac2,mac3,mac4,ip,id_direccion,id_usuario,procedencia,observaciones) 
       VALUES ('$_POST[tipo]','$_POST[marca]','$_POST[modelo]','$_POST[serial]','$_POST[bn]','$_POST[mac1]','$_POST[mac2]','$_POST[mac3]','$_POST[mac4]','$_POST[ip]','$_POST[direccion]','$_POST[usuario]','$_POST[procedencia]','$_POST[observaciones]')"; 
       if (!mysqli_query($con,$sql)) { die('Error: ' . mysqli_error()); } 
         //llamo a la funcion para auditorias;
		$valor="-Operacion: Agregar -Tabla: Equipo -Registro Serial: ".$_POST[serial];
        registrarOperacion($con,$_SESSION['login'],$valor);                      
		echo "1 Registro  agregado";
	    }
		 }
 mysqli_close($con);
?>
          </p>
          <p align="left"> 
            <input value="Volver" type="submit">
          </p>
        </form>
<p>

</p>
    </div>
  </tbody> 
</table>
<p>&nbsp;</p>
