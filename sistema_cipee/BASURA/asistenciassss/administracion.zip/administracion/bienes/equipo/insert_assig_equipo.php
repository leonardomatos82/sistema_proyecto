<?php
include("../control/valida.php"); 
include("../config.php"); 
include("../utils.php"); 
$resulta = mysqli_query($con,"SELECT *
FROM assig_lic 
WHERE ((id_equipo='$_GET[id_equipo]') && (id_list='$_GET[id_list]'))

");
$roww= mysqli_fetch_row($resulta);
// echo $_GET[id_equipo];
 IF (($roww[0]==$_GET[id_equipo])&&($roww[1]==$_GET[id_list])) 
 {   
//echo "el codigo ya existe"; 
header("location: ../equipo/assig_equipo.php?id=".$_GET[id_equipo]);
  }else
  {
 $sql="INSERT INTO assig_lic (id_equipo,id_list) 
       VALUES ('$_GET[id_equipo]','$_GET[id_list]')"; 
      if (!mysqli_query($con,$sql)) { die('Error: ' . mysqli_error()); } 
          //llamo a la funcion para auditorias;
		$valor="-Operacion: Agregar -Tabla: Assig_list -Registro id_equipo: ".$_GET[id_equipo];
        registrarOperacion($con,$_SESSION['login'],$valor);          
       
 mysqli_close($con);
 
 header("location: ../equipo/assig_equipo.php?id=".$_GET[id_equipo]);
 }
?>