<?php 
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
?>

  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}

  </script>

<?php 
$result = mysqli_query($con,"SELECT equipos.id_equipo,tipo.descripcion,marca.nomb_marca,modelo.nomb_modelo,equipos.serial,equipos.bn,equipos.ip,direccion.nomb_direccion,usuario.nomb_usuario
 FROM equipos 
 INNER JOIN tipo ON equipos.id_tipo = tipo.id_tipo 
 INNER JOIN marca ON equipos.id_marca = marca.id_marca 
 INNER JOIN modelo ON equipos.id_modelo = modelo.id_modelo
 INNER JOIN direccion ON equipos.id_direccion = direccion.id_direccion
 INNER JOIN usuario ON equipos.id_usuario = usuario.id_usuario 
 where equipos.id_equipo='$_GET[id]'");


$row=mysqli_fetch_array($result);
$id_equipo=$row['id_equipo'];
$campo2=$row['id_modelo'];
$campo3=$row['id_tipo'];
$campo4=$row['id_direccion'];
$campo5=$row['id_usuario'];

?>
<?php
echo "<table  align=center cellpadding=1 cellspacing=1 bordercolor=264656 background-color: rgb(210, 210, 210); border =4; WIDTH=760 bgcolor=FFFFFF>";

 
echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>ID</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>TIPO</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>MARCA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>MODELO</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>SERIAL</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>IP</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>DIRECCION</b></td>";



echo "</tr> ";
echo "<tr>";
echo "<td <small style=width: 50px >$row[0]</td>";
echo "<td <small style=width: 100px >$row[1]</td>";
echo "<td <small style=width: 100px >$row[2]</td>";
echo "<td <small style=width: 100px >$row[3]</td>";
echo "<td <small style=width: 100px >$row[4]</td>";
echo "<td <small style=width: 50px >$row[6]</td>";
echo "<td <small style=width: 100px >$row[7]</td>";
echo "</tr> ";
?>
<?php

//////////////////////////////////////licencias asociadas////////////////////////////

echo "</table>";
?>

<table   style="background-color: rgb(189, 210, 230); text-align: center; width: 760px; height: 60px;" bordercolor="264656" align="center" border="4" cellpadding="1" cellspacing="1" width="442" height="47" bgcolor="264656">
  <tbody> 
  <td width="428" height="32"> 
    <div align="center"></div><b>Licencias asociadas al equipo</b>
  </tbody> 
</table>
<?php

$resulta = mysqli_query($con,"SELECT assig_lic.id_equipo,list_soft.id_list, list_soft.licencia,software.nomb_software,  list_soft.tipo, software.id_software
FROM assig_lic 
INNER JOIN list_soft ON list_soft.id_list = assig_lic.id_list
INNER JOIN software ON list_soft.id_software = software.id_software
");


echo "<table align=center cellpadding=1 cellspacing=1 bordercolor=264656 background-color: rgb(255, 255, 255); border =4; WIDTH=760 bgcolor=ced8e1>";
echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>ID</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>LICENCIA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>SOFTWARE</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>TIPO</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>BAJAR</b></td>";



echo "</tr> ";

while ($row = mysqli_fetch_row($resulta)){
$ress=mysqli_query($con,"SELECT * FROM assig_lic");
$roww= mysqli_fetch_row($ress);

IF (($row[0]==$id_equipo)) 
{
echo "<tr> ";
echo "<td <small style=width: 50px >$row[1]</td> ";
echo "<td <small style=width: 100px >$row[2]</td> ";
echo "<td <small style=width: 100px >$row[3]</td> ";
echo "<td <small style=width: 100px >$row[4]</td> ";
$id_list=$row[1];
?>

<td><a href="../equipo/elim_assig_equipo.php?id_equipo=<?=$id_equipo?>&id_list=<?=$id_list?>">
<img style="border: 0px solid ; width: 16px; height: 16px;" alt=""
 src="../imagenes/desig.png" ></a>

 </td>

<?PHP
echo "</tr> ";
}
}
echo "</table>";
?>

<?PHP
//////////////////////////////////////licencias a seleccionar////////////////////////////
?>


<table   style="background-color: rgb(180, 190, 200); text-align: center; width: 760px; height: 60px;" bordercolor="264656" align="center" border="4" cellpadding="1" cellspacing="1" width="442" height="47" bgcolor="264656">
  <tbody> 
  <td width="428" height="32"> 
    <div align="center"></div><b>Seleccione la Licencia</b>
  </tbody> 
</table>
<?php

$resulta = mysqli_query($con,"SELECT list_soft.id_list, list_soft.licencia,software.nomb_software,  list_soft.tipo, list_soft.status
FROM list_soft 
INNER JOIN software ON list_soft.id_software = software.id_software
");
echo "<table align=center cellpadding=1 cellspacing=1 bordercolor=264656 background-color: rgb(255, 255, 255); border =4; WIDTH=760 bgcolor=cbced2>";
echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>ID</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>LICENCIA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>SOFTWARE</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>TIPO</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>SUBIR</b></td>";



echo "</tr> ";
while ($row = mysqli_fetch_row($resulta)){
$ress=mysqli_query($con,"SELECT * FROM assig_lic WHERE  (id_list=$row[0])");
$roww= mysqli_fetch_row($ress);

IF (($roww[1]!=$row[0])) 
{
echo "<tr> ";
echo "<td <small style=width: 50px >$row[0]</td> ";
echo "<td <small style=width: 100px >$row[1]</td> ";
echo "<td <small style=width: 100px >$row[2]</td> ";
echo "<td <small style=width: 100px >$row[3]</td> ";
$id_list=$row[0];
?>

<td><a href="../equipo/insert_assig_equipo.php?id_equipo=<?=$id_equipo?>&id_list=<?=$id_list?>">
<img style="border: 0px solid ; width: 16px; height: 16px;" alt=""
 src="../imagenes/assig.png" ></a>

 </td>
<?PHP
echo "</tr> ";
}ELSE{
IF (($row[3]=="GNU"))
{
echo "<tr> ";
echo "<td <small style=width: 50px >$row[0]</td> ";
echo "<td <small style=width: 100px >$row[1]</td> ";
echo "<td <small style=width: 100px >$row[2]</td> ";
echo "<td <small style=width: 100px >$row[3]</td> ";
$id_list=$row[0];
?>

<td><a href="../equipo/insert_assig_equipo.php?id_equipo=<?=$id_equipo?>&id_list=<?=$id_list?>">
<img style="border: 0px solid ; width: 16px; height: 16px;" alt=""
 src="../imagenes/assig.png" ></a>

 </td>
<?PHP
echo "</tr> ";
}
}
}
echo "</table>";
?>
