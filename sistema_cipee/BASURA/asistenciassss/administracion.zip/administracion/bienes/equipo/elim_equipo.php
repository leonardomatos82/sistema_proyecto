<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
include("../utils.php");
?> 
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
    <td>
      <div align="center">
 <p><form style="width: 615px;" action="menu_equipo.php";" method="post">
          <p align="left"><br>
            <?php
//if($_POST[id]=="" || $_POST[tipo]=="" || $_POST[marca]=="" || $_POST[modelo]=="" ||  $_POST[serial]==""  || $_POST[bn]==""  ||  
//   $_POST[mac1]==""  || $_POST[mac2]==""  ||   $_POST[mac3]==""  || $_POST[mac4]=="" || $_POST[ip]==""||
 //  $_POST[direccion]=="" || $_POST[usuario]=="" )
//		{
//		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>";
		
      
  //  	}
//	  else 
	//   {
       $sql = "DELETE FROM equipos WHERE id_equipo='$_POST[id]'";
       //$result = mysqli_query($sql);
       if (!mysqli_query($con,$sql)) { die('Error: ' . mysqli_error()); } 
                      //llamo a la funcion para auditorias;
		$valor="-Operacion: Eliminar -Tabla: Equipo -Registro: ".$_POST[id];
        registrarOperacion($con,$_SESSION['login'],$valor); 
       echo "Registro N: ",$_POST[id]," eliminado";
       
       
 //       }
 mysqli_close($con);
?>
          </p>
          <p align="left"> 
            <input value="Volver" type="submit">
          </p>
        </form>
<p>

</p>
    </div>
  </tbody> 
</table>
<p>&nbsp;</p>

