<?php
include("../control/valida.php"); 
include("../css.php");
 include("../config.php");
$resultado = mysqli_query($con,"SELECT * FROM marca order by nomb_marca");
$resultado2 = mysqli_query($con,"SELECT * FROM modelo order by nomb_modelo");
$resultado3 = mysqli_query($con,"SELECT * FROM tipo order by descripcion");
$resultado4 = mysqli_query($con,"SELECT * FROM direccion order by nomb_direccion");
$resultado5 = mysqli_query($con,"SELECT * FROM usuario order by nomb_usuario");
?>

  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}

  </script>

<?php 
$sql="select * from equipos";
$result=mysqli_query($con,$sql);
$nreg= mysqli_num_rows($result);
$query="select * from equipos where equipos.id_equipo='$_GET[id]'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_array($result);
$campo1=$row['id_marca'];
$campo2=$row['id_modelo'];
$campo3=$row['id_tipo'];
$campo4=$row['id_direccion'];
$campo5=$row['id_usuario'];

$buscar1=mysqli_query($con,"select * from marca where marca.id_marca=$campo1");
$mbuscar1=mysqli_fetch_array($buscar1);

$buscar2=mysqli_query($con,"select * from modelo where modelo.id_modelo=$campo2");
$mbuscar2=mysqli_fetch_array($buscar2);
$buscar3=mysqli_query($con,"select * from tipo where tipo.id_tipo=$campo3");
$mbuscar3=mysqli_fetch_array($buscar3);
$buscar4=mysqli_query($con,"select * from direccion where direccion.id_direccion=$campo4");
$mbuscar4=mysqli_fetch_array($buscar4);
$buscar5=mysqli_query($con,"select * from usuario where usuario.id_usuario=$campo5");
$mbuscar5=mysqli_fetch_array($buscar5);

?>
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
    <td>
      <div align="left">
<form style="width: 742px; height: 450px;" action="edit_equipo.php" name="form" id="form"  method="post">
          <p>&nbsp;</p>
          <table width="75%" border="0">
            <tr> 
              <td width="15%"> 
                <div align="left">Id:</div>
              </td>
              <td width="85%"> 
                <input name="id" size="5" readonly type="text" value= "<?php echo $row['id_equipo'];?>"></td>

              </td>
            </tr>
			  <tr> 
              <td width="15%"> 
                <div align="left">Procedencia:</div>
              </td>
              <td width="85%"> 
                <input name="procedencia"  type="text" value= "<?php echo $row['procedencia'];?>">*</td>
             </td>
            </tr>
            <tr> 
              <td width="15%"> 
                <div align="left">Tipo:</div>
              </td>
              <td width="85%"> 
              <select name="tipo" id="tipo">
<option value="<? echo $mbuscar3['id_tipo']?>"><? echo $mbuscar3['descripcion']?></option>
<?php while($obj=mysqli_fetch_object($resultado3)){?>
<option value="<? echo $obj->id_tipo?>"><? echo $obj->descripcion?></option>
<? }//Fin while ?>
</select>*
              </td>
            </tr>
            <tr> 
              <td width="15%" height="30"> 
                <div align="left">Marca:</div>
              </td>
              <td width="85%" height="30"> 
                <p> 
                  <select name="marca" id="marca">
<option value="<? echo $mbuscar1['id_marca']?>"><? echo $mbuscar1['nomb_marca']?></option>
<?php while($obj=mysqli_fetch_object($resultado)){?>
<option value="<? echo $obj->id_marca?>"><? echo $obj->nomb_marca?></option>
<? }//Fin while ?>
</select>*
                </p>
              </td>
            </tr>
            <tr> 
              <td width="15%"> 
                <div align="left">Modelo:</div>
              </td>
              <td width="85%"> 
                 <select name="modelo" id="modelo">
<option value="<? echo $mbuscar2['id_modelo']?>"><? echo $mbuscar2['nomb_modelo']?></option>
<?php while($obj=mysqli_fetch_object($resultado2)){?>
<option value="<? echo $obj->id_modelo?>"><? echo $obj->nomb_modelo?></option>
<? }//Fin while ?>
</select>*
              </td>
            </tr>
            <tr> 
              <td width="15%"> 
                <div align="left">Serial:</div>
              </td>
              <td width="85%"> 
                <input name="serial"  type="text" value= "<?php echo $row['serial'];?>">*</td>
             </td>
            </tr>
            <tr> 
              <td width="15%" height="24"> 
                <div align="left">Serial BN:</div>
              </td>
              <td width="85%" height="24"> 
                <input name="bn"  type="text" value="<?php echo $row['bn'];?>">*</td>
             </td>
            </tr>
            <tr> 
              <td width="15%">Mac 1:&nbsp;</td>
              <td width="85%"> 
              <input name="mac1"  type="text" value="<?php echo $row['mac1'];?>"></td>
             </td>
            </tr>
            <tr> 
              <td width="15%">Mac 2:&nbsp;</td>
              <td width="85%"> 
              <input name="mac2"  type="text" value="<?php echo $row['mac2'];?>"></td>
              </td>
            </tr>
            <tr> 
              <td width="15%">Mac 3</td>
              <td width="85%"> 
                <input name="mac3"  type="text" value="<?php echo $row['mac3'];?>"></td>
             </td>
            </tr>
            <tr> 
              <td width="15%">Mac 4:</td>
              <td width="85%"> 
                <input name="mac4"  type="text" value="<?php echo $row['mac4'];?>"></td>
             </td>
            </tr>
            <tr> 
              <td width="15%" height="23">IP:&nbsp;</td>
              <td width="85%" height="23"> 
                <input name="ip"  type="text" value="<?php echo $row['ip'];?>"></td>
             </td>
            </tr>
            <tr> 
              <td width="15%">Direccion:</td>
              <td width="85%"> 
                 <select name="direccion" id="direccion">
<option value="<? echo $mbuscar4['id_direccion']?>"><? echo $mbuscar4['nomb_direccion']?></option>
<?php while($obj=mysqli_fetch_object($resultado4)){?>
<option value="<? echo $obj->id_direccion?>"><? echo $obj->nomb_direccion?></option>
<? }//Fin while ?>
</select>*
              </td>
            </tr>
            <tr> 
              <td width="15%">Usuario:</td>
              <td width="85%"> 
                 <select name="usuario" id="usuario" >
<option  value="<? echo $mbuscar5['id_usuario']?>"><? echo $mbuscar5['nomb_usuario']?></option>
<?php while($obj=mysqli_fetch_object($resultado5)){?>
<option value="<? echo $obj->id_usuario?>"><? echo $obj->nomb_usuario?></option>
<? }//Fin while ?>
</select>*
              </td>
			  </tr>
			    <tr>
              <td>Observaciones:</td>
              <td><label>
                <textarea name="observaciones" id="observaciones"><?php echo $row['observaciones'];?></textarea>
              </label></td>
            </tr>
            <tr>
              <td width="15%">&nbsp;</td>
              <td width="85%"> 
			  <input value="Guardar" type="button" name="Button" onclick="document.form.submit()" />
                  </td>
            </tr>
          </table>
          <p>
        </form>* Campo requerido
      </div>
    
  </tbody> 
</table>
<?php
include("../pie.php");
?>

