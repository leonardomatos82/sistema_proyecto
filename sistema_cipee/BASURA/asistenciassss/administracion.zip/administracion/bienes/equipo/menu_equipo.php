<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
?>
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
      <td><div align="center">
        <p align="left"><b> <font size="2">Seleccione:</font></b></p>
        <p>&nbsp;| <a href="../equipo/Aequipo.php?titulo=<?="AGREGAR EQUIPO"?>">Agregar</a> || <a href="../equipo/ver_modi.php?titulo=<?="MODIFICAR EQUIPO"?>">Modificar</a> || <a href="../equipo/ver_modi_lic.php?titulo=<?="AGREGAR LICENCIA"?>">Licencias</a> || <a href="../equipo/ver_elim.php?titulo=<?="ELIMINAR EQUIPO"?>">Eliminar</a> |</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </div></td>
    </tr>
  </tbody>
</table>
<?php
include("../pie.php");
?>
<p>&nbsp;</p>
