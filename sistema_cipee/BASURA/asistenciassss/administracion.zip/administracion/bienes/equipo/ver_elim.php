<?php 
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
$result = mysqli_query($con,"SELECT equipos.id_equipo,tipo.descripcion,marca.nomb_marca,modelo.nomb_modelo,equipos.serial,equipos.bn,equipos.ip,direccion.nomb_direccion,usuario.nomb_usuario
 FROM equipos 
 INNER JOIN tipo ON equipos.id_tipo = tipo.id_tipo 
 INNER JOIN marca ON equipos.id_marca = marca.id_marca 
 INNER JOIN modelo ON equipos.id_modelo = modelo.id_modelo
 INNER JOIN direccion ON equipos.id_direccion = direccion.id_direccion
 INNER JOIN usuario ON equipos.id_usuario = usuario.id_usuario 
");

?>
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
    <td height="26"> <small style="width: 750px; background-color: rgb(255,255,255);font-weight: bold;">
      <div align="left">SELECCIONE EL REGISTRO
        
      </div>
    </tr>
  </tbody>
</table>



<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
      <td height="26"><?php

echo "<table align=center cellpadding=1 cellspacing=0 background-color: rgb(255, 255, 255); border =2; WIDTH=100% bgcolor=#FFFFFF >";

 
echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>ID</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>TIPO</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>MARCA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>MODELO</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>SERIAL</b></td>";
//echo "<td <small style=width: 50px font-weight: bold><b>IP</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>DIRECCION</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>OPT</b></td>";


echo "</tr> ";
while ($row = mysqli_fetch_row($result)){
echo "<tr> ";
echo "<td <small style=width: 50px >$row[0]</td> ";
echo "<td <small style=width: 100px >$row[1]</td> ";
echo "<td <small style=width: 100px >$row[2]</td> ";
echo "<td <small style=width: 100px >$row[3]</td> ";
echo "<td <small style=width: 100px >$row[4]</td> ";
//echo "<td <small style=width: 100px >$row[6]</td> ";
echo "<td <small style=width: 100px >$row[7]</td> ";
?>       
<td><a href="../equipo/Eequipo.php?id=<?=$row[0]?>?&titulo=<?="SEGURO QUE DESEA ELIMINAR"?>"><img
 style="border: 0px solid ; width: 16px; height: 16px;" alt=""
 src="../imagenes/b_drop.png" ></a>
 

 </td>
<?PHP
echo "</tr> ";
}
echo "</table>";
?>
 </tr>
  </tbody>
</table>
<?php
include("../pie.php");
?>

