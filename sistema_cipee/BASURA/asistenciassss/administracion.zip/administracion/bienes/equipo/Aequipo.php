<?php 
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
$resultado = mysqli_query($con,"SELECT * FROM marca order by nomb_marca");
$resultado2 = mysqli_query($con,"SELECT * FROM modelo order by nomb_modelo");
$resultado3 = mysqli_query($con,"SELECT * FROM tipo order by descripcion");
$resultado4 = mysqli_query($con,"SELECT * FROM direccion order by nomb_direccion");
$resultado5 = mysqli_query($con,"SELECT * FROM usuario order by nomb_usuario");
?>
 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
  </script>
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
    <td>
      <div align="left">
<form action="insert_equipo.php" method="post" name="form" id="form" style="width: 742px; height: 430px;">
          <p>&nbsp;</p>
          <table width="75%" border="0">
            <tr> 
              <td width="17%">Procedencia: </td>
              <td width="83%"><select name="procedencia" id="procedencia">
                <option value="0">-- Seleccione --</option>
                <option value="Compra">Compra</option>
                <option value="Donaci&oacute;n">Donaci&oacute;n</option>
                <option value="Pr&eacute;stamo">Pr&eacute;stamo</option>
              </select>
              *</td>
            </tr>
            <tr>
              <td width="17%"><div align="left">Tipo:</div></td> 
              <td width="83%"><select name="tipo" id="tipo" >
                  <option value="0">-- Seleccione --</option>
                  <?php while($obj=mysqli_fetch_object($resultado3)){?>
                  <option value="<? echo $obj->id_tipo?>"> <? echo $obj->descripcion?> </option>
                  <? }//Fin while ?>
                </select>
                *                </td>
            </tr>
            <tr>
              <td width="17%"><div align="left">Marca:</div></td> 
              <td width="83%"><p>
                  <select name="marca" id="marca" >
                    <option value="0">-- Seleccione --</option>
                    <?php while($obj=mysqli_fetch_object($resultado)){?>
                    <option value="<? echo $obj->id_marca?>"> <? echo $obj->nomb_marca?> </option>
                    <? }//Fin while ?>
                  </select>
                * </p></td>
            </tr>
            <tr>
              <td width="17%"><div align="left">Modelo:</div></td> 
              <td width="83%"><select name="modelo" id="modelo" >
                  <option value="0">-- Seleccione --</option>
                  <?php while($obj=mysqli_fetch_object($resultado2)){?>
                  <option value="<? echo $obj->id_modelo?>"> <? echo $obj->nomb_modelo?> </option>
                  <? }//Fin while ?>
                </select>
                * </td>
            </tr>
            <tr>
              <td width="17%"><div align="left">Serial:</div></td> 
              <td width="83%"><input name="serial"  type="text" >
                *</td>
            </tr>
            <tr>
              <td width="17%"><div align="left">Serial BN:</div></td> 
              <td width="83%"><input name="bn" type="text" >
                * </td>
            </tr>
            <tr>
              <td width="17%">Mac 1:&nbsp;</td> 
              <td width="83%"><input name="mac1"  type="text" /></td>
            </tr>
            <tr>
              <td width="17%">Mac 2:&nbsp;</td> 
              <td width="83%"><input name="mac2"  type="text" >              </td>
            </tr>
            <tr>
              <td width="17%">Mac 3</td> 
              <td width="83%"><input name="mac3"  type="text" /></td>
            </tr>
            <tr>
              <td width="17%"> Mac 4:</td> 
              <td width="83%"><input name="mac4"  type="text" >              </td>
            </tr>
            <tr>
              <td width="17%">IP:&nbsp;</td> 
              <td width="83%"><input name="ip"  type="text" >              </td>
            </tr>
            <tr>
              <td width="17%">Direccion:</td> 
              <td width="83%"><select name="direccion" id="direccion" >
                  <option value="0">-- Seleccione --</option>
                  <?php while($obj=mysqli_fetch_object($resultado4)){?>
                  <option value="<? echo $obj->id_direccion?>"> <? echo $obj->nomb_direccion?> </option>
                  <? }//Fin while ?>
                </select>
                * </td>
            </tr>
            <tr>
              <td width="17%">Usuario:</td>
              <td width="83%"><select name="usuario" id="usuario" >
                <option value="0">-- Seleccione --</option>
                <?php while($obj=mysqli_fetch_object($resultado5)){?>
                <option value="<? echo $obj->id_usuario?>"> <? echo $obj->nomb_usuario?> </option>
                <? }//Fin while ?>
              </select>
                * </td>
            </tr>
            <tr>
              <td>Observaciones:</td>
              <td><label>
                <textarea name="observaciones" id="observaciones"></textarea>
              </label></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input value="Guardar" type="button" name="Button" onclick="document.form.submit()" /></td>
            </tr>
          </table>
          <p>
        </form>* Campo requerido</div>
    
  </tbody> 
</table>
<?php
include("../pie.php");
?>

