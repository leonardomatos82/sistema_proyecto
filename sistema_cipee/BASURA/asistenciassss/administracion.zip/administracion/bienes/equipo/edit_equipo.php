<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
include("../utils.php");
?> 
<table   style="background-color: rgb(255, 255, 255); text-align: center; width: 760px; height: 60px;" align="center" border="2" cellpadding="1" cellspacing="0">
  <tbody>
    <tr align="center" bordercolor="#000000">
    <td>
      <div align="center">
 <p><form style="width: 615px;" action="menu_equipo.php";" method="post">
          <p align="left"><br>
            <?php
if($_POST[id]==0 || $_POST[procedencia]=="" || $_POST[tipo]==0 || $_POST[marca]==0 || $_POST[modelo]==0 ||  $_POST[serial]==""  || $_POST[bn]==""  || 
   $_POST[direccion]==0 || $_POST[usuario]==0 )
		{
		echo"<b>Mensaje: </b>".Escriba_en_los_campos_obligatorios."<br><br>";
		
       	}
	  else 
	   {
	   
	   $sql = "UPDATE equipos SET id_tipo='$_POST[tipo]',procedencia='$_POST[procedencia]',id_marca='$_POST[marca]',id_modelo='$_POST[modelo]',serial='$_POST[serial]',bn='$_POST[bn]',mac1='$_POST[mac1]',mac2='$_POST[mac2]',mac3='$_POST[mac3]',mac4='$_POST[mac4]',ip='$_POST[ip]',id_direccion='$_POST[direccion]',id_usuario='$_POST[usuario]' WHERE id_equipo='$_POST[id]'";
            
       if (!mysqli_query($con,$sql)) { die('Error: ' . mysqli_error()); } 
         //llamo a la funcion para auditorias;
		$valor="-Operacion: Modificar -Tabla: Equipo -Registro Serial: ".$_POST[serial];
        registrarOperacion($con,$_SESSION['login'],$valor);   
       echo "Registro N: ",$_POST[id]," modificado";
       
       
        }
 mysqli_close($con);
?>
          </p>
          <p align="left"> 
            <input value="Volver" type="submit">
          </p>
        </form>
<p>

</p>
    </div>
  </tbody> 
</table>
<p>&nbsp;</p>