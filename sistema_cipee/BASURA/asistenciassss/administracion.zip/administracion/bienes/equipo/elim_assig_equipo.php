<?php
include("../control/valida.php"); 
include("../config.php");
include("../utils.php");
            
            $sql = "DELETE FROM assig_lic WHERE ((id_equipo='$_GET[id_equipo]') && (id_list='$_GET[id_list]'))";
           if (!mysqli_query($con,$sql)) { die('Error: ' . mysqli_error()); } 
                            //llamo a la funcion para auditorias;
		$valor="-Operacion: Eliminar -Tabla: Assig_lic -Registro: ".$_GET[id_equipo];
        registrarOperacion($con,$_SESSION['login'],$valor);      
        
 mysqli_close($con);
 header("location: ../equipo/assig_equipo.php?id=".$_GET[id_equipo]);
?>