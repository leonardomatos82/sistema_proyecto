<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
?>

  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}

  </script>

<?php 
$sql="select * from tabla";
$result=pg_query($con,$sql);
$nreg= pg_num_rows($result);
$query="select * from tabla where tabla.id_tabla='$_GET[id]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);
?>
  
</form>

<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Eliminar Tabla de Viaticos</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>&iquest;Seguro que desea Eliminar  la tabla de vi&aacute;tico?</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form id="form1" name="form1" method="post" action="elim_tabla.php">
      <table width="70%" height="146" border="0">
        <tr>
          <td width="19%"><div align="left">id:</div></td>
          <td><input name="id" type="text" id="id" onkeypress="return acceptchar(event)" value= "<?php echo $row['id_tabla'];?>" readonly="readonly" /></td>
          <td width="21%">&nbsp;</td>
        </tr>
        <tr>
          <td><div align="left">Tipo:</div></td>
          <td width="60%"><input name="tipo" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['tipo'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="30"><div align="left">Desayuno:</div></td>
          <td width="60%"><p>
              <input name="desayuno" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['desayuno'];?>" />
          </p></td>
          <td height="30"><p>&nbsp;</p></td>
        </tr>
        <tr>
          <td><div align="left">Almuerzo:</div></td>
          <td width="60%"><input name="almuerzo" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['almuerzo'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td><div align="left">Cena:</div></td>
          <td width="60%"><input name="cena" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['cena'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="24"><div align="left">Alojamiento:</div></td>
          <td width="60%"><input name="alojamiento"  readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['alojamiento'];?>" />
          </td>
          <td height="24">&nbsp;</td>
        </tr>
        <tr>
          <td>Taxi:&nbsp;</td>
          <td width="60%"><input name="taxi" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['taxi'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Transporte:&nbsp;</td>
          <td width="60%"><input name="transporte" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['transporte'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Tasa:</td>
          <td width="60%"><input name="tasa" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['tasa'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Autobus:</td>
          <td width="60%"><input name="autobus"  readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['tasa'];?>" />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="23">Vehiculo:&nbsp;</td>
          <td width="60%"><input name="vehiculo" readonly="readonly" onkeypress="return acceptchar(event)" type="text" value= "<?php echo $row['vehiculo'];?>" />
          </td>
          <td height="23">&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td width="60%"><input value="Eliminar" type="submit" name="submit" />
          </td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>

