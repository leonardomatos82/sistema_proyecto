<?php
 session_start();
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
?> 
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="menu_cheque.php" method="post">
      <p align="left"><br />
          <?php
	if($_POST[motivo]=="")
		{
		echo"<b>Mensaje: </b>".Escriba_un_motivo_para_anular_el_cheque."<br><br>"; 
       	}
	  else 
	   {	  
		  
      $anulado="ANULADO";
      $estado="SIN ASIGNAR";
	  $sql = "UPDATE cheque SET 
	  estado= '$anulado',
	 motivo='$_POST[motivo]',
	 fecha_a='".date("Y-m-d")."'
	 WHERE ncheque='$_POST[numero]'";
	 
     $sql2 = "UPDATE distribucion_cheque SET 
		 estado='$anulado'
	 WHERE ncheque='$_POST[numero]'";
	 
	      $sql3 = "UPDATE retencion_isrl SET 
		 estado='$estado'
	 WHERE ncheque='$_POST[numero]'";
	 
	     $sql4 = "UPDATE retencion_iva SET 
		 estado='$estado'
	 WHERE ncheque='$_POST[numero]'";

      if (!pg_query($con,$sql2)) { die('Error: ' . pg_result_error());}
      if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error());} 
      if (!pg_query($con,$sql3)) { die('Error: ' . pg_result_error());} 
      if (!pg_query($con,$sql4)) { die('Error: ' . pg_result_error());} 
	   echo " Registro  Anulado";
            /////////////////////////////
$valor="-Operacion: Anular -Cheque:  ".$_POST[numero];
 registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////  
 pg_close($con);
 	}
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>