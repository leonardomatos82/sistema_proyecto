<?php
include("../control/valida.php"); 
include("../config.php");
include("../css.php");

$queryw="select *
from cheque 
where ncheque='$_GET[id]'";
$resultw=pg_query($con,$queryw);
$roww=pg_fetch_array($resultw);

$resultadopart = pg_query($con,"SELECT p_terciaria.codigo_t,p_terciaria.descripcion,distribucion_cheque.cod_partida, p_terciaria.id_p_terciaria,distribucion_cheque.monto
 FROM distribucion_cheque 
  INNER JOIN p_terciaria ON distribucion_cheque.cod_partida= p_terciaria.id_p_terciaria 
where ncheque='$_GET[id]'");
$rowp1=pg_fetch_array($resultadopart );
$resultado1 = pg_query($con,"SELECT * FROM p_terciaria");
$resultado2 = pg_query($con,"SELECT * FROM p_terciaria");
$resultado3 = pg_query($con,"SELECT * FROM p_terciaria");
$resultado4 = pg_query($con,"SELECT * FROM p_terciaria");
$resultado5 = pg_query($con,"SELECT * FROM p_terciaria");
$resultado6 = pg_query($con,"SELECT * FROM p_terciaria");

if ($_POST[bolivares]<>0){
$query="SELECT * FROM numero where id_numero='$_POST[bolivares]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);
}
?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field, countfield) {
countfield.value = field.value;
}

function comparar(field1,field2,field3,countfield) {



if (field1.value >= countfield.value)
field1.value = "";

}



  </script>

 

<table width="670" border="0" align="center" bgcolor="#FFFFFF">
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>  
  <tr> 
    <td colspan="2"><strong>Anular Cheque</strong></td>
    <td width="73">&nbsp;</td>
  </tr>
  <tr> 
    <td width="60">&nbsp;</td>
    <td width="709"><em>Usted esta a punto de anular este Cheque:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form id="form1" name="form1" method="post" action="anular_cheque.php">
        <table width="98%" height="301" border="0" cellpadding="2" cellspacing="0">
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="20%" height="23"> <div align="right"></div></td>
            <td width="80%"> <strong>Barinas, 
              <script>
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el a�o a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
<!-- document.write
document.write (dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
 
</script>
              </strong></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="20%" height="28"> <div align="left"><strong>Cheque N&ordm;:</strong> 
              </div></td>
            <td><strong> 
              <input name="numero" type="text" id="numero4" onKeyPress="return acceptNum(event)" value="<?php echo $roww['ncheque'];?>" size="8" maxlength="8" readonly="readonly" />
              </strong> </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="20%" height="26"> <div align="left"><strong>Monto del cheque:</strong></div></td>
            <td><input  readonly="readonly" name="bolivares" type="text"  onKeyPress="return acceptNum(event)" value="<?php echo $roww['monto_cheque'];?>" onKeyUp="asignar(this.form.bolivares,this.form.total);"/> 
            </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Beneficiario:</strong></td>
            <td><input readonly="readonly" name="beneficiario" type="text" id="beneficiario" value="<?php echo $roww['beneficiario'];?>" size="67" /> 
            </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Cedula/Rif:</strong></td>
            <td><input  name="cedula_rif" type="text"   value="<?php echo $roww['cedula_rif'];?>" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="26"><strong>Concepto:</strong></td>
            <td><textarea readonly="readonly" name="concepto" cols="60" id="textarea";"><?php echo $roww['concepto'];?></textarea></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Programa:</strong></td>
            <td><input readonly="readonly" name="programa" type="text"   value="<?php echo $roww['programa'];?>" size="50" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Cod Contable:</strong></td>
            <td><input  readonly="readonly" name="contable" type="text"   value="<?php echo $roww['cod_contable'];?>" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF">
            <td height="23">Registro Actual:</td>
            <td>&nbsp;</td>
          </tr>
        </table>
        <p> 
          <?php
$result4 = pg_query($con,"SELECT p_terciaria.codigo_t,p_terciaria.descripcion,distribucion_cheque.cod_partida, p_terciaria.id_p_terciaria,distribucion_cheque.monto
 FROM distribucion_cheque 
  INNER JOIN p_terciaria ON distribucion_cheque.cod_partida= p_terciaria.id_p_terciaria 
where ncheque='$_GET[id]'");

 echo "<table align=left cellpadding=1 cellspacing=0 background-color: rgb(255, 255, 255); border =2; WIDTH=640 bgcolor=#FFFFFF >";

echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>PARTIDA PRESUPUESTARIA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>DESCRIPCION</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>MONTO</b></td>";

echo "</tr> ";
while ($row4 = pg_fetch_row($result4)){
echo "<tr> ";
echo "<td <small style=width: 50px >$row4[0]</td> ";
echo "<td <small style=width: 50px >$row4[1]</td> ";
echo "<td <small style=width: 50px >$row4[4]</td> ";
?>
        </p>
        <?PHP
echo "</tr> ";
}
echo "</table>";
?>
 <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
         <table width="45%" border="0" align="center">
          <tr> 
            <td width="77%"><div align="right"><strong>TOTAL</strong></div></td>
            <td width="23%"><div align="right"> 
                <input name="total" type="text" value="<?php echo $roww['monto_cheque'];?>" size="10" readonly="readonly">
              </div></td>
          </tr>
        </table>
    
        <p>&nbsp;</p>
        <table width="670" border="0" cellspacing="o" cellpadding="0" align="center">
          <tr> 
            <td width="21%">&nbsp;</td>
            <td width="79%">&nbsp;</td>
          </tr>
          
          <tr> 
            <td><strong>Motivo para anular:</strong></td>
            <td><div align="left">
                <textarea name="motivo" cols="60" id="textarea2";"></textarea>
              </div></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <p align="center"><strong> 
          <input value="ANULAR CHEQUE" type="submit" name="submit2" />
          </strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form></td>
    <td>&nbsp;</td>
  </tr>
  <? include("../pie.php"); ?>