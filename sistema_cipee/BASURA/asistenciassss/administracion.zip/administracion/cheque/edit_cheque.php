<?php
session_start();
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
?> 
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="menu_cheque.php" method="post">
      <p align="left"><br/>
<?php   
if($_POST[numero]=="" ||
   $_POST[bolivares]==""|| 
   $_POST[beneficiario]=="" || 
   $_POST[concepto]==""  || 
   $_POST[programa]=="" || 
   $_POST[contable]=="" || 
    $_POST[tipo]=="" || 
   $_POST[estado]=="")
		{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>"; 
       	}
	  else 
	   {
       $resultx = pg_query($con,"Select cedula_rif from usuario where nombre='$_POST[beneficiario]'");
       $rowx = pg_fetch_array($resultx);
	    $cedula_rif=  $rowx['cedula_rif'];       
	   
	  $sql = "UPDATE cheque SET 
	 ncheque='$_POST[numero]',
	 monto_cheque='$_POST[bolivares]',
	 beneficiario='$_POST[beneficiario]',
    cedula_rif='$cedula_rif',	 
	 concepto='$_POST[concepto]',
	 programa='$_POST[programa]',
	 cod_contable='$_POST[contable]',
	estado='$_POST[estado]',
	tipo_f='$_POST[tipo]'
	   WHERE ncheque='$_POST[numero]'";
 $sqle="DELETE from distribucion_cheque WHERE ncheque='$_POST[numero]'";
    if (!pg_query($con,$sqle)) { die('Error: ' . pg_result_error()); } 	
for($x=1; $x<=6; $x=$x+1)
{ 
$partida="partida".$x;
$monto="monto".$x;
 
   
if ($_POST[$partida]== ""  AND  $_POST[$monto]== "")
{}else{
    $query2="select * from distribucion_cheque where ncheque='$_POST[numero]'";
    $resulta=pg_query($con,$query2);
       $row=pg_fetch_array($resulta);  

//if ($row[ncheque]==""){
	  $sql2="INSERT INTO distribucion_cheque (fecha,ncheque,cod_partida,monto,programa,cod_contable,estado,tipo_f) 
       VALUES ('".date("Y-m-d")."','$_POST[numero]','$_POST[$partida]','$_POST[$monto]','$_POST[programa]','$_POST[contable]','$_POST[estado]','$_POST[tipo]')"; 
     if (!pg_query($con,$sql2)) { die('Error: ' . pg_result_error()); } 
//}else{

//     //      $sql2 = "UPDATE distribucion_cheque SET 
//	   cod_partida='$_POST[$partida]',
//	   monto='$_POST[$monto]',
//	    programa='$_POST[programa]',
//	   cod_contable='$_POST[contable]',
 //          estado='$_POST[estado]'
//	   WHERE ncheque='$_POST[numero]'";
  //   }

}	   
 };
	   
	   if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error()); } 
	   
       
echo "Registro_Modificado";
            /////////////////////////////
$valor="-Operacion: Modificar -Cheque:  ".$_POST[numero];
 registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////         }
 pg_close($con);
 }
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>
