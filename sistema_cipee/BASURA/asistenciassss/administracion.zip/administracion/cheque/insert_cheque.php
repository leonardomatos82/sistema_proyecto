<?php
session_start();
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
?> 
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="menu_cheque.php";" method="post">
      <p align="left"><br />
          <?php
   //$_POST[bolivares]=number_format($_POST[bolivares],2);

if($_POST[tipo]=="" ||$_POST[numero]=="" || $_POST[bolivares]==""|| $_POST[beneficiario]==""||  $_POST[concepto]==""  || $_POST[programa]=="" || $_POST[contable]=="")
		{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>"; 
       	}
	  else 
	   {
      $resultx = pg_query($con,"Select cedula_rif from usuario where nombre='$_POST[beneficiario]'");
       $rowx = pg_fetch_array($resultx);
	   $cedula_rif=  $rowx['cedula_rif'];


	   $query2="select * from usuario where cedula_rif= '$cedula_rif'";
       $result=pg_query($con,$query2);
       $row=pg_fetch_array($result);
	   $bolivares=$_POST[bolivares];
       if ($_POST[cedula_rif]==$row[cedula_rif]) {}
	    else 
		{
		 $sql3="INSERT INTO usuario (cedula_rif,nombre) 
       VALUES ('$cedula_rif','$_POST[beneficiario]')"; 
		pg_query($con,$query2);
		}
     $esta='PAGADO';
	   $sql="INSERT INTO cheque (fecha,ncheque,monto_cheque,cedula_rif,beneficiario,concepto,programa,cod_contable,estado,tipo_f) 
       VALUES ('".date("Y-m-d")."','$_POST[numero]','$_POST[bolivares]','$cedula_rif','$_POST[beneficiario]','$_POST[concepto]','$_POST[programa]','$_POST[contable]','$esta','$_POST[tipo]')"; 
        
	   
for($x=1; $x<=6; $x=$x+1)
{ 
$partida="partida".$x;
$monto="monto".$x;
//$monto=number_format($monto,2);


if ($_POST[$partida]== ""  AND  $_POST[$monto]== "")
{}else{

	  $sql2="INSERT INTO distribucion_cheque (fecha,ncheque,cod_partida,monto,programa,cod_contable,estado,tipo_f) 
       VALUES ('".date("Y-m-d")."','$_POST[numero]','$_POST[$partida]','$_POST[$monto]','$_POST[programa]','$_POST[contable]','$esta','$_POST[tipo]')"; 
      if (!pg_query($con,$sql2)) { die('Error: ' . pg_result_error()); } 

                 if($_POST[$partida]=="0"){
                          $rc2="select count(id_asignacion_caja_chica) from asignacion_caja_chica";
                          $qrc2=pg_query($con,$rc2);
                          $cant_reg2=pg_fetch_array($qrc2);
                          $num2=$cant_reg2[0]+1;
	                   $descripcion=$num2." REPOSICION DE CAJA CHICA";
	                  $estatus="EN EJECUCION";
	                  $sql4="UPDATE asignacion_caja_chica
                          SET estado='EJECUTADO'";
                          if (!pg_query($con,$sql4)) { die('Error: ' . pg_result_error()); }                       
	          $sql3="INSERT INTO asignacion_caja_chica(fecha, ncheque, monto, descripcion, estado)
                  VALUES ('".date("Y-m-d")."','$_POST[numero]','$bolivares','$descripcion','$estatus')"; 
                  if (!pg_query($con,$sql3)) { die('Error: ' . pg_result_error()); } 
          
                 
                 }
}
 };

 if($_POST[iva]!=""){
	   $update="UPDATE retencion_iva
       SET ncheque='$_POST[numero]', estado='ASIGNADO'       
       WHERE comprobante='$_POST[iva]'";
	   if (!pg_query($con,$update)) { die('Error: ' . pg_result_error()); }
	   }
	    if($_POST[isrl]!=""){
	    $update2="UPDATE retencion_isrl
       SET ncheque='$_POST[numero]', estado='ASIGNADO'       
       WHERE comprobante='$_POST[isrl]'";
       if (!pg_query($con,$update2)) { die('Error: ' . pg_result_error()); }
       }	

                 if ($_POST[id]==""){}else{
                        
                          $sql5="UPDATE viaticos
                         SET estado='PROCESADO' WHERE id_viatico='$_POST[id]'";
                          if (!pg_query($con,$sql5)) { die('Error: ' . pg_result_error()); } 
                          }
   
	   if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error()); } 
	   
       
       echo " Registro  agregado";
                 /////////////////////////////
       $valor="-Operacion: Agregar -Cheque:  ".$_POST[numero];
 registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////  
       $_POST[numero]=="";
       $_POST[bolivares]=="";
       $_POST[beneficiario]=="";

        }

 pg_close($con);
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>
