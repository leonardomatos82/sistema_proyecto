<?php
include("../control/valida.php"); 
include("../config.php");
include("../css.php");
include("cantidad.php");
$resultado1 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado2 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado3 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado4 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado5 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado6 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado6 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");
$resultado = pg_query($con,"SELECT * FROM usuario order by nombre");

$rc="select distinct(comprobante)  from retencion_iva 
where estado='SIN ASIGNAR'
order by comprobante desc";
$qrc=pg_query($con,$rc);
$rc2="select distinct(comprobante)  from retencion_isrl 
where estado='SIN ASIGNAR'
order by comprobante desc";
$qrc2=pg_query($con,$rc2);

?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field, countfield) {
countfield.value = field.value;
}

function comparar(field1,field2,field3,countfield) {



if (field1.value >= countfield.value)
field1.value = "";

}
  </script>
 
 <?php
include("../atras.php"); 
 ?>
<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="2"><strong>Agregar Cheque</strong></td>
    <td width="73">&nbsp;</td>
  </tr>
  <tr> 
    <td width="60">&nbsp;</td>
    <td width="709"><em>Escriba las caracter&iacute;sticas del Cheque:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><form id="form1" name="form1" method="post" action="insert_cheque.php">
        <table width="98%" height="259" border="0" cellpadding="2" cellspacing="0">
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="23"> <div align="right"></div></td>
            <td width="79%"> <strong>Barinas, 
              <script>
<!--
   nombres_dias = new Array("Domingo", "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado")
   nombres_meses = new Array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre")
   fecha_actual = new Date()
   dia_mes = fecha_actual.getDate()		//dia del mes
   strdia_mes = (dia_mes <= 9) ? "0" + dia_mes : dia_mes
   dia_semana = fecha_actual.getDay()		//dia de la semana
   mes = fecha_actual.getMonth() + 1
   strmes = (mes <= 9) ? "0" + mes : mes
   anio = fecha_actual.getYear()
   if (anio < 100) anio = "19" + anio			//pasa el a�o a 4 digitos
   else if ( ( anio > 100 ) && ( anio < 999 ) ) {	//efecto 2000
      var cadena_anio = new String(anio)
      anio = "20" + cadena_anio.substring(1,3)
   }
<!-- document.write
document.write (dia_mes + " de " + nombres_meses[mes - 1] + " de " + anio)
 
</script>
              </strong></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="28"> <div align="left"><strong>Cheque N&ordm;:</strong> 
              </div></td>
            <td><strong> 
              <input name="numero" type="text" id="numero4" onKeyPress="return acceptNum(event)" value="<?php echo $_POST[numero];?>" size="8" maxlength="8" />
              </strong> </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td width="21%" height="26"> <div align="left"><strong>Monto del cheque:</strong></div></td>
            <td><input  name="bolivares" type="text"  onKeyPress="return acceptNum(event)" value="<?php echo $_POST['bolivares'];?>" onKeyUP="asignar(this.form.bolivares,this.form.total);"/> 
            </td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="29"><strong>Beneficiario:</strong></td>
            <td><select name="beneficiario" id="select">
                <option value="<? echo $row['beneficiario']?>" selected><? echo $row['beneficiario']?></option>
                <?php while($obj=pg_fetch_object($resultado)){?>
                <option value="<? echo $obj->nombre?>"><? echo $obj->nombre?></option>
                <? }//Fin while ?>
              </select>
            </td>
              <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="26"><strong>Concepto:</strong></td>
            <td><textarea name="concepto" cols="60" id="textarea";"><?php echo $_POST['concepto'];?></textarea></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Programa:</strong></td>
            <td><input  name="programa" type="text"   value="<?php echo $_POST['programa'];?>" size="50" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Cod Contable:</strong></td>
            <td><input  name="contable" type="text"   value="BNS-<?php echo $numerosig;?>" /></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Comprobante IVA:</strong></td>
            <td><select name="iva" id="select4">
                <option value="Sin IVA" selected>Sin IVA</option>
                <?php while($obj=pg_fetch_object($qrc)){?>
                <option value="<? echo $obj->comprobante?>"><? echo $obj->comprobante?></option>
                <? }//Fin while ?>
              </select></td>
          </tr>
          <tr bordercolor="#000000" bgcolor="#FFFFFF"> 
            <td height="23"><strong>Comprobante ISRL:</strong></td>
            <td><select name="isrl" id="select5">
                <option value="Sin ISRL" selected>Sin ISRL</option>
                <?php while($obj=pg_fetch_object($qrc2)){?>
                <option value="<? echo $obj->comprobante?>"><? echo $obj->comprobante?></option>
                <? }//Fin while ?>
              </select></td>
          </tr>
           <tr> 
            <td height="23"><strong>Tipo Fondo:</strong></td>
            <td> <select name="tipo">
                <option value="">Seleccione:</option>
                <option value="FONDO MENSUAL">FONDO MENSUAL</option>
                <option value="FONDO ESPECIAL">FONDO ESPECIAL</option>
              </select>
              *</td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <table width="45%" border="0" align="center">
          <tr> 
            <td width="77%"><strong>PARTIDA PRESUPUESTARIA</strong></td>
            <td width="23%"><div align="right"><strong> MONTO</strong></div></td>
          </tr>
          <tr> 
            <td><select name="partida1" id="partida1" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado1)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right"> 
                <input name="monto1" type="text" size="10");">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida2" id="partida2" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado2)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right"> 
                <input name="monto2" type="text" id="monto2" size="10">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida3" id="partida3" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado3)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right"> 
                <input name="monto3" type="text" id="monto3" size="10">
              </div></td>
          </tr>
          <tr> 
            <td> <div align="left">
                <select name="partida4" id="select" >
                  <option value="" selected>-- Seleccione --</option>
                  <?php while($obj=pg_fetch_object($resultado4)){?>
                  <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                  </option>
                  <? }//Fin while ?>
                </select>
              </div></td>
            <td><div align="right">
                <input name="monto4" type="text" id="monto4" size="10">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida5" id="select2" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado5)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right">
                <input name="monto5" type="text" id="monto5" size="10">
              </div></td>
          </tr>
          <tr> 
            <td><select name="partida6" id="select3" >
                <option value="" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado6)){?>
                <option value="<? echo $obj->id_p_terciaria?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select></td>
            <td><div align="right">
                <input name="monto6" type="text" id="monto6" size="10">
              </div></td>
          </tr>
          <tr>
            <td><div align="right"><strong>TOTAL</strong></div></td>
            <td><div align="right">
                <input readonly="readonly" name="total" type="text" size="10">
              </div></td>
          </tr>
        </table>
        <p><strong> </strong></p>
        <table width="8%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr> 
            <td width="10%"><div align="center"><strong> 
                <input value="GUARDAR CHEQUE" type="submit" name="submit2" />
                </strong></div></td>
          </tr>
        </table>
        <p><strong> </strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </form></td>
    <td>&nbsp;</td>
  </tr>
 <?php
include("../pie.php"); 
 ?>
