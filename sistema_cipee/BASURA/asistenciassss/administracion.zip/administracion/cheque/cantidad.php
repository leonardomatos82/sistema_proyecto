<?php
//para el registro contable
include("../config.php");
$rc="select count(id_cheque) from cheque";
$qrc=pg_query($con,$rc);
$cant_reg=pg_fetch_array($qrc);
$num=$cant_reg[0]+1;
$numerosig=$num;
if ($num<100)
{
$numerosig="0".$num;
}

?>