<?php 
//include("control/valida.php"); 
//include("config.php");
?>
<body bgcolor="#FFFFFF">

<table width="760" border="0" align="center" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="3"><div align="center"> 
        <p><img src="../imagenes/banin.png" alt="d" width="760" height="70"></p>
        <p><img src="../imagenes/bannertop.png" alt="d" width="760" height="159"></p>
      </div></td>
  </tr>
  <tr> 
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><div align="center"><strong>SISTEMA PARA EL CONTROL Y ADMINISTRACION DE 
        FONDOS</strong></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
<td colspan="3"><div align="center"><img src="../imagenes/mural1.png" width="760" height="2" /></div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><div align="center"><FONT Size=2>|<a href="../menu.php">VOLVER</a> |</FONT></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><div align="center"><strong>MARGEN PARA IMPRIMIR LOS CHEQUES Y VOUCHERS</strong></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td height="59"><p align="right">&nbsp;</p>
      <p align="right">&nbsp;</p></td>
    <td><div align="center"><img src="../imagenes/margen1.png" width="400" height="426" /></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td><div align="center"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
   
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td> <marquee direction="left" onmouseout="this.start()" onmouseover="this.stop()">
      Desarrollado por: Analista Programador de Sistemas - Leonardo Matos </marquee></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
 <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" width="760" height="2" /></div></td>
  </tr>
</table>



