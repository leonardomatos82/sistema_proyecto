<?php 
//include("control/valida.php"); 
include("config.php");
include("utils.php");

include("style.php"); 
include("tabla2.php"); 
//<script>if(window.screen.availWidth == 800)window.parent.document.body.style.zoom="75%"; if(window.screen.availWidth == 640)window.parent.document.body.style.zoom="60%"</script>
?>