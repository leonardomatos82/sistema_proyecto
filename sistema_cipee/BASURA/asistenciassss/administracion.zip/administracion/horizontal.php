<link rel="stylesheet" type="text/css" href="estilos.css">
   <div id="vertical">
  
              <ul>
  
                      <li><a href="#">Home</a>
  
                      <li><a href="#">Quienes Somos</a>
 
                      <li><a href="#">Servicios</a>
  
                      <li><a href="#">Productos</a>
  
                      <li><a href="#">Contacto</a>
  
              </ul>
  
      </div>
  
