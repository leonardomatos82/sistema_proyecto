<?php 
session_start();
include("control/valida.php"); 
include("config.php");
include("utils.php");

include("style.php"); 
include("tabla.php"); 
$query2="SELECT * FROM tareas";
$result2=pg_query($con,$query2);

?>


 <tr>
  <tr><td></td>
    
     <td></td></tr>
 <td bgcolor="#FFFFFF"><b>MENU PRINCIPAL </b><link rel="stylesheet" type="text/css" href="estilos.css">
   <div id="vertical">
  
              <ul>
  
                      <li><a href="acceso/menu_acceso.php">Acceso</a>  
                      <li><a href="ingreso/menu_ingreso.php">Ingresos</a> 
                      <li><a href="cheque/menu_cheque.php">Cheques</a>  
                      <li><a href="chica/menu_chica.php">Caja Chica</a>  
                      <li><a href="iva/menu_iva.php">Retencion IVA</a>
							<li><a href="isrl/menu_isrl.php">Retencion ISRL</a>
                     <li><a href="usuario/menu_usuario.php">Usuarios</a>
                     <li><a href="partida/menu_partida.php">Partidas</a>
                     <li><a href="consulta/menu_consulta.php">Consultas</a>
                     <li><a href="viaticos/menu.php">Viaticos</a>
                     <li><a href="control/desconectar.php">Salir</a>

  
              </ul>
  
      </div></td>
      <td>
      <strong><div align="right"><font color="navy">Bienvenido(a) :<? $cadena=strtoupper($_SESSION[nomb_usuario]);?><? echo $cadena; ?></font></div></strong>
     <div align="left"><font size="2">Nota: Este sistema se encuentra en constantes modificaciones con el fin de mejorar tanto los procesos administrativos como la intefaz grafica. Pedimos disculpas por inconvenientes ocasionados. La Coordinacion de Informatica, Sede Barinas-Portuguesa.</font> </div> 
      <div align="<?echo $alight; ?>"><span class="style2"><img src="<?echo $imagen_menu; ?>"  width="<?echo $with_menu; ?>" height="<?echo $height_menu; ?>" /></span></div></td>

  
</tr>
    <tr><td></td>
    
     <td></td></tr>
    <tr><td></td>
    <td><div align="center"><span class="style3">Software Libre distribuido bajo licencia GNU/GPL. Versi&oacute;n 
        1.0 </span></div>      
        </td>
        </tr> 
     <tr>
     
    <td bgcolor="#FFFFFF"><b>UTILIDADES </b><link rel="stylesheet" type="text/css" href="estilos.css">
   <div id="vertical">
  
              <ul>    <li><a href="ADMON 2008">Documentos y Oficios Adm.</a>   
              
                        <li><a href="bienes/menu_bienes.php">Bienes Nacionales</a>                      
                        <li><a href="suministros/menu_suministros.php">Materiales y Suministros</a>   
								<li><a href="MensaHurdes/menu_msn.php">Sala de Chat SICAF</a>               
                       <li><a href="configuracion/Atarea.php">Enviar Sugerencia</a>  
                      <li><a href="manual/margenes.php">Margenes establecidos</a>  
                      <li><a href="manual/MANUAL_cheques_def.doc">Ver Manual de Usuario</a> 
                      <li><a href="manual/ayuda.php">Ver archivo de ayuda</a>  
                      <li><a href="configuracion/Mconf.php">Configuracion</a>  
                      <li><a href="CodabarMedium.ttf">Fuente</a>   
              </ul>
    <td>
 <div align="left">SUGERENCIAS ENVIADAS:
 <? 
 while ($row2 = pg_fetch_row($result2)){
 echo "<div align=left>";  
 echo "<img src=imagenes/tick.png>";
 echo $row2['1'];
 }?>
 </div> 
 </td>
 </tr>
 <td>Actualmente hay:
<? include("usuarios.php");
echo users(); 
?>
usuario(s) Conectado(s). </td>

<? include("pie.php"); ?>




