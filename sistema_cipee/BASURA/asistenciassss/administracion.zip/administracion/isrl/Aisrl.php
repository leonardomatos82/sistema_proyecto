<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
$query2="SELECT * FROM configuracion where id_configuracion='1'";
$resultado = pg_query($con,"SELECT * FROM usuario order by nombre");
$result2=pg_query($con,$query2);
$row2=pg_fetch_array($result2);
include("cantidad.php");
$resultado1 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");   
 ?>
 <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field1,field2,field3) {
isrl=field3.value;
field2.value=(field1.value*isrl)/100;
}

function comparar(field1,field2,field3,countfield) {
if (field1.value >= countfield.value)
field1.value = "";

}
  </script>

<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Agregar Retencion ISRL</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>Escriba los datos de la Retencion ISRL:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 742px; height: 260px;" action="insert_isrl.php"  method="post">
      <p>
      
        <table width="81%" border="0">
          <tr> 
            <td width="30%"><div align="left">Sujeto Retenido:</div></td>
            <td width="70%"><select name="sujeto" id="select">
                <option value="<? echo $row['nombre']?>" selected><? echo $row['nombre']?></option>
                <?php while($obj=pg_fetch_object($resultado)){?>
                <option value="<? echo $obj->nombre?>"><? echo $obj->nombre?></option>
                <? }//Fin while ?>
              </select></td>
          </tr>
          <tr> 
            <td width="30%">N&ordm; Comprobante:</td>
            <td><input autocomplete=OFF name="comprobante" type="text" id="cedula_rif10"  size="15" value="<? echo date("Ym"). $numerosig; ?>">
              *</td>
          </tr>
          <tr> 
            <td>Concepto:</td>
            <td><select name="tipo_transaccion" id="tipo_transaccion" >
                <option value="0" selected>-- Seleccione --</option>
                <?php while($obj=pg_fetch_object($resultado1)){?>
                <option value="<? echo $obj->descripcion?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select>
              *</td>
          </tr>
          <tr> 
            <td>Monto Sujeto</td>
            <td> 
              <input autocomplete=OFF name="total_compra" type="text"  value="0" onKeyPress="return acceptNum(event)" onKeyUp="asignar(this.form.total_compra,this.form.isrl_ret,this.form.n2);" size="15"/>
              * </td>
          </tr>
          <tr> 
            <td><font size="2">%RETENCION</font></td>
            <td>
              <input  onKeyUp="asignar(this.form.total_compra,this.form.isrl_ret,this.form.n2);" size="5" name="n2" type="text"  value="2" />
              *  </td>
          </tr>
          <tr> 
            <td>Monto ISRL Retenido:</td>
            <td> 
              <input  readonly="readonly" name="isrl_ret" type="text"   value="0"  size="15"/>
              * </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><input value="Guardar" type="submit" name="submit2"></td>
          </tr>
        </table>
        <p>&nbsp;</p>
      <p>* Campo requerido
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="" width="850" height="13" /></div></td>
  </tr>
</table>

  


