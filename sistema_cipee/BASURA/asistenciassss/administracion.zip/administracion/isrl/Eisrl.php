<?php
include("../control/valida.php"); 
include("../config.php");
include("../css.php");
$query2="SELECT * FROM configuracion where id_configuracion='1'";
$result2=pg_query($con,$query2);
$row2=pg_fetch_array($result2);
include("cantidad.php");
$resultado1 = pg_query($con,"SELECT * FROM p_terciaria order by descripcion");    

$result = pg_query($con,"SELECT *
 FROM retencion_isrl
where id_retencion_isrl='$_GET[id]' 
  ");
 $retencion=pg_fetch_array($result);


$monto_retenido=$retencion['monto_retenido'];

 ?>
 
 
<script language="javascript">
<!--
function alerta(){
if (confirm("Mensaje deconfirmacion.\r�estas de acuerdo?")){
alert("has pulsado ACEPTAR");
}else{
alert("has pulsadoCANCELAR");
}
}
//-->
</script>
 
  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 44 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 44 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}
function asignar(field1, field2,field3,field4,field5,field6,field7) {
iva=field6.value;
isrl=field7.value;
diferencia=field1.value-field2.value;
field5.value=diferencia/(1.09);
field3.value=(field5.value*iva)/100;
field4.value=(field3.value*isrl)/100;

}

function comparar(field1,field2,field3,countfield) {
if (field1.value >= countfield.value)
field1.value = "";

}
  </script>

<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Eliminar Retencion ISRL</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>&iquest;Seguro que desea eliminar este registro?:</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 742px; height: 260px;" action="elim_isrl.php"  method="post">
      <p>
      
        <table width="81%" border="0">
          <tr> 
            <td width="30%"><div align="left">ID:</div></td>
            <td width="70%"><input readonly="readonly" name="id" type="text" id="id"  size="15" value="<? echo $retencion['id_retencion_isrl']?>"></td>
          </tr>
          <tr> 
            <td>Sujeto Retenido:</td>
            <td width="70%"><select name="sujeto" id="select">
                <option value="<? echo $retencion['sujeto']?>" selected><? echo $retencion['sujeto']?></option>
                <?php while($obj=pg_fetch_object($resultado)){?>
                <option value="<? echo $obj->nombre?>"><? echo $obj->nombre?></option>
                <? }//Fin while ?>
              </select></td>
          </tr>
          <tr> 
            <td width="30%">N&ordm; Comprobante:</td>
            <td><input readonly="readonly" name="comprobante" type="text" id="cedula_rif10"  size="15" value="<? echo $retencion['comprobante']?>">
              *</td>
          </tr>
          <tr> 
            <td width="30%"><div align="left">Fecha:</div></td>
            <td width="70%"><input readonly="readonly" name="fecha" type="text" id="cedula_rif3" value="<? echo $retencion['fecha']?>"  size="15" >
              *</td>
          </tr>
          <tr> 
            <td height="11">N&ordm; Cheque</td>
            <td><input readonly="readonly" name="ncheque" type="text" id="ncheque" value="<? echo $retencion['ncheque']?>"  size="15"  autocomplete=OFF >
              *</td>
          </tr>
          <tr> 
            <td>Concepto:</td>
            <td> <select name="tipo_transaccion" id="tipo_transaccion" >
                <option value="<? echo $retencion['tipo_transaccion']?>" selected><? echo $retencion['tipo_transaccion']?></option>
                <?php while($obj=pg_fetch_object($resultado1)){?>
                <option value="<? echo $obj->descripcion?>"> <? echo $obj->descripcion?> 
                </option>
                <? }//Fin while ?>
              </select>
              *</td>
          </tr>
          <tr> 
            <td>Monto Sujeto</td>
            <td><font size="2"> 
              <input readonly="readonly" name="total_compra" type="text"  value="<? echo $retencion['monto_total']?>" onKeyPress="return acceptNum(event)" onKeyUp="asignar(this.form.total_compra,this.form.CSCF,this.form.iva,this.form.iva_ret,this.form.base,this.form.n1,this.form.n2);" size="15"/>
              * </font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><font size="2"> %RETENCION 
              <input readonly="readonly" onKeyUp="asignar(this.form.total_compra,this.form.CSCF,this.form.iva,this.form.iva_ret,this.form.base,this.form.n1,this.form.n2);" size="5" name="n2" type="text"  value="<? echo $retencion[pret]; ?>" />
              </font> </td>
          </tr>
          <tr> 
            <td>Impuesto:</td>
            <td><font size="2"> 
              <input  readonly="readonly" name="isrl_ret" type="text"   value="<? echo $monto_retenido?>"  size="15"/>
              * </font></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><input value="Eliminar" type="submit" name="submit2"></td>
          </tr>
        </table>
      <p>
</p>
      <p>* Campo requerido
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>

  


