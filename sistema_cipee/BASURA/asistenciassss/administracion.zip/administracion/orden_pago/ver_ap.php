<?php
include("../cheque/estilo_cheque.php");
include("../config.php");
include("../utils.php");
if ($_POST[bolivares]<>0){}
$query2="SELECT * FROM configuracion where id_configuracion='1'";
$result2=pg_query($con,$query2);
$row2=pg_fetch_array($result2);
$query="select *
from cheque 
where ncheque='$_GET[id]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);

include("numero2.php"); 

?>
<script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 47 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}
function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else 
countfield.value = maxlimit - field.value.length;
}

  </script>
  <td>&nbsp;</td>
<table width="617" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td height="0" colspan="3"> <div align="center"></div></td>
  </tr>
  <tr> 
    <td width="144" rowspan="4"><div align="center"><strong><font size="4" face="Times New Roman, Times, serif"><img src="../imagenes/ubv.jpg" width="70" height="62" /></font></strong></div></td>
    <td height="23" colspan="2"> <p align="left"><strong><font size="3" face="Times New Roman, Times, serif">UNIVERSIDAD 
        BOLIVARIANA DE VENEZUELA</font></strong></p></td>
  </tr>
  <tr> 
    <td height="0" colspan="2"> <div align="left"><strong><font size="3"><strong><font face="Times New Roman, Times, serif">SEDE 
        <?php echo $row2['sede'];?> -PORTUGUESA</font></strong></font></strong></div></td>
  </tr>
  <tr> 
    <td colspan="2"><div align="left"><strong><font size="3">COORDINACION DE ADMINISTRACION</font><font size="4"></font></strong></div></td>
  </tr>
  <tr> 
    <td colspan="2"><div align="center"><strong><font size="4"></font></strong></div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="2"><div align="center"><strong><font size="4"></font></strong></div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="2"><div align="center"><strong><font size="4"></font></strong></div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="2"><div align="center"><strong><font size="4"><em>AUTORIZACION 
        PRESUPUESTARIA </em></font></strong></div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="2"> <div align="center"><strong><font size="4"></font></strong></div></td>
  </tr>
  <tr> 
    <td><div align="right"><strong>AP N&ordm; :</strong></div></td>
    <td width="345"><?php echo $row[6];?></td>
    <td width="128">&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="right"><strong>FECHA :</strong></div></td>
    <td> 
      <?php $row[0]=cambiaf_a_normal($row[0]); echo $row[0];?>
    </td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td height="25"> <div align="right"><strong>BANCO :</strong></div></td>
    <td><img src="../imagenes/BIV.jpg" width="113" height="26"> </td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="right"><strong>CUENTA :</strong></div></td>
    <td><?php echo $row2['cuenta'];?></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="right"><strong>PROGRAMA :</strong></div></td>
    <td><?php echo $row['programa'];?></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="right"></div></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="right"><strong>BENEFICIARIO :</strong></div></td>
    <td><?php echo $row['beneficiario'];?></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="right"><strong>RIF-CEDULA :</strong></div></td>
    <td><?php echo $row['cedula_rif'];?></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td height="23">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr></table>
  <tr> 
    <td><div align="left"><strong>CONCEPTO : </strong></div></td>
    <td colspan="2" rowspan="3" font size="2"> <?php echo "<small style=width: 50px >$row[concepto]";?></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td height="23">&nbsp;</td>
  </tr>

<p> 
  <?php
$result4 = pg_query($con,"SELECT p_terciaria.codigo_t,p_terciaria.descripcion,distribucion_cheque.cod_partida, p_terciaria.id_p_terciaria,distribucion_cheque.monto
 FROM distribucion_cheque 
  INNER JOIN p_terciaria ON distribucion_cheque.cod_partida= p_terciaria.id_p_terciaria 
where ncheque='$_GET[id]'");

 echo "<table align=left cellpadding=1 cellspacing=0 background-color: rgb(255, 255, 255); border =2; WIDTH=640 bgcolor=#FFFFFF >";

echo "<tr>";
echo "<td <small style=width: 50px font-weight: bold><b>PARTIDA PRESUPUESTARIA</b></td>";
echo "<td <small style=width: 100px font-weight: bold><b>DESCRIPCION</b></td>";
echo "<td <small style=width: 50px font-weight: bold><b>MONTO</b></td>";

echo "</tr> ";
while ($row4 = pg_fetch_row($result4)){
echo "<tr> ";
$row4[4]=number_format($row4[4],2);
echo "<td <small style=width: 50px >$row4[0]</td> ";
echo "<td <small style=width: 50px >$row4[1]</td> ";
echo "<td <small style=width: 50px >$row4[4]</td> ";
?>
</p>
<?PHP
echo "</tr> ";
}
echo "</table>";
?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<p>&nbsp;</p>
<td>&nbsp;</td>
<td>&nbsp;</td>
<p>&nbsp;</p>
<table width="709" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <td height="19"> <div align="left"><strong>TOTAL AUTORIZADO: (<?php echo number_format($row['monto_cheque'],2);?>)</strong></div></td>
  <p>&nbsp;</p>
</table>

<table width="709" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr bordercolor="#CCCCCC"> 
    <td width="709"><font size="1"><strong> 
      <?php $cadena=strtoupper($x);$cadena2=strtoupper($muestra); echo ($cadena).$cadena2;?>
      </strong> </font> <div align="right"></div></td>
  </tr>
  <tr bordercolor="#CCCCCC"> 
    <td><strong>________________________________________________________________________________________</strong> 
      <div align="right"></div></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width=100% border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr bordercolor="#CCCCCC"> 
    <td width=25%><strong><font size="2">REVISADO POR</font></strong></td>
    <td width=25%><strong><font size="2">APROBADO POR</font></strong></td>
    <td width=25%><strong><font size="2">AUTORIZADO POR</font></strong></td>
    
  </tr>
  <tr> 
    <td><font size="2"><?php echo $row2['administrador'];?></font></td>
    <td><font size="2"><?php echo $row2['coordinador_adm'];?></font></td>
    <td><font size="2"><?php echo $row2['coordinador_sede'];?></font></td>

  </tr>
  <tr> 
<td><font size="2"><?php echo $row2['cargo3'];?></font></td>
    <td><font size="2"><?php echo $row2['cargo2'];?></font></td>
    <td><font size="2"><?php echo $row2['cargo1'];?></font></td>
  
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>

  </tr></tr>
</table>

<table width="93%" border="0" align="left" cellpadding="0" cellspacing="0">
  <tr> 
    <td><div align="left"><font face="CodabarMedium"><?php echo $row['ncheque'].$row['beneficiario'].$row['monto_cheque'];?> 
       
        </strong></font></div></td>
  </tr>
</table>
<tr>
  <td width="769" height="220">&nbsp;