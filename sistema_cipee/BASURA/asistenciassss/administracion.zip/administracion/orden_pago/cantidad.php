<?php
//para el registro contable
include("../config.php");
if ($_POST[orden]=="ORDEN DE COMPRA"){
$rc="select count(id_ordencs) from ordencs where tipo='ORDEN DE COMPRA'";
}else
if ($_POST[orden]=="ORDEN DE SERVICIO"){
$rc="select count(id_ordencs) from ordencs where tipo='ORDEN DE SERVICIO'";
}else{
$rc="select count(id_ordencs) from ordencs";
}


$qrc=pg_query($con,$rc);
$cant_reg=pg_fetch_array($qrc);
$num=$cant_reg[0]+1;
$numerosig=$num;
if ($num<100)
{
$numerosig="0".$num;
}

?>