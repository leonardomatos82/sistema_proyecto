<?php 
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
//include("cantidad.php");
?>
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">SELECCIONE EL REGISTRO</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="59"><p align="right">&nbsp;</p>
    <p align="right">&nbsp;</p></td>
    <td><table width="88%" height="48" border="0"  align="center" cellpadding="0" cellspacing="1"   style="background-color: rgb(255, 255, 255); text-align: center; width: 88%; height: 50px;" >
      <tbody>
      </tbody>
      <tr>
        <td width="88%" height="42" bordercolor="#000000" bgcolor="#FFFFFF"><div align="center">
            <?php
$result = pg_query($con,"SELECT *
 FROM cheque 
 where (estado ='PAGADO')  ORDER BY id_cheque DESC
 ");
 
 echo "<table align=center cellpadding=1 cellspacing=0 background-color: rgb(255, 255, 255); border =2; WIDTH=100% bgcolor=#FFFFFF >";

 echo "<tr>";
 echo "<td <font size=2 align=right><small style=width: 50px>ID</font></td>";
 echo "<td <font size=2 align=center><small style=width: 50px>----FECHA----</font></td>";
 echo "<td <font size=2 align=center><small style=width: 50px>--NUMERO--</font></td>";
  echo "<td <font size=2 align=right><small style=width: 50px>MONTO CHEQ</font></td>";
   echo "<td <font size=2 align=left><small style=width: 50px>BENEFICIARIO</font></td>";
   echo "<td <font size=2 align=left><small style=width: 50px>AP</font></td>";
      echo "<td <font size=2 align=left><small style=width: 50px>OP</font></td>";
echo "</tr> ";
$c=$numerosig;
while ($row = pg_fetch_row($result)){$c--;
echo "<tr> ";
$row[0]=cambiaf_a_normal($row[0]);
$row[2]=number_format($row[2],2);
echo "<td <font size=2 align=right><small style=width: 50px>$c</font></td>";
echo "<td <font size=2 align=center><small style=width: 50px>$row[0]</font></td>";
echo "<td <font size=2 align=center><small style=width: 50px>$row[6]</font></td>";
echo "<td <font size=2 align=right><small style=width: 50px>$row[2]</font></td>";
echo "<td <font size=2 align=left><small style=width: 50px>$row[3]</font></td>";
?>
            </p>
        </div></td>
        <td><a href="../orden_pago/ver_ap.php?id=<?=$row[1]?>&amp;titulo=<?="IMPRIMIR CHEQUE"?>"><img
 style="border: 0px solid ; width: 16px; height: 16px;" alt="Cheque"
 src="../imagenes/AP.png"></a></td>
  <td><a href="../orden_pago/ver_op.php?id=<?=$row[1]?>&amp;titulo=<?="IMPRIMIR VOUCHER"?>"><img
 style="border: 0px solid ; width: 16px; height: 16px;" alt="Voucher"
 src="../imagenes/OP.png"></a></td>
        <?PHP
echo "</tr> ";
}
echo "</table>";
?>
        &nbsp;
        <td></td></td>
      </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>