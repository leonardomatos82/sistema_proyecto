<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
?>

<tr>
<td bgcolor="#FFFFFF"><b>MENU PRINCIPAL </b><link rel="stylesheet" type="text/css" href="../estilos.css">
   <div id="vertical">
  
              <ul>
  
							<li><a href="../menu.php">Inicio</a>                        
                      <li><a href="../acceso/menu_acceso.php">Acceso</a>  
                      <li><a href="../ingreso/menu_ingreso.php">Ingresos</a> 
                      <li><a href="../cheque/menu_cheque.php">Cheques</a>  
                      <li><a href="../chica/menu_chica.php">Caja Chica</a>  
                      <li><a href="../iva/menu_iva.php">Retencion IVA</a>
							<li><a href="../isrl/menu_isrl.php">Retencion ISRL</a>
                     <li><a href="../usuario/menu_usuario.php">Usuarios</a>
                     <li><a href="../partida/menu_partida.php">Partidas</a>
                     <li><a href="../consulta/menu_consulta.php">Consultas</a>
                     <li><a href="../viaticos/menu.php">Viaticos</a>
                     <li><a href="../control/desconectar.php">Salir</a>

  
              </ul>
<td bgcolor="#FFFFFF"><b>SUBMENU RETENCION IVA </b><link rel="stylesheet" type="text/css" href="../estilos.css">
   <div id="vertical">
  
              <ul>
  
                      <li><a href="Aiva.php">Agregar Ret. IVA</a>  
                      <li><a href="ver_modiiva.php">Modificar Ret. IVA</a> 
                      <li><a href="ver_elimiva.php">Eliminar Ret. IVA</a>  
                      <li><a href="ver_impiva.php">Imprimir Ret. IVA</a> 
							

  
              </ul>
  
    <td><div align="<?echo $alight; ?>"><span class="style2"><img src="../<?echo $imagen_menu4; ?>"  width="<?echo $with_submenu; ?>" height="<?echo $height_submenu; ?>" /></span></div>
    <div align="center"><span class="style3">Software Libre distribuido bajo licencia GNU/GPL. Versi&oacute;n 
        1.0 </span></div>
    </td>
    <td></td></tr>
    <tr><td></td>
    <td></td>
    <td></td>
     
   </tr>  
 
<tr>
 <td>&nbsp;</td>
<td>&nbsp;</td>
 </tr> <tr>
 <td>&nbsp;</td>
<td>&nbsp;</td>
 </tr>  
<? include("../pie.php"); ?>

