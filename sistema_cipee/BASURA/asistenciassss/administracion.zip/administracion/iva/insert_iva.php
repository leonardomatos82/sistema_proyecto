<?php
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
session_start();
?> 
<table width="824" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2">&nbsp;</td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 615px;" action="menu_iva.php";" method="post">
      <p align="left"><br />
<?php
$_POST[total_compra]==number_format($_POST[total_compra],2);
$_POST[CSCF]==number_format($_POST[CSCF],2);
$_POST[base]==number_format($_POST[base],2);
$_POST[iva]==number_format($_POST[iva],2);
$_POST[iva_ret]==number_format($_POST[iva_ret],2);
		  
if($_POST[sujeto]=="" 
|| $_POST[comprobante]=="" || 
$_POST[fecha_fact]=="" ||
 $_POST[nfactura]==""|| 
 $_POST[ncontrol]==""||
  $_POST[tipo_transaccion]==""
  || $_POST[total_compra]==""
  || $_POST[CSCF]==""
  || $_POST[base]==""
  || $_POST[iva]==""
  || $_POST[iva_ret]==""
  || $_POST[n1]==""
  || $_POST[n2]=="")
		{
		echo"<b>Mensaje: </b>".Todos_los_campos_son_obligatorios."<br><br>";
		
    	}
	  else 
	   {  
	   
	   $result = pg_query($con,"Select cedula_rif from usuario where nombre='$_POST[sujeto]'");
       $row = pg_fetch_array($result);
	   $cedula_rif=  $row['cedula_rif'];
	   $estado="SIN ASIGNAR";
       $sql="INSERT INTO retencion_iva (fecha,sujeto,cedula_rif,comprobante,fecha_fact,nfactura,ncontrol,tipo_transaccion,monto_total,monto_scf,monto_base,iva,monto_retenido,piva,pret,estado) 
       VALUES ('".date("Y-m-d")."','$_POST[sujeto]','$cedula_rif','$_POST[comprobante]','$_POST[fecha_fact]','$_POST[nfactura]','$_POST[ncontrol]','$_POST[tipo_transaccion]','$_POST[total_compra]','$_POST[CSCF]','$_POST[base]','$_POST[iva]','$_POST[iva_ret]','$_POST[n1]','$_POST[n2]','$estado')"; 
       if (!pg_query($con,$sql)) { die('Error: ' . pg_result_error()); } 
       
       echo "1 Registro  agregado";

            /////////////////////////////
$valor="-Agregar Retencion IVA:  ".$_POST[comprobante];
 registrarOperacion($con,$_SESSION['login'],$valor);      
///////////////////////////////////////////////////////////////////  
        }
 pg_close($con);
?>
      </p>
      <p align="left">
        <input name="submit" type="submit" value="Volver" />
      </p>
    </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>

