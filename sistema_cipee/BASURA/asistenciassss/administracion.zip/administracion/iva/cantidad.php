<?php
//para el el correlativo de numero de comprobante ojo recuerda el distinc para distinguir los numeros de comprobantes
//include("../config.php");
$rc="select count(distinct(comprobante))  from retencion_iva";
$qrc=pg_query($con,$rc);
$cant_reg=pg_fetch_array($qrc);
$num=$cant_reg[0]+1;
$numerosig=$num;
    if ($num<10)
     {
       $numerosig="0000000".$num;
     }else
	     {
           if ($num>=10 && $num<100)
            {
              $numerosig="000000".$num;
            }else{
                   if ($num>=100 && $num<1000)
                    {
                      $numerosig="00000".$num;
                    }else{
                          if ($num>=1000 && $num<10000)
                          {
                           $numerosig="0000".$num;
                          }
					      }
}
}

?>