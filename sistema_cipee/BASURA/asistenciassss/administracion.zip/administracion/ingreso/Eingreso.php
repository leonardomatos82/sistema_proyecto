<?php 
include("../control/valida.php"); 
include("../css.php");
include("../config.php");
//include("../utils.php");
//include("../control/check_user.php"); 
//$resultado = pg_query($con,"SELECT * FROM acceso" );
?><head>
  <script language="JavaScript">
function acceptNum(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key <= 13 || (key >= 48 && key <= 57));
}
var nav4 = window.Event ? true : false;
function acceptChar(evt){ var key = nav4 ? evt.which : evt.keyCode; return (key < 48 || key > 57);
}

  </script>
<?php 
$query="select * from ingresos where ingresos.id_ingresos='$_GET[id]'";
$result=pg_query($con,$query);
$row=pg_fetch_array($result);
$fecha=cambiaf_a_normal($row[fecha]);
?>
  
<table width="600" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td colspan="2"><strong>Eliminar Ingreso</strong></td>
    <td width="77">&nbsp;</td>
  </tr>
  <tr>
    <td width="149">&nbsp;</td>
    <td width="584"><em>�Seguro que desea eliminar este Registro?</em></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="88"><p align="right">&nbsp;</p>
        <p align="right">&nbsp;</p></td>
    <td><form style="width: 100%; height: 70%;" action="elim_ingreso.php" ;="" method="post">
      <table width="70%" border="0">
        <tr>
          <td width="30%"><div align="left">Id:</div></td>
          <td width="76%"><input size="5" readonly="readonly" name="id"  onkeypress="return acceptChar(event)" &gt="" type="text" value= "<?php echo $row['id_ingresos'];?>" /></td>
          <td></td></td>
        </tr>
        <tr>
          <td width="30%"><div align="left">Fecha:</div></td>
          <td width="76%"><input name="fecha" readonly="readonly" type="text" value= "<?php echo $fecha;?>" />
            *</td>
          <td></td></td>
        </tr>
        <tr>
          <td width="30%"><div align="left">Beneficiario:</div></td>
          <td width="76%"><input name="beneficiario" readonly="readonly" type="text" value= "<?php echo $row['beneficiario'];?>" />
            *</td>
          <td></td></td>
        </tr>
        <tr>
          <td width="24%"><div align="left">Concepto:</div></td>
          <td width="76%">
		  <textarea name="concepto" cols="50" readonly="readonly" id="textarea2" value=""><?php echo $row['concepto'];?></textarea>*</td>
          <td></td></td>
        </tr>
		     <tr>
          <td width="24%"><div align="left">Codigo:</div></td>
          <td width="76%"><input name="codigo" readonly="readonly" type="text" value= "<?php echo $row['codigo'];?>" />
            *</td>
          <td></td></td>
        </tr>
				     <tr>
          <td width="24%"><div align="left">monto:</div></td>
          <td width="76%"><input name="monto" readonly="readonly" type="text" value= "<?php echo $row['monto'];?>" />
            *</td>
          <td></td></td>
        </tr>
        <tr>
          <td width="24%"><div align="right"></div></td>
          <td width="76%"><input value="Guardar" type="submit" name="submit" />
          </td>
        </tr>
      </table>
	
	  </form>
	&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>* Campo requerido</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><img src="../imagenes/mural1.png" alt="d" width="850" height="13" /></div></td>
  </tr>
</table>